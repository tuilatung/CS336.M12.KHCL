#ifndef org_apache_lucene_analysis_ja_JapaneseNumberFilter_H
#define org_apache_lucene_analysis_ja_JapaneseNumberFilter_H

#include "org/apache/lucene/analysis/TokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {

          class _dll_lucene JapaneseNumberFilter : public ::org::apache::lucene::analysis::TokenFilter {
           public:
            enum {
              mid_init$_00000000419d1091,
              mid_incrementToken_0000000000c0c182,
              mid_isArabicNumeral_ffffffffe9b4328a,
              mid_isNumeral_ffffffffc94366ea,
              mid_isNumeral_ffffffffe9b4328a,
              mid_isNumeralPunctuation_ffffffffe9b4328a,
              mid_isNumeralPunctuation_ffffffffc94366ea,
              mid_normalizeNumber_ffffffffbf6eae52,
              mid_reset_ffffffffde902c42,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit JapaneseNumberFilter(jobject obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            JapaneseNumberFilter(const JapaneseNumberFilter& obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {}

            JapaneseNumberFilter(const ::org::apache::lucene::analysis::TokenStream &);

            jboolean incrementToken() const;
            jboolean isArabicNumeral(jchar) const;
            jboolean isNumeral(const ::java::lang::String &) const;
            jboolean isNumeral(jchar) const;
            jboolean isNumeralPunctuation(jchar) const;
            jboolean isNumeralPunctuation(const ::java::lang::String &) const;
            ::java::lang::String normalizeNumber(const ::java::lang::String &) const;
            void reset() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(JapaneseNumberFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(JapaneseNumberFilter);

          class _dll_lucene t_JapaneseNumberFilter {
          public:
            PyObject_HEAD
            JapaneseNumberFilter object;
            static PyObject *wrap_Object(const JapaneseNumberFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
