#ifndef org_apache_lucene_analysis_AnalyzerWrapper_H
#define org_apache_lucene_analysis_AnalyzerWrapper_H

#include "org/apache/lucene/analysis/Analyzer.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class Reader;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene AnalyzerWrapper : public ::org::apache::lucene::analysis::Analyzer {
         public:
          enum {
            mid_getOffsetGap_0000000026f4dfbe,
            mid_getPositionIncrementGap_0000000026f4dfbe,
            mid_initReader_ffffffff978ef084,
            mid_normalize_000000001d1e9a51,
            mid_createComponents_000000003a09807f,
            mid_attributeFactory_ffffffffa3592994,
            mid_initReaderForNormalization_ffffffff978ef084,
            mid_wrapTokenStreamForNormalization_000000001d1e9a51,
            mid_wrapReaderForNormalization_ffffffff978ef084,
            mid_getWrappedAnalyzer_ffffffffed78a70d,
            mid_wrapComponents_00000000391dc405,
            mid_wrapReader_ffffffff978ef084,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit AnalyzerWrapper(jobject obj) : ::org::apache::lucene::analysis::Analyzer(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          AnalyzerWrapper(const AnalyzerWrapper& obj) : ::org::apache::lucene::analysis::Analyzer(obj) {}

          jint getOffsetGap(const ::java::lang::String &) const;
          jint getPositionIncrementGap(const ::java::lang::String &) const;
          ::java::io::Reader initReader(const ::java::lang::String &, const ::java::io::Reader &) const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(AnalyzerWrapper);
        _dll_lucene extern PyTypeObject *PY_TYPE(AnalyzerWrapper);

        class _dll_lucene t_AnalyzerWrapper {
        public:
          PyObject_HEAD
          AnalyzerWrapper object;
          static PyObject *wrap_Object(const AnalyzerWrapper&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
