#ifndef org_apache_lucene_analysis_ja_dict_UnknownDictionary_H
#define org_apache_lucene_analysis_ja_dict_UnknownDictionary_H

#include "org/apache/lucene/analysis/ja/dict/BinaryDictionary.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            class UnknownDictionary;
            class CharacterDefinition;
          }
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {

            class _dll_lucene UnknownDictionary : public ::org::apache::lucene::analysis::ja::dict::BinaryDictionary {
             public:
              enum {
                mid_getCharacterDefinition_ffffffffd5cf6fe3,
                mid_getInflectionForm_0000000026c48400,
                mid_getInflectionType_0000000026c48400,
                mid_getInstance_0000000010091e13,
                mid_getReading_ffffffffbd9d4b41,
                mid_lookup_ffffffffc9e60873,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit UnknownDictionary(jobject obj) : ::org::apache::lucene::analysis::ja::dict::BinaryDictionary(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              UnknownDictionary(const UnknownDictionary& obj) : ::org::apache::lucene::analysis::ja::dict::BinaryDictionary(obj) {}

              ::org::apache::lucene::analysis::ja::dict::CharacterDefinition getCharacterDefinition() const;
              ::java::lang::String getInflectionForm(jint) const;
              ::java::lang::String getInflectionType(jint) const;
              static UnknownDictionary getInstance();
              ::java::lang::String getReading(jint, const JArray< jchar > &, jint, jint) const;
              jint lookup(const JArray< jchar > &, jint, jint) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(UnknownDictionary);
            _dll_lucene extern PyTypeObject *PY_TYPE(UnknownDictionary);

            class _dll_lucene t_UnknownDictionary {
            public:
              PyObject_HEAD
              UnknownDictionary object;
              static PyObject *wrap_Object(const UnknownDictionary&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
