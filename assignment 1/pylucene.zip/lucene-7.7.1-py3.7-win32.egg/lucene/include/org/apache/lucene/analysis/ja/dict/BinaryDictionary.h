#ifndef org_apache_lucene_analysis_ja_dict_BinaryDictionary_H
#define org_apache_lucene_analysis_ja_dict_BinaryDictionary_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace util {
        class IntsRef;
      }
      namespace analysis {
        namespace ja {
          namespace dict {
            class Dictionary;
          }
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class InputStream;
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {

            class _dll_lucene BinaryDictionary : public ::java::lang::Object {
             public:
              enum {
                mid_getBaseForm_ffffffffbd9d4b41,
                mid_getClassResource_ffffffffa5d27992,
                mid_getInflectionForm_0000000026c48400,
                mid_getInflectionType_0000000026c48400,
                mid_getLeftId_000000007930bd1c,
                mid_getPartOfSpeech_0000000026c48400,
                mid_getPronunciation_ffffffffbd9d4b41,
                mid_getReading_ffffffffbd9d4b41,
                mid_getRightId_000000007930bd1c,
                mid_getWordCost_000000007930bd1c,
                mid_lookupWordIds_ffffffff96f5aa28,
                mid_getResource_00000000041da0eb,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit BinaryDictionary(jobject obj) : ::java::lang::Object(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              BinaryDictionary(const BinaryDictionary& obj) : ::java::lang::Object(obj) {}

              static ::java::lang::String *DICT_FILENAME_SUFFIX;
              static ::java::lang::String *DICT_HEADER;
              static jint HAS_BASEFORM;
              static jint HAS_PRONUNCIATION;
              static jint HAS_READING;
              static ::java::lang::String *POSDICT_FILENAME_SUFFIX;
              static ::java::lang::String *POSDICT_HEADER;
              static ::java::lang::String *TARGETMAP_FILENAME_SUFFIX;
              static ::java::lang::String *TARGETMAP_HEADER;
              static jint VERSION;

              ::java::lang::String getBaseForm(jint, const JArray< jchar > &, jint, jint) const;
              static ::java::io::InputStream getClassResource(const ::java::lang::Class &, const ::java::lang::String &);
              ::java::lang::String getInflectionForm(jint) const;
              ::java::lang::String getInflectionType(jint) const;
              jint getLeftId(jint) const;
              ::java::lang::String getPartOfSpeech(jint) const;
              ::java::lang::String getPronunciation(jint, const JArray< jchar > &, jint, jint) const;
              ::java::lang::String getReading(jint, const JArray< jchar > &, jint, jint) const;
              jint getRightId(jint) const;
              jint getWordCost(jint) const;
              void lookupWordIds(jint, const ::org::apache::lucene::util::IntsRef &) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(BinaryDictionary);
            _dll_lucene extern PyTypeObject *PY_TYPE(BinaryDictionary);

            class _dll_lucene t_BinaryDictionary {
            public:
              PyObject_HEAD
              BinaryDictionary object;
              static PyObject *wrap_Object(const BinaryDictionary&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
