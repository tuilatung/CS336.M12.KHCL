#ifndef org_apache_lucene_analysis_de_GermanMinimalStemFilter_H
#define org_apache_lucene_analysis_de_GermanMinimalStemFilter_H

#include "org/apache/lucene/analysis/TokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace de {

          class _dll_lucene GermanMinimalStemFilter : public ::org::apache::lucene::analysis::TokenFilter {
           public:
            enum {
              mid_init$_00000000419d1091,
              mid_incrementToken_0000000000c0c182,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit GermanMinimalStemFilter(jobject obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            GermanMinimalStemFilter(const GermanMinimalStemFilter& obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {}

            GermanMinimalStemFilter(const ::org::apache::lucene::analysis::TokenStream &);

            jboolean incrementToken() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace de {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(GermanMinimalStemFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(GermanMinimalStemFilter);

          class _dll_lucene t_GermanMinimalStemFilter {
          public:
            PyObject_HEAD
            GermanMinimalStemFilter object;
            static PyObject *wrap_Object(const GermanMinimalStemFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
