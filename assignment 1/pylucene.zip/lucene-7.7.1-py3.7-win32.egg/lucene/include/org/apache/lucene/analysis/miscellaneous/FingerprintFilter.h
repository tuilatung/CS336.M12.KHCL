#ifndef org_apache_lucene_analysis_miscellaneous_FingerprintFilter_H
#define org_apache_lucene_analysis_miscellaneous_FingerprintFilter_H

#include "org/apache/lucene/analysis/TokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene FingerprintFilter : public ::org::apache::lucene::analysis::TokenFilter {
           public:
            enum {
              mid_init$_00000000419d1091,
              mid_init$_000000000224f3a6,
              mid_end_ffffffffde902c42,
              mid_incrementToken_0000000000c0c182,
              mid_reset_ffffffffde902c42,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit FingerprintFilter(jobject obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            FingerprintFilter(const FingerprintFilter& obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {}

            static jint DEFAULT_MAX_OUTPUT_TOKEN_SIZE;
            static jchar DEFAULT_SEPARATOR;

            FingerprintFilter(const ::org::apache::lucene::analysis::TokenStream &);
            FingerprintFilter(const ::org::apache::lucene::analysis::TokenStream &, jint, jchar);

            void end() const;
            jboolean incrementToken() const;
            void reset() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(FingerprintFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(FingerprintFilter);

          class _dll_lucene t_FingerprintFilter {
          public:
            PyObject_HEAD
            FingerprintFilter object;
            static PyObject *wrap_Object(const FingerprintFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
