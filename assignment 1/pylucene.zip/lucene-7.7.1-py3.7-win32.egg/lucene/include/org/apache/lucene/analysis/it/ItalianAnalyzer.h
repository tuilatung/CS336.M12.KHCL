#ifndef org_apache_lucene_analysis_it_ItalianAnalyzer_H
#define org_apache_lucene_analysis_it_ItalianAnalyzer_H

#include "org/apache/lucene/analysis/StopwordAnalyzerBase.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArraySet;
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace it {

          class _dll_lucene ItalianAnalyzer : public ::org::apache::lucene::analysis::StopwordAnalyzerBase {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_init$_ffffffffae3a4519,
              mid_init$_ffffffffd23612ce,
              mid_getDefaultStopSet_fffffffff150072b,
              mid_normalize_000000001d1e9a51,
              mid_createComponents_000000003a09807f,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ItalianAnalyzer(jobject obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ItalianAnalyzer(const ItalianAnalyzer& obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {}

            static ::java::lang::String *DEFAULT_STOPWORD_FILE;

            ItalianAnalyzer();
            ItalianAnalyzer(const ::org::apache::lucene::analysis::CharArraySet &);
            ItalianAnalyzer(const ::org::apache::lucene::analysis::CharArraySet &, const ::org::apache::lucene::analysis::CharArraySet &);

            static ::org::apache::lucene::analysis::CharArraySet getDefaultStopSet();
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace it {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ItalianAnalyzer);
          _dll_lucene extern PyTypeObject *PY_TYPE(ItalianAnalyzer);

          class _dll_lucene t_ItalianAnalyzer {
          public:
            PyObject_HEAD
            ItalianAnalyzer object;
            static PyObject *wrap_Object(const ItalianAnalyzer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
