#ifndef org_apache_lucene_analysis_core_KeywordTokenizerFactory_H
#define org_apache_lucene_analysis_core_KeywordTokenizerFactory_H

#include "org/apache/lucene/analysis/util/TokenizerFactory.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {
          class KeywordTokenizer;
        }
      }
      namespace util {
        class AttributeFactory;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Map;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {

          class _dll_lucene KeywordTokenizerFactory : public ::org::apache::lucene::analysis::util::TokenizerFactory {
           public:
            enum {
              mid_init$_ffffffffd3ad6b94,
              mid_create_00000000137a1af6,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit KeywordTokenizerFactory(jobject obj) : ::org::apache::lucene::analysis::util::TokenizerFactory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            KeywordTokenizerFactory(const KeywordTokenizerFactory& obj) : ::org::apache::lucene::analysis::util::TokenizerFactory(obj) {}

            KeywordTokenizerFactory(const ::java::util::Map &);

            ::org::apache::lucene::analysis::core::KeywordTokenizer create(const ::org::apache::lucene::util::AttributeFactory &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(KeywordTokenizerFactory);
          _dll_lucene extern PyTypeObject *PY_TYPE(KeywordTokenizerFactory);

          class _dll_lucene t_KeywordTokenizerFactory {
          public:
            PyObject_HEAD
            KeywordTokenizerFactory object;
            static PyObject *wrap_Object(const KeywordTokenizerFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
