#ifndef org_apache_lucene_analysis_core_StopAnalyzer_H
#define org_apache_lucene_analysis_core_StopAnalyzer_H

#include "org/apache/lucene/analysis/StopwordAnalyzerBase.h"

namespace java {
  namespace lang {
    class Class;
  }
  namespace nio {
    namespace file {
      class Path;
    }
  }
  namespace io {
    class Reader;
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArraySet;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {

          class _dll_lucene StopAnalyzer : public ::org::apache::lucene::analysis::StopwordAnalyzerBase {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_init$_ffffffffac14d142,
              mid_init$_000000005ef717a4,
              mid_init$_ffffffffae3a4519,
              mid_normalize_000000001d1e9a51,
              mid_createComponents_000000003a09807f,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit StopAnalyzer(jobject obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            StopAnalyzer(const StopAnalyzer& obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {}

            static ::org::apache::lucene::analysis::CharArraySet *ENGLISH_STOP_WORDS_SET;

            StopAnalyzer();
            StopAnalyzer(const ::java::io::Reader &);
            StopAnalyzer(const ::java::nio::file::Path &);
            StopAnalyzer(const ::org::apache::lucene::analysis::CharArraySet &);
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(StopAnalyzer);
          _dll_lucene extern PyTypeObject *PY_TYPE(StopAnalyzer);

          class _dll_lucene t_StopAnalyzer {
          public:
            PyObject_HEAD
            StopAnalyzer object;
            static PyObject *wrap_Object(const StopAnalyzer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
