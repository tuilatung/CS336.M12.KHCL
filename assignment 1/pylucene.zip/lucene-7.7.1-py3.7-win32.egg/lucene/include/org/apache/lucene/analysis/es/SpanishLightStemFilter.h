#ifndef org_apache_lucene_analysis_es_SpanishLightStemFilter_H
#define org_apache_lucene_analysis_es_SpanishLightStemFilter_H

#include "org/apache/lucene/analysis/TokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace es {

          class _dll_lucene SpanishLightStemFilter : public ::org::apache::lucene::analysis::TokenFilter {
           public:
            enum {
              mid_init$_00000000419d1091,
              mid_incrementToken_0000000000c0c182,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanishLightStemFilter(jobject obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanishLightStemFilter(const SpanishLightStemFilter& obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {}

            SpanishLightStemFilter(const ::org::apache::lucene::analysis::TokenStream &);

            jboolean incrementToken() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace es {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(SpanishLightStemFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(SpanishLightStemFilter);

          class _dll_lucene t_SpanishLightStemFilter {
          public:
            PyObject_HEAD
            SpanishLightStemFilter object;
            static PyObject *wrap_Object(const SpanishLightStemFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
