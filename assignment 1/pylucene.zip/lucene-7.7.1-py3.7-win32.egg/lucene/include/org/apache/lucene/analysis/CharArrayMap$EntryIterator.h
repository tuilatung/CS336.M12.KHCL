#ifndef org_apache_lucene_analysis_CharArrayMap$EntryIterator_H
#define org_apache_lucene_analysis_CharArrayMap$EntryIterator_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Iterator;
    class Map$Entry;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene CharArrayMap$EntryIterator : public ::java::lang::Object {
         public:
          enum {
            mid_currentValue_ffffffffdcc2e1cc,
            mid_hasNext_0000000000c0c182,
            mid_next_ffffffffd4d24527,
            mid_nextKey_00000000698c608a,
            mid_nextKeyString_000000001d4fc793,
            mid_remove_ffffffffde902c42,
            mid_setValue_ffffffff8bf08471,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit CharArrayMap$EntryIterator(jobject obj) : ::java::lang::Object(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          CharArrayMap$EntryIterator(const CharArrayMap$EntryIterator& obj) : ::java::lang::Object(obj) {}

          ::java::lang::Object currentValue() const;
          jboolean hasNext() const;
          ::java::util::Map$Entry next() const;
          JArray< jchar > nextKey() const;
          ::java::lang::String nextKeyString() const;
          void remove() const;
          ::java::lang::Object setValue(const ::java::lang::Object &) const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(CharArrayMap$EntryIterator);
        _dll_lucene extern PyTypeObject *PY_TYPE(CharArrayMap$EntryIterator);

        class _dll_lucene t_CharArrayMap$EntryIterator {
        public:
          PyObject_HEAD
          CharArrayMap$EntryIterator object;
          PyTypeObject *parameters[1];
          static PyTypeObject **parameters_(t_CharArrayMap$EntryIterator *self)
          {
            return (PyTypeObject **) &(self->parameters);
          }
          static PyObject *wrap_Object(const CharArrayMap$EntryIterator&);
          static PyObject *wrap_jobject(const jobject&);
          static PyObject *wrap_Object(const CharArrayMap$EntryIterator&, PyTypeObject *);
          static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
