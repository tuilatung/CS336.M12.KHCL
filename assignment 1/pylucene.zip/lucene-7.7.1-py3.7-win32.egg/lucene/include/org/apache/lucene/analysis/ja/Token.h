#ifndef org_apache_lucene_analysis_ja_Token_H
#define org_apache_lucene_analysis_ja_Token_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            class Dictionary;
          }
          class JapaneseTokenizer$Type;
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {

          class _dll_lucene Token : public ::java::lang::Object {
           public:
            enum {
              mid_init$_00000000259a9e4d,
              mid_getBaseForm_000000001d4fc793,
              mid_getInflectionForm_000000001d4fc793,
              mid_getInflectionType_000000001d4fc793,
              mid_getLength_000000002043cb81,
              mid_getOffset_000000002043cb81,
              mid_getPartOfSpeech_000000001d4fc793,
              mid_getPosition_000000002043cb81,
              mid_getPositionLength_000000002043cb81,
              mid_getPronunciation_000000001d4fc793,
              mid_getReading_000000001d4fc793,
              mid_getSurfaceForm_00000000698c608a,
              mid_getSurfaceFormString_000000001d4fc793,
              mid_getType_fffffffff5c98365,
              mid_isKnown_0000000000c0c182,
              mid_isUnknown_0000000000c0c182,
              mid_isUser_0000000000c0c182,
              mid_setPositionLength_ffffffffa0b31ff5,
              mid_toString_000000001d4fc793,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit Token(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            Token(const Token& obj) : ::java::lang::Object(obj) {}

            Token(jint, const JArray< jchar > &, jint, jint, const ::org::apache::lucene::analysis::ja::JapaneseTokenizer$Type &, jint, const ::org::apache::lucene::analysis::ja::dict::Dictionary &);

            ::java::lang::String getBaseForm() const;
            ::java::lang::String getInflectionForm() const;
            ::java::lang::String getInflectionType() const;
            jint getLength() const;
            jint getOffset() const;
            ::java::lang::String getPartOfSpeech() const;
            jint getPosition() const;
            jint getPositionLength() const;
            ::java::lang::String getPronunciation() const;
            ::java::lang::String getReading() const;
            JArray< jchar > getSurfaceForm() const;
            ::java::lang::String getSurfaceFormString() const;
            ::org::apache::lucene::analysis::ja::JapaneseTokenizer$Type getType() const;
            jboolean isKnown() const;
            jboolean isUnknown() const;
            jboolean isUser() const;
            void setPositionLength(jint) const;
            ::java::lang::String toString() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(Token);
          _dll_lucene extern PyTypeObject *PY_TYPE(Token);

          class _dll_lucene t_Token {
          public:
            PyObject_HEAD
            Token object;
            static PyObject *wrap_Object(const Token&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
