#ifndef org_apache_lucene_analysis_CharArraySet_H
#define org_apache_lucene_analysis_CharArraySet_H

#include "java/util/AbstractSet.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class CharSequence;
    class String;
  }
  namespace util {
    class Iterator;
    class Collection;
    class Set;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArraySet;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene CharArraySet : public ::java::util::AbstractSet {
         public:
          enum {
            mid_init$_0000000004a50c27,
            mid_init$_ffffffffa5f48b8f,
            mid_add_fffffffffec8a33a,
            mid_add_ffffffffc94366ea,
            mid_add_000000007b2e38e9,
            mid_add_ffffffffc3a5efb1,
            mid_clear_ffffffffde902c42,
            mid_contains_000000007b2e38e9,
            mid_contains_fffffffffec8a33a,
            mid_contains_ffffffffd70eb951,
            mid_copy_ffffffffcf2f746e,
            mid_iterator_ffffffffafc8ac37,
            mid_size_000000002043cb81,
            mid_toString_000000001d4fc793,
            mid_unmodifiableSet_fffffffffec421e3,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit CharArraySet(jobject obj) : ::java::util::AbstractSet(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          CharArraySet(const CharArraySet& obj) : ::java::util::AbstractSet(obj) {}

          static CharArraySet *EMPTY_SET;

          CharArraySet(const ::java::util::Collection &, jboolean);
          CharArraySet(jint, jboolean);

          jboolean add(const ::java::lang::CharSequence &) const;
          jboolean add(const ::java::lang::String &) const;
          jboolean add(const ::java::lang::Object &) const;
          jboolean add(const JArray< jchar > &) const;
          void clear() const;
          jboolean contains(const ::java::lang::Object &) const;
          jboolean contains(const ::java::lang::CharSequence &) const;
          jboolean contains(const JArray< jchar > &, jint, jint) const;
          static CharArraySet copy(const ::java::util::Set &);
          ::java::util::Iterator iterator() const;
          jint size() const;
          ::java::lang::String toString() const;
          static CharArraySet unmodifiableSet(const CharArraySet &);
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(CharArraySet);
        _dll_lucene extern PyTypeObject *PY_TYPE(CharArraySet);

        class _dll_lucene t_CharArraySet {
        public:
          PyObject_HEAD
          CharArraySet object;
          PyTypeObject *parameters[1];
          static PyTypeObject **parameters_(t_CharArraySet *self)
          {
            return (PyTypeObject **) &(self->parameters);
          }
          static PyObject *wrap_Object(const CharArraySet&);
          static PyObject *wrap_jobject(const jobject&);
          static PyObject *wrap_Object(const CharArraySet&, PyTypeObject *);
          static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
