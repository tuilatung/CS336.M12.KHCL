#ifndef org_apache_lucene_analysis_CharacterUtils_H
#define org_apache_lucene_analysis_CharacterUtils_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharacterUtils$CharacterBuffer;
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
    class Reader;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene CharacterUtils : public ::java::lang::Object {
         public:
          enum {
            mid_fill_ffffffffadcdb455,
            mid_fill_00000000039d0f00,
            mid_newCharacterBuffer_fffffffff3b3d3e9,
            mid_toChars_ffffffff8e018e9b,
            mid_toCodePoints_00000000332dc779,
            mid_toLowerCase_0000000052290416,
            mid_toUpperCase_0000000052290416,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit CharacterUtils(jobject obj) : ::java::lang::Object(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          CharacterUtils(const CharacterUtils& obj) : ::java::lang::Object(obj) {}

          static jboolean fill(const ::org::apache::lucene::analysis::CharacterUtils$CharacterBuffer &, const ::java::io::Reader &);
          static jboolean fill(const ::org::apache::lucene::analysis::CharacterUtils$CharacterBuffer &, const ::java::io::Reader &, jint);
          static ::org::apache::lucene::analysis::CharacterUtils$CharacterBuffer newCharacterBuffer(jint);
          static jint toChars(const JArray< jint > &, jint, jint, const JArray< jchar > &, jint);
          static jint toCodePoints(const JArray< jchar > &, jint, jint, const JArray< jint > &, jint);
          static void toLowerCase(const JArray< jchar > &, jint, jint);
          static void toUpperCase(const JArray< jchar > &, jint, jint);
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(CharacterUtils);
        _dll_lucene extern PyTypeObject *PY_TYPE(CharacterUtils);

        class _dll_lucene t_CharacterUtils {
        public:
          PyObject_HEAD
          CharacterUtils object;
          static PyObject *wrap_Object(const CharacterUtils&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
