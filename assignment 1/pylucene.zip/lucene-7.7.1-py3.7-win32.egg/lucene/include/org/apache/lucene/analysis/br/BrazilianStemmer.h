#ifndef org_apache_lucene_analysis_br_BrazilianStemmer_H
#define org_apache_lucene_analysis_br_BrazilianStemmer_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace br {

          class _dll_lucene BrazilianStemmer : public ::java::lang::Object {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_log_000000001d4fc793,
              mid_stem_ffffffffbf6eae52,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit BrazilianStemmer(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            BrazilianStemmer(const BrazilianStemmer& obj) : ::java::lang::Object(obj) {}

            BrazilianStemmer();

            ::java::lang::String log() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace br {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(BrazilianStemmer);
          _dll_lucene extern PyTypeObject *PY_TYPE(BrazilianStemmer);

          class _dll_lucene t_BrazilianStemmer {
          public:
            PyObject_HEAD
            BrazilianStemmer object;
            static PyObject *wrap_Object(const BrazilianStemmer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
