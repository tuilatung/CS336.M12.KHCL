#ifndef org_apache_lucene_analysis_ja_JapaneseIterationMarkCharFilterFactory_H
#define org_apache_lucene_analysis_ja_JapaneseIterationMarkCharFilterFactory_H

#include "org/apache/lucene/analysis/util/CharFilterFactory.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class Reader;
  }
  namespace util {
    class Map;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace util {
          class AbstractAnalysisFactory;
          class MultiTermAwareComponent;
        }
        class CharFilter;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {

          class _dll_lucene JapaneseIterationMarkCharFilterFactory : public ::org::apache::lucene::analysis::util::CharFilterFactory {
           public:
            enum {
              mid_init$_ffffffffd3ad6b94,
              mid_create_ffffffffb0617eb6,
              mid_getMultiTermComponent_000000002950e407,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit JapaneseIterationMarkCharFilterFactory(jobject obj) : ::org::apache::lucene::analysis::util::CharFilterFactory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            JapaneseIterationMarkCharFilterFactory(const JapaneseIterationMarkCharFilterFactory& obj) : ::org::apache::lucene::analysis::util::CharFilterFactory(obj) {}

            JapaneseIterationMarkCharFilterFactory(const ::java::util::Map &);

            ::org::apache::lucene::analysis::CharFilter create(const ::java::io::Reader &) const;
            ::org::apache::lucene::analysis::util::AbstractAnalysisFactory getMultiTermComponent() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(JapaneseIterationMarkCharFilterFactory);
          _dll_lucene extern PyTypeObject *PY_TYPE(JapaneseIterationMarkCharFilterFactory);

          class _dll_lucene t_JapaneseIterationMarkCharFilterFactory {
          public:
            PyObject_HEAD
            JapaneseIterationMarkCharFilterFactory object;
            static PyObject *wrap_Object(const JapaneseIterationMarkCharFilterFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
