#ifndef org_apache_lucene_analysis_ja_dict_ConnectionCosts_H
#define org_apache_lucene_analysis_ja_dict_ConnectionCosts_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            class ConnectionCosts;
          }
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {

            class _dll_lucene ConnectionCosts : public ::java::lang::Object {
             public:
              enum {
                mid_get_ffffffffbefe0b2f,
                mid_getInstance_00000000154bad35,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit ConnectionCosts(jobject obj) : ::java::lang::Object(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              ConnectionCosts(const ConnectionCosts& obj) : ::java::lang::Object(obj) {}

              static ::java::lang::String *FILENAME_SUFFIX;
              static ::java::lang::String *HEADER;
              static jint VERSION;

              jint get(jint, jint) const;
              static ConnectionCosts getInstance();
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(ConnectionCosts);
            _dll_lucene extern PyTypeObject *PY_TYPE(ConnectionCosts);

            class _dll_lucene t_ConnectionCosts {
            public:
              PyObject_HEAD
              ConnectionCosts object;
              static PyObject *wrap_Object(const ConnectionCosts&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
