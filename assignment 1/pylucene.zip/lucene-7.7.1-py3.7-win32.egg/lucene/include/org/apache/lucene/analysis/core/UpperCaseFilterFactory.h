#ifndef org_apache_lucene_analysis_core_UpperCaseFilterFactory_H
#define org_apache_lucene_analysis_core_UpperCaseFilterFactory_H

#include "org/apache/lucene/analysis/util/TokenFilterFactory.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {
          class UpperCaseFilter;
        }
        namespace util {
          class AbstractAnalysisFactory;
          class MultiTermAwareComponent;
        }
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Map;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {

          class _dll_lucene UpperCaseFilterFactory : public ::org::apache::lucene::analysis::util::TokenFilterFactory {
           public:
            enum {
              mid_init$_ffffffffd3ad6b94,
              mid_create_0000000042503a76,
              mid_getMultiTermComponent_000000002950e407,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit UpperCaseFilterFactory(jobject obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            UpperCaseFilterFactory(const UpperCaseFilterFactory& obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {}

            UpperCaseFilterFactory(const ::java::util::Map &);

            ::org::apache::lucene::analysis::core::UpperCaseFilter create(const ::org::apache::lucene::analysis::TokenStream &) const;
            ::org::apache::lucene::analysis::util::AbstractAnalysisFactory getMultiTermComponent() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(UpperCaseFilterFactory);
          _dll_lucene extern PyTypeObject *PY_TYPE(UpperCaseFilterFactory);

          class _dll_lucene t_UpperCaseFilterFactory {
          public:
            PyObject_HEAD
            UpperCaseFilterFactory object;
            static PyObject *wrap_Object(const UpperCaseFilterFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
