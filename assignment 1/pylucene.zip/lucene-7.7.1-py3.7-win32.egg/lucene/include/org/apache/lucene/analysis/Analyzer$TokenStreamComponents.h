#ifndef org_apache_lucene_analysis_Analyzer$TokenStreamComponents_H
#define org_apache_lucene_analysis_Analyzer$TokenStreamComponents_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class Tokenizer;
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene Analyzer$TokenStreamComponents : public ::java::lang::Object {
         public:
          enum {
            mid_init$_0000000036bdfb79,
            mid_init$_0000000078ac25c3,
            mid_getTokenStream_00000000601adab3,
            mid_getTokenizer_ffffffff850258c8,
            mid_setReader_ffffffffac14d142,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit Analyzer$TokenStreamComponents(jobject obj) : ::java::lang::Object(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          Analyzer$TokenStreamComponents(const Analyzer$TokenStreamComponents& obj) : ::java::lang::Object(obj) {}

          Analyzer$TokenStreamComponents(const ::org::apache::lucene::analysis::Tokenizer &);
          Analyzer$TokenStreamComponents(const ::org::apache::lucene::analysis::Tokenizer &, const ::org::apache::lucene::analysis::TokenStream &);

          ::org::apache::lucene::analysis::TokenStream getTokenStream() const;
          ::org::apache::lucene::analysis::Tokenizer getTokenizer() const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(Analyzer$TokenStreamComponents);
        _dll_lucene extern PyTypeObject *PY_TYPE(Analyzer$TokenStreamComponents);

        class _dll_lucene t_Analyzer$TokenStreamComponents {
        public:
          PyObject_HEAD
          Analyzer$TokenStreamComponents object;
          static PyObject *wrap_Object(const Analyzer$TokenStreamComponents&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
