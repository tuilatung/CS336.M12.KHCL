#ifndef org_apache_lucene_analysis_CharArrayMap_H
#define org_apache_lucene_analysis_CharArrayMap_H

#include "java/util/AbstractMap.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class CharSequence;
    class String;
  }
  namespace util {
    class Map;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArrayMap;
        class CharArrayMap$EntrySet;
        class CharArraySet;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene CharArrayMap : public ::java::util::AbstractMap {
         public:
          enum {
            mid_init$_000000002dd46152,
            mid_init$_ffffffffa5f48b8f,
            mid_clear_ffffffffde902c42,
            mid_containsKey_000000007b2e38e9,
            mid_containsKey_fffffffffec8a33a,
            mid_containsKey_ffffffffd70eb951,
            mid_copy_00000000652896b7,
            mid_emptyMap_000000001e5f944c,
            mid_entrySet_000000007e5e54cf,
            mid_get_ffffffffe269712e,
            mid_get_ffffffff8bf08471,
            mid_get_000000002c74892b,
            mid_keySet_fffffffff150072b,
            mid_put_000000007b65518b,
            mid_put_ffffffffb36203b8,
            mid_put_ffffffffd29d9423,
            mid_put_ffffffff8c9373d4,
            mid_remove_ffffffff8bf08471,
            mid_size_000000002043cb81,
            mid_toString_000000001d4fc793,
            mid_unmodifiableMap_ffffffff9c469640,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit CharArrayMap(jobject obj) : ::java::util::AbstractMap(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          CharArrayMap(const CharArrayMap& obj) : ::java::util::AbstractMap(obj) {}

          CharArrayMap(const ::java::util::Map &, jboolean);
          CharArrayMap(jint, jboolean);

          void clear() const;
          jboolean containsKey(const ::java::lang::Object &) const;
          jboolean containsKey(const ::java::lang::CharSequence &) const;
          jboolean containsKey(const JArray< jchar > &, jint, jint) const;
          static CharArrayMap copy(const ::java::util::Map &);
          static CharArrayMap emptyMap();
          ::org::apache::lucene::analysis::CharArrayMap$EntrySet entrySet() const;
          ::java::lang::Object get(const ::java::lang::CharSequence &) const;
          ::java::lang::Object get(const ::java::lang::Object &) const;
          ::java::lang::Object get(const JArray< jchar > &, jint, jint) const;
          ::org::apache::lucene::analysis::CharArraySet keySet() const;
          ::java::lang::Object put(const JArray< jchar > &, const ::java::lang::Object &) const;
          ::java::lang::Object put(const ::java::lang::CharSequence &, const ::java::lang::Object &) const;
          ::java::lang::Object put(const ::java::lang::Object &, const ::java::lang::Object &) const;
          ::java::lang::Object put(const ::java::lang::String &, const ::java::lang::Object &) const;
          ::java::lang::Object remove(const ::java::lang::Object &) const;
          jint size() const;
          ::java::lang::String toString() const;
          static CharArrayMap unmodifiableMap(const CharArrayMap &);
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(CharArrayMap);
        _dll_lucene extern PyTypeObject *PY_TYPE(CharArrayMap);

        class _dll_lucene t_CharArrayMap {
        public:
          PyObject_HEAD
          CharArrayMap object;
          PyTypeObject *parameters[1];
          static PyTypeObject **parameters_(t_CharArrayMap *self)
          {
            return (PyTypeObject **) &(self->parameters);
          }
          static PyObject *wrap_Object(const CharArrayMap&);
          static PyObject *wrap_jobject(const jobject&);
          static PyObject *wrap_Object(const CharArrayMap&, PyTypeObject *);
          static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
