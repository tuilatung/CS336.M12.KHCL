#ifndef org_apache_lucene_analysis_compound_hyphenation_CharVector_H
#define org_apache_lucene_analysis_compound_hyphenation_CharVector_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Cloneable;
    class Class;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            class CharVector;
          }
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {

            class _dll_lucene CharVector : public ::java::lang::Object {
             public:
              enum {
                mid_init$_ffffffffde902c42,
                mid_init$_ffffffffa23b19d5,
                mid_init$_ffffffffa0b31ff5,
                mid_init$_00000000391c5b33,
                mid_alloc_000000007930bd1c,
                mid_capacity_000000002043cb81,
                mid_clear_ffffffffde902c42,
                mid_clone_ffffffffbf97710a,
                mid_get_000000007fc4e57c,
                mid_getArray_00000000698c608a,
                mid_length_000000002043cb81,
                mid_put_00000000680774e8,
                mid_trimToSize_ffffffffde902c42,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit CharVector(jobject obj) : ::java::lang::Object(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              CharVector(const CharVector& obj) : ::java::lang::Object(obj) {}

              CharVector();
              CharVector(const JArray< jchar > &);
              CharVector(jint);
              CharVector(const JArray< jchar > &, jint);

              jint alloc(jint) const;
              jint capacity() const;
              void clear() const;
              CharVector clone() const;
              jchar get(jint) const;
              JArray< jchar > getArray() const;
              jint length() const;
              void put(jint, jchar) const;
              void trimToSize() const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(CharVector);
            _dll_lucene extern PyTypeObject *PY_TYPE(CharVector);

            class _dll_lucene t_CharVector {
            public:
              PyObject_HEAD
              CharVector object;
              static PyObject *wrap_Object(const CharVector&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
