#ifndef org_apache_lucene_analysis_en_PorterStemFilterFactory_H
#define org_apache_lucene_analysis_en_PorterStemFilterFactory_H

#include "org/apache/lucene/analysis/util/TokenFilterFactory.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Map;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace en {
          class PorterStemFilter;
        }
        class TokenStream;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace en {

          class _dll_lucene PorterStemFilterFactory : public ::org::apache::lucene::analysis::util::TokenFilterFactory {
           public:
            enum {
              mid_init$_ffffffffd3ad6b94,
              mid_create_ffffffffa39a41bc,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit PorterStemFilterFactory(jobject obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            PorterStemFilterFactory(const PorterStemFilterFactory& obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {}

            PorterStemFilterFactory(const ::java::util::Map &);

            ::org::apache::lucene::analysis::en::PorterStemFilter create(const ::org::apache::lucene::analysis::TokenStream &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace en {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(PorterStemFilterFactory);
          _dll_lucene extern PyTypeObject *PY_TYPE(PorterStemFilterFactory);

          class _dll_lucene t_PorterStemFilterFactory {
          public:
            PyObject_HEAD
            PorterStemFilterFactory object;
            static PyObject *wrap_Object(const PorterStemFilterFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
