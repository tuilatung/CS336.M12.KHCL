#ifndef org_apache_lucene_analysis_miscellaneous_LimitTokenOffsetFilter_H
#define org_apache_lucene_analysis_miscellaneous_LimitTokenOffsetFilter_H

#include "org/apache/lucene/analysis/TokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene LimitTokenOffsetFilter : public ::org::apache::lucene::analysis::TokenFilter {
           public:
            enum {
              mid_init$_ffffffffb3193075,
              mid_init$_ffffffff9cbaeec1,
              mid_incrementToken_0000000000c0c182,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit LimitTokenOffsetFilter(jobject obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            LimitTokenOffsetFilter(const LimitTokenOffsetFilter& obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {}

            LimitTokenOffsetFilter(const ::org::apache::lucene::analysis::TokenStream &, jint);
            LimitTokenOffsetFilter(const ::org::apache::lucene::analysis::TokenStream &, jint, jboolean);

            jboolean incrementToken() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(LimitTokenOffsetFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(LimitTokenOffsetFilter);

          class _dll_lucene t_LimitTokenOffsetFilter {
          public:
            PyObject_HEAD
            LimitTokenOffsetFilter object;
            static PyObject *wrap_Object(const LimitTokenOffsetFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
