#ifndef org_apache_lucene_analysis_de_GermanStemFilter_H
#define org_apache_lucene_analysis_de_GermanStemFilter_H

#include "org/apache/lucene/analysis/TokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace de {
          class GermanStemmer;
        }
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace de {

          class _dll_lucene GermanStemFilter : public ::org::apache::lucene::analysis::TokenFilter {
           public:
            enum {
              mid_init$_00000000419d1091,
              mid_incrementToken_0000000000c0c182,
              mid_setStemmer_0000000012c12aa4,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit GermanStemFilter(jobject obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            GermanStemFilter(const GermanStemFilter& obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {}

            GermanStemFilter(const ::org::apache::lucene::analysis::TokenStream &);

            jboolean incrementToken() const;
            void setStemmer(const ::org::apache::lucene::analysis::de::GermanStemmer &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace de {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(GermanStemFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(GermanStemFilter);

          class _dll_lucene t_GermanStemFilter {
          public:
            PyObject_HEAD
            GermanStemFilter object;
            static PyObject *wrap_Object(const GermanStemFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
