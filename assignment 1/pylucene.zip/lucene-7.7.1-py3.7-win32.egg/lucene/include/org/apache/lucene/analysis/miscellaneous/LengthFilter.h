#ifndef org_apache_lucene_analysis_miscellaneous_LengthFilter_H
#define org_apache_lucene_analysis_miscellaneous_LengthFilter_H

#include "org/apache/lucene/analysis/FilteringTokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene LengthFilter : public ::org::apache::lucene::analysis::FilteringTokenFilter {
           public:
            enum {
              mid_init$_ffffffffb487ce0e,
              mid_accept_0000000000c0c182,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit LengthFilter(jobject obj) : ::org::apache::lucene::analysis::FilteringTokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            LengthFilter(const LengthFilter& obj) : ::org::apache::lucene::analysis::FilteringTokenFilter(obj) {}

            LengthFilter(const ::org::apache::lucene::analysis::TokenStream &, jint, jint);

            jboolean accept() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(LengthFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(LengthFilter);

          class _dll_lucene t_LengthFilter {
          public:
            PyObject_HEAD
            LengthFilter object;
            static PyObject *wrap_Object(const LengthFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
