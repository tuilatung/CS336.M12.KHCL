#ifndef org_apache_lucene_analysis_ja_JapaneseTokenizer_H
#define org_apache_lucene_analysis_ja_JapaneseTokenizer_H

#include "org/apache/lucene/analysis/Tokenizer.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          class GraphvizFormatter;
          namespace dict {
            class UserDictionary;
          }
          class JapaneseTokenizer$Mode;
        }
      }
      namespace util {
        class AttributeFactory;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {

          class _dll_lucene JapaneseTokenizer : public ::org::apache::lucene::analysis::Tokenizer {
           public:
            enum {
              mid_init$_ffffffffe3e770f7,
              mid_init$_ffffffffed0c4f69,
              mid_calcNBestCost_0000000026f4dfbe,
              mid_close_ffffffffde902c42,
              mid_end_ffffffffde902c42,
              mid_incrementToken_0000000000c0c182,
              mid_reset_ffffffffde902c42,
              mid_setGraphvizFormatter_000000007be51c42,
              mid_setNBestCost_ffffffffa0b31ff5,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit JapaneseTokenizer(jobject obj) : ::org::apache::lucene::analysis::Tokenizer(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            JapaneseTokenizer(const JapaneseTokenizer& obj) : ::org::apache::lucene::analysis::Tokenizer(obj) {}

            static ::org::apache::lucene::analysis::ja::JapaneseTokenizer$Mode *DEFAULT_MODE;

            JapaneseTokenizer(const ::org::apache::lucene::analysis::ja::dict::UserDictionary &, jboolean, const ::org::apache::lucene::analysis::ja::JapaneseTokenizer$Mode &);
            JapaneseTokenizer(const ::org::apache::lucene::util::AttributeFactory &, const ::org::apache::lucene::analysis::ja::dict::UserDictionary &, jboolean, const ::org::apache::lucene::analysis::ja::JapaneseTokenizer$Mode &);

            jint calcNBestCost(const ::java::lang::String &) const;
            void close() const;
            void end() const;
            jboolean incrementToken() const;
            void reset() const;
            void setGraphvizFormatter(const ::org::apache::lucene::analysis::ja::GraphvizFormatter &) const;
            void setNBestCost(jint) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(JapaneseTokenizer);
          _dll_lucene extern PyTypeObject *PY_TYPE(JapaneseTokenizer);

          class _dll_lucene t_JapaneseTokenizer {
          public:
            PyObject_HEAD
            JapaneseTokenizer object;
            static PyObject *wrap_Object(const JapaneseTokenizer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
