#ifndef org_apache_lucene_analysis_compound_hyphenation_TernaryTree_H
#define org_apache_lucene_analysis_compound_hyphenation_TernaryTree_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            class TernaryTree;
          }
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class Cloneable;
    class String;
  }
  namespace util {
    class Enumeration;
  }
  namespace io {
    class PrintStream;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {

            class _dll_lucene TernaryTree : public ::java::lang::Object {
             public:
              enum {
                mid_balance_ffffffffde902c42,
                mid_clone_ffffffffed6ac8b7,
                mid_find_0000000026f4dfbe,
                mid_find_000000004bc20cb9,
                mid_insert_ffffffff8a4480a3,
                mid_insert_0000000023016cab,
                mid_keys_000000003fb08ac2,
                mid_knows_ffffffffc94366ea,
                mid_printStats_0000000065dd8cbc,
                mid_size_000000002043cb81,
                mid_strcmp_000000003293556e,
                mid_strcmp_0000000019fed13c,
                mid_strcpy_00000000535e708c,
                mid_strlen_0000000015233544,
                mid_strlen_000000004bc20cb9,
                mid_trimToSize_ffffffffde902c42,
                mid_init_ffffffffde902c42,
                mid_insertBalanced_ffffffffc2bfad33,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit TernaryTree(jobject obj) : ::java::lang::Object(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              TernaryTree(const TernaryTree& obj) : ::java::lang::Object(obj) {}

              void balance() const;
              TernaryTree clone() const;
              jint find(const ::java::lang::String &) const;
              jint find(const JArray< jchar > &, jint) const;
              void insert(const ::java::lang::String &, jchar) const;
              void insert(const JArray< jchar > &, jint, jchar) const;
              ::java::util::Enumeration keys() const;
              jboolean knows(const ::java::lang::String &) const;
              void printStats(const ::java::io::PrintStream &) const;
              jint size() const;
              static jint strcmp(const ::java::lang::String &, const JArray< jchar > &, jint);
              static jint strcmp(const JArray< jchar > &, jint, const JArray< jchar > &, jint);
              static void strcpy(const JArray< jchar > &, jint, const JArray< jchar > &, jint);
              static jint strlen(const JArray< jchar > &);
              static jint strlen(const JArray< jchar > &, jint);
              void trimToSize() const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(TernaryTree);
            _dll_lucene extern PyTypeObject *PY_TYPE(TernaryTree);

            class _dll_lucene t_TernaryTree {
            public:
              PyObject_HEAD
              TernaryTree object;
              static PyObject *wrap_Object(const TernaryTree&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
