#ifndef org_apache_lucene_analysis_charfilter_HTMLStripCharFilter_H
#define org_apache_lucene_analysis_charfilter_HTMLStripCharFilter_H

#include "org/apache/lucene/analysis/charfilter/BaseCharFilter.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class Reader;
    class IOException;
  }
  namespace util {
    class Set;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace charfilter {

          class _dll_lucene HTMLStripCharFilter : public ::org::apache::lucene::analysis::charfilter::BaseCharFilter {
           public:
            enum {
              mid_init$_ffffffffac14d142,
              mid_init$_00000000189eaad0,
              mid_close_ffffffffde902c42,
              mid_read_000000002043cb81,
              mid_read_ffffffffc9e60873,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit HTMLStripCharFilter(jobject obj) : ::org::apache::lucene::analysis::charfilter::BaseCharFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            HTMLStripCharFilter(const HTMLStripCharFilter& obj) : ::org::apache::lucene::analysis::charfilter::BaseCharFilter(obj) {}

            HTMLStripCharFilter(const ::java::io::Reader &);
            HTMLStripCharFilter(const ::java::io::Reader &, const ::java::util::Set &);

            void close() const;
            jint read() const;
            jint read(const JArray< jchar > &, jint, jint) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace charfilter {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(HTMLStripCharFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(HTMLStripCharFilter);

          class _dll_lucene t_HTMLStripCharFilter {
          public:
            PyObject_HEAD
            HTMLStripCharFilter object;
            static PyObject *wrap_Object(const HTMLStripCharFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
