#ifndef org_apache_lucene_analysis_CharFilter_H
#define org_apache_lucene_analysis_CharFilter_H

#include "java/io/Reader.h"

namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene CharFilter : public ::java::io::Reader {
         public:
          enum {
            mid_init$_ffffffffac14d142,
            mid_close_ffffffffde902c42,
            mid_correctOffset_000000007930bd1c,
            mid_correct_000000007930bd1c,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit CharFilter(jobject obj) : ::java::io::Reader(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          CharFilter(const CharFilter& obj) : ::java::io::Reader(obj) {}

          CharFilter(const ::java::io::Reader &);

          void close() const;
          jint correctOffset(jint) const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(CharFilter);
        _dll_lucene extern PyTypeObject *PY_TYPE(CharFilter);

        class _dll_lucene t_CharFilter {
        public:
          PyObject_HEAD
          CharFilter object;
          static PyObject *wrap_Object(const CharFilter&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
