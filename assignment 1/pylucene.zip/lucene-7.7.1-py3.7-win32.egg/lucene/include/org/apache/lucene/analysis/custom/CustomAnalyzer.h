#ifndef org_apache_lucene_analysis_custom_CustomAnalyzer_H
#define org_apache_lucene_analysis_custom_CustomAnalyzer_H

#include "org/apache/lucene/analysis/Analyzer.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace nio {
    namespace file {
      class Path;
    }
  }
  namespace util {
    class List;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace util {
          class TokenizerFactory;
          class CharFilterFactory;
          class TokenFilterFactory;
          class ResourceLoader;
        }
        namespace custom {
          class CustomAnalyzer$Builder;
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace custom {

          class _dll_lucene CustomAnalyzer : public ::org::apache::lucene::analysis::Analyzer {
           public:
            enum {
              mid_builder_00000000514284be,
              mid_builder_0000000044353421,
              mid_builder_0000000077f5c503,
              mid_getCharFilterFactories_ffffffffbf1ee3ce,
              mid_getOffsetGap_0000000026f4dfbe,
              mid_getPositionIncrementGap_0000000026f4dfbe,
              mid_getTokenFilterFactories_ffffffffbf1ee3ce,
              mid_getTokenizerFactory_ffffffffd2204438,
              mid_toString_000000001d4fc793,
              mid_normalize_000000001d1e9a51,
              mid_initReader_ffffffff978ef084,
              mid_createComponents_000000003a09807f,
              mid_initReaderForNormalization_ffffffff978ef084,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit CustomAnalyzer(jobject obj) : ::org::apache::lucene::analysis::Analyzer(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            CustomAnalyzer(const CustomAnalyzer& obj) : ::org::apache::lucene::analysis::Analyzer(obj) {}

            static ::org::apache::lucene::analysis::custom::CustomAnalyzer$Builder builder();
            static ::org::apache::lucene::analysis::custom::CustomAnalyzer$Builder builder(const ::java::nio::file::Path &);
            static ::org::apache::lucene::analysis::custom::CustomAnalyzer$Builder builder(const ::org::apache::lucene::analysis::util::ResourceLoader &);
            ::java::util::List getCharFilterFactories() const;
            jint getOffsetGap(const ::java::lang::String &) const;
            jint getPositionIncrementGap(const ::java::lang::String &) const;
            ::java::util::List getTokenFilterFactories() const;
            ::org::apache::lucene::analysis::util::TokenizerFactory getTokenizerFactory() const;
            ::java::lang::String toString() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace custom {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(CustomAnalyzer);
          _dll_lucene extern PyTypeObject *PY_TYPE(CustomAnalyzer);

          class _dll_lucene t_CustomAnalyzer {
          public:
            PyObject_HEAD
            CustomAnalyzer object;
            static PyObject *wrap_Object(const CustomAnalyzer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
