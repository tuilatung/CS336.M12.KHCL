#ifndef org_apache_lucene_analysis_compound_hyphenation_ByteVector_H
#define org_apache_lucene_analysis_compound_hyphenation_ByteVector_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {

            class _dll_lucene ByteVector : public ::java::lang::Object {
             public:
              enum {
                mid_init$_ffffffffde902c42,
                mid_init$_0000000038c78f53,
                mid_init$_ffffffffa0b31ff5,
                mid_init$_ffffffff98ab79e7,
                mid_alloc_000000007930bd1c,
                mid_capacity_000000002043cb81,
                mid_get_00000000650b48f4,
                mid_getArray_000000007043ab9b,
                mid_length_000000002043cb81,
                mid_put_0000000032a7e59e,
                mid_trimToSize_ffffffffde902c42,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit ByteVector(jobject obj) : ::java::lang::Object(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              ByteVector(const ByteVector& obj) : ::java::lang::Object(obj) {}

              ByteVector();
              ByteVector(const JArray< jbyte > &);
              ByteVector(jint);
              ByteVector(const JArray< jbyte > &, jint);

              jint alloc(jint) const;
              jint capacity() const;
              jbyte get(jint) const;
              JArray< jbyte > getArray() const;
              jint length() const;
              void put(jint, jbyte) const;
              void trimToSize() const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(ByteVector);
            _dll_lucene extern PyTypeObject *PY_TYPE(ByteVector);

            class _dll_lucene t_ByteVector {
            public:
              PyObject_HEAD
              ByteVector object;
              static PyObject *wrap_Object(const ByteVector&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
