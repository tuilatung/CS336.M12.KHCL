#ifndef org_apache_lucene_analysis_in_IndicNormalizationFilter_H
#define org_apache_lucene_analysis_in_IndicNormalizationFilter_H

#include "org/apache/lucene/analysis/TokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace in {

          class _dll_lucene IndicNormalizationFilter : public ::org::apache::lucene::analysis::TokenFilter {
           public:
            enum {
              mid_init$_00000000419d1091,
              mid_incrementToken_0000000000c0c182,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit IndicNormalizationFilter(jobject obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            IndicNormalizationFilter(const IndicNormalizationFilter& obj) : ::org::apache::lucene::analysis::TokenFilter(obj) {}

            IndicNormalizationFilter(const ::org::apache::lucene::analysis::TokenStream &);

            jboolean incrementToken() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace in {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(IndicNormalizationFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(IndicNormalizationFilter);

          class _dll_lucene t_IndicNormalizationFilter {
          public:
            PyObject_HEAD
            IndicNormalizationFilter object;
            static PyObject *wrap_Object(const IndicNormalizationFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
