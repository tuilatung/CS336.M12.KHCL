#ifndef org_apache_lucene_analysis_compound_hyphenation_HyphenationTree_H
#define org_apache_lucene_analysis_compound_hyphenation_HyphenationTree_H

#include "org/apache/lucene/analysis/compound/hyphenation/TernaryTree.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class String;
  }
  namespace util {
    class ArrayList;
  }
  namespace io {
    class PrintStream;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            class PatternConsumer;
            class Hyphenation;
          }
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {

            class _dll_lucene HyphenationTree : public ::org::apache::lucene::analysis::compound::hyphenation::TernaryTree {
             public:
              enum {
                mid_init$_ffffffffde902c42,
                mid_addClass_0000000048822f5e,
                mid_addException_000000003e23eaf5,
                mid_addPattern_ffffffffea5c5690,
                mid_findPattern_ffffffffbf6eae52,
                mid_hyphenate_000000005097ae73,
                mid_hyphenate_000000000f998a9e,
                mid_printStats_0000000065dd8cbc,
                mid_getValues_00000000708503f6,
                mid_unpackValues_0000000026c48400,
                mid_searchPatterns_000000005e5aab7f,
                mid_packValues_0000000026f4dfbe,
                mid_hstrcmp_0000000019fed13c,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit HyphenationTree(jobject obj) : ::org::apache::lucene::analysis::compound::hyphenation::TernaryTree(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              HyphenationTree(const HyphenationTree& obj) : ::org::apache::lucene::analysis::compound::hyphenation::TernaryTree(obj) {}

              HyphenationTree();

              void addClass(const ::java::lang::String &) const;
              void addException(const ::java::lang::String &, const ::java::util::ArrayList &) const;
              void addPattern(const ::java::lang::String &, const ::java::lang::String &) const;
              ::java::lang::String findPattern(const ::java::lang::String &) const;
              ::org::apache::lucene::analysis::compound::hyphenation::Hyphenation hyphenate(const ::java::lang::String &, jint, jint) const;
              ::org::apache::lucene::analysis::compound::hyphenation::Hyphenation hyphenate(const JArray< jchar > &, jint, jint, jint, jint) const;
              void printStats(const ::java::io::PrintStream &) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(HyphenationTree);
            _dll_lucene extern PyTypeObject *PY_TYPE(HyphenationTree);

            class _dll_lucene t_HyphenationTree {
            public:
              PyObject_HEAD
              HyphenationTree object;
              static PyObject *wrap_Object(const HyphenationTree&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
