#ifndef org_apache_lucene_analysis_ja_tokenattributes_BaseFormAttributeImpl_H
#define org_apache_lucene_analysis_ja_tokenattributes_BaseFormAttributeImpl_H

#include "org/apache/lucene/util/AttributeImpl.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace tokenattributes {
            class BaseFormAttribute;
          }
          class Token;
        }
      }
      namespace util {
        class AttributeReflector;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace tokenattributes {

            class _dll_lucene BaseFormAttributeImpl : public ::org::apache::lucene::util::AttributeImpl {
             public:
              enum {
                mid_init$_ffffffffde902c42,
                mid_clear_ffffffffde902c42,
                mid_copyTo_ffffffff87731181,
                mid_getBaseForm_000000001d4fc793,
                mid_reflectWith_000000007ae09ba8,
                mid_setToken_0000000018b314d4,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit BaseFormAttributeImpl(jobject obj) : ::org::apache::lucene::util::AttributeImpl(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              BaseFormAttributeImpl(const BaseFormAttributeImpl& obj) : ::org::apache::lucene::util::AttributeImpl(obj) {}

              BaseFormAttributeImpl();

              void clear() const;
              void copyTo(const ::org::apache::lucene::util::AttributeImpl &) const;
              ::java::lang::String getBaseForm() const;
              void reflectWith(const ::org::apache::lucene::util::AttributeReflector &) const;
              void setToken(const ::org::apache::lucene::analysis::ja::Token &) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace tokenattributes {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(BaseFormAttributeImpl);
            _dll_lucene extern PyTypeObject *PY_TYPE(BaseFormAttributeImpl);

            class _dll_lucene t_BaseFormAttributeImpl {
            public:
              PyObject_HEAD
              BaseFormAttributeImpl object;
              static PyObject *wrap_Object(const BaseFormAttributeImpl&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
