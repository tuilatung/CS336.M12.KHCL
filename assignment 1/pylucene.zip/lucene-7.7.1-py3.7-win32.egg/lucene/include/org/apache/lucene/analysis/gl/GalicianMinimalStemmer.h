#ifndef org_apache_lucene_analysis_gl_GalicianMinimalStemmer_H
#define org_apache_lucene_analysis_gl_GalicianMinimalStemmer_H

#include "org/apache/lucene/analysis/pt/RSLPStemmerBase.h"

namespace java {
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace gl {

          class _dll_lucene GalicianMinimalStemmer : public ::org::apache::lucene::analysis::pt::RSLPStemmerBase {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_stem_000000004bc20cb9,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit GalicianMinimalStemmer(jobject obj) : ::org::apache::lucene::analysis::pt::RSLPStemmerBase(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            GalicianMinimalStemmer(const GalicianMinimalStemmer& obj) : ::org::apache::lucene::analysis::pt::RSLPStemmerBase(obj) {}

            GalicianMinimalStemmer();

            jint stem(const JArray< jchar > &, jint) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace gl {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(GalicianMinimalStemmer);
          _dll_lucene extern PyTypeObject *PY_TYPE(GalicianMinimalStemmer);

          class _dll_lucene t_GalicianMinimalStemmer {
          public:
            PyObject_HEAD
            GalicianMinimalStemmer object;
            static PyObject *wrap_Object(const GalicianMinimalStemmer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
