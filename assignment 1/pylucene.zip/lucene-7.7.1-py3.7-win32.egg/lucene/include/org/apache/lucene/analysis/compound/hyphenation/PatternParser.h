#ifndef org_apache_lucene_analysis_compound_hyphenation_PatternParser_H
#define org_apache_lucene_analysis_compound_hyphenation_PatternParser_H

#include "org/xml/sax/helpers/DefaultHandler.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            class PatternConsumer;
          }
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {

            class _dll_lucene PatternParser : public ::org::xml::sax::helpers::DefaultHandler {
             public:
              enum {
                mid_init$_ffffffffde902c42,
                mid_init$_00000000707b07a1,
                mid_characters_0000000052290416,
                mid_endElement_ffffffffccbeb7a8,
                mid_parse_0000000048822f5e,
                mid_setConsumer_00000000707b07a1,
                mid_getPattern_ffffffffbf6eae52,
                mid_getInterletterValues_ffffffffbf6eae52,
                mid_normalizeException_0000000053b538f9,
                mid_readToken_000000000e0169da,
                mid_getExceptionWord_00000000406f41e3,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit PatternParser(jobject obj) : ::org::xml::sax::helpers::DefaultHandler(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              PatternParser(const PatternParser& obj) : ::org::xml::sax::helpers::DefaultHandler(obj) {}

              PatternParser();
              PatternParser(const ::org::apache::lucene::analysis::compound::hyphenation::PatternConsumer &);

              void characters(const JArray< jchar > &, jint, jint) const;
              void endElement(const ::java::lang::String &, const ::java::lang::String &, const ::java::lang::String &) const;
              void parse(const ::java::lang::String &) const;
              void setConsumer(const ::org::apache::lucene::analysis::compound::hyphenation::PatternConsumer &) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace compound {
          namespace hyphenation {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(PatternParser);
            _dll_lucene extern PyTypeObject *PY_TYPE(PatternParser);

            class _dll_lucene t_PatternParser {
            public:
              PyObject_HEAD
              PatternParser object;
              static PyObject *wrap_Object(const PatternParser&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
