#ifndef org_apache_lucene_analysis_ar_ArabicNormalizationFilterFactory_H
#define org_apache_lucene_analysis_ar_ArabicNormalizationFilterFactory_H

#include "org/apache/lucene/analysis/util/TokenFilterFactory.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Map;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace util {
          class AbstractAnalysisFactory;
          class MultiTermAwareComponent;
        }
        namespace ar {
          class ArabicNormalizationFilter;
        }
        class TokenStream;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ar {

          class _dll_lucene ArabicNormalizationFilterFactory : public ::org::apache::lucene::analysis::util::TokenFilterFactory {
           public:
            enum {
              mid_init$_ffffffffd3ad6b94,
              mid_create_000000003b006bc1,
              mid_getMultiTermComponent_000000002950e407,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ArabicNormalizationFilterFactory(jobject obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ArabicNormalizationFilterFactory(const ArabicNormalizationFilterFactory& obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {}

            ArabicNormalizationFilterFactory(const ::java::util::Map &);

            ::org::apache::lucene::analysis::ar::ArabicNormalizationFilter create(const ::org::apache::lucene::analysis::TokenStream &) const;
            ::org::apache::lucene::analysis::util::AbstractAnalysisFactory getMultiTermComponent() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ar {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ArabicNormalizationFilterFactory);
          _dll_lucene extern PyTypeObject *PY_TYPE(ArabicNormalizationFilterFactory);

          class _dll_lucene t_ArabicNormalizationFilterFactory {
          public:
            PyObject_HEAD
            ArabicNormalizationFilterFactory object;
            static PyObject *wrap_Object(const ArabicNormalizationFilterFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
