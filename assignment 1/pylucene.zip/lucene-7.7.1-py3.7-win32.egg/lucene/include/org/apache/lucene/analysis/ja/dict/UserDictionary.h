#ifndef org_apache_lucene_analysis_ja_dict_UserDictionary_H
#define org_apache_lucene_analysis_ja_dict_UserDictionary_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class Reader;
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            class UserDictionary;
            class TokenInfoFST;
            class Dictionary;
          }
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {

            class _dll_lucene UserDictionary : public ::java::lang::Object {
             public:
              enum {
                mid_getBaseForm_ffffffffbd9d4b41,
                mid_getFST_000000001848eee1,
                mid_getInflectionForm_0000000026c48400,
                mid_getInflectionType_0000000026c48400,
                mid_getLeftId_000000007930bd1c,
                mid_getPartOfSpeech_0000000026c48400,
                mid_getPronunciation_ffffffffbd9d4b41,
                mid_getReading_ffffffffbd9d4b41,
                mid_getRightId_000000007930bd1c,
                mid_getWordCost_000000007930bd1c,
                mid_lookup_00000000145b2f9d,
                mid_lookupSegmentation_ffffffffd00d2449,
                mid_open_ffffffffb8cd5a7f,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit UserDictionary(jobject obj) : ::java::lang::Object(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              UserDictionary(const UserDictionary& obj) : ::java::lang::Object(obj) {}

              static jint LEFT_ID;
              static jint RIGHT_ID;
              static jint WORD_COST;

              ::java::lang::String getBaseForm(jint, const JArray< jchar > &, jint, jint) const;
              ::org::apache::lucene::analysis::ja::dict::TokenInfoFST getFST() const;
              ::java::lang::String getInflectionForm(jint) const;
              ::java::lang::String getInflectionType(jint) const;
              jint getLeftId(jint) const;
              ::java::lang::String getPartOfSpeech(jint) const;
              ::java::lang::String getPronunciation(jint, const JArray< jchar > &, jint, jint) const;
              ::java::lang::String getReading(jint, const JArray< jchar > &, jint, jint) const;
              jint getRightId(jint) const;
              jint getWordCost(jint) const;
              JArray< JArray< jint > > lookup(const JArray< jchar > &, jint, jint) const;
              JArray< jint > lookupSegmentation(jint) const;
              static UserDictionary open(const ::java::io::Reader &);
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(UserDictionary);
            _dll_lucene extern PyTypeObject *PY_TYPE(UserDictionary);

            class _dll_lucene t_UserDictionary {
            public:
              PyObject_HEAD
              UserDictionary object;
              static PyObject *wrap_Object(const UserDictionary&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
