#ifndef org_apache_lucene_analysis_miscellaneous_ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl_H
#define org_apache_lucene_analysis_miscellaneous_ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl_H

#include "org/apache/lucene/util/AttributeImpl.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace util {
        class BytesRefBuilder;
        class BytesRef;
        class AttributeReflector;
      }
      namespace analysis {
        namespace tokenattributes {
          class TermToBytesRefAttribute;
        }
        namespace miscellaneous {
          class ConcatenateGraphFilter$BytesRefBuilderTermAttribute;
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class CharSequence;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl : public ::org::apache::lucene::util::AttributeImpl {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_builder_000000005e67d1a5,
              mid_clear_ffffffffde902c42,
              mid_clone_0000000042261863,
              mid_copyTo_ffffffff87731181,
              mid_getBytesRef_ffffffffd1929b3f,
              mid_reflectWith_000000007ae09ba8,
              mid_toUTF16_0000000011afe6c5,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl(jobject obj) : ::org::apache::lucene::util::AttributeImpl(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl(const ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl& obj) : ::org::apache::lucene::util::AttributeImpl(obj) {}

            ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl();

            ::org::apache::lucene::util::BytesRefBuilder builder() const;
            void clear() const;
            ::org::apache::lucene::util::AttributeImpl clone() const;
            void copyTo(const ::org::apache::lucene::util::AttributeImpl &) const;
            ::org::apache::lucene::util::BytesRef getBytesRef() const;
            void reflectWith(const ::org::apache::lucene::util::AttributeReflector &) const;
            ::java::lang::CharSequence toUTF16() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl);
          _dll_lucene extern PyTypeObject *PY_TYPE(ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl);

          class _dll_lucene t_ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl {
          public:
            PyObject_HEAD
            ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl object;
            static PyObject *wrap_Object(const ConcatenateGraphFilter$BytesRefBuilderTermAttributeImpl&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
