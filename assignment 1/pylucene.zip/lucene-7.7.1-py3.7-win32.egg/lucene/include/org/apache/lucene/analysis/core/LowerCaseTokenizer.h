#ifndef org_apache_lucene_analysis_core_LowerCaseTokenizer_H
#define org_apache_lucene_analysis_core_LowerCaseTokenizer_H

#include "org/apache/lucene/analysis/core/LetterTokenizer.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace util {
        class AttributeFactory;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {

          class _dll_lucene LowerCaseTokenizer : public ::org::apache::lucene::analysis::core::LetterTokenizer {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_init$_000000000f811fb7,
              mid_init$_000000006f9428ff,
              mid_normalize_000000007930bd1c,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit LowerCaseTokenizer(jobject obj) : ::org::apache::lucene::analysis::core::LetterTokenizer(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            LowerCaseTokenizer(const LowerCaseTokenizer& obj) : ::org::apache::lucene::analysis::core::LetterTokenizer(obj) {}

            LowerCaseTokenizer();
            LowerCaseTokenizer(const ::org::apache::lucene::util::AttributeFactory &);
            LowerCaseTokenizer(const ::org::apache::lucene::util::AttributeFactory &, jint);
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace core {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(LowerCaseTokenizer);
          _dll_lucene extern PyTypeObject *PY_TYPE(LowerCaseTokenizer);

          class _dll_lucene t_LowerCaseTokenizer {
          public:
            PyObject_HEAD
            LowerCaseTokenizer object;
            static PyObject *wrap_Object(const LowerCaseTokenizer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
