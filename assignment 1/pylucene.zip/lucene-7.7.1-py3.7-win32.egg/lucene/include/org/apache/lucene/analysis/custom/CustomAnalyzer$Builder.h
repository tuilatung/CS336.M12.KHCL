#ifndef org_apache_lucene_analysis_custom_CustomAnalyzer$Builder_H
#define org_apache_lucene_analysis_custom_CustomAnalyzer$Builder_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Map;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace util {
          class TokenizerFactory;
          class CharFilterFactory;
          class TokenFilterFactory;
        }
        namespace custom {
          class CustomAnalyzer$ConditionBuilder;
          class CustomAnalyzer$Builder;
          class CustomAnalyzer;
        }
        namespace miscellaneous {
          class ConditionalTokenFilterFactory;
        }
      }
      namespace util {
        class Version;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace custom {

          class _dll_lucene CustomAnalyzer$Builder : public ::java::lang::Object {
           public:
            enum {
              mid_addCharFilter_0000000073f41768,
              mid_addCharFilter_000000001ab46de3,
              mid_addCharFilter_0000000026eeb09a,
              mid_addCharFilter_fffffffff2d1d76f,
              mid_addTokenFilter_fffffffff2d1d76f,
              mid_addTokenFilter_0000000026eeb09a,
              mid_addTokenFilter_0000000073f41768,
              mid_addTokenFilter_000000001ab46de3,
              mid_build_ffffffff823bd2ed,
              mid_when_000000001985346d,
              mid_when_000000002c21bfa7,
              mid_when_ffffffffcd532a4a,
              mid_when_000000005d723085,
              mid_when_ffffffffacae358b,
              mid_withDefaultMatchVersion_ffffffffdb9ffe08,
              mid_withOffsetGap_ffffffff81cc46d7,
              mid_withPositionIncrementGap_ffffffff81cc46d7,
              mid_withTokenizer_fffffffff2d1d76f,
              mid_withTokenizer_000000001ab46de3,
              mid_withTokenizer_0000000073f41768,
              mid_withTokenizer_0000000026eeb09a,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit CustomAnalyzer$Builder(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            CustomAnalyzer$Builder(const CustomAnalyzer$Builder& obj) : ::java::lang::Object(obj) {}

            CustomAnalyzer$Builder addCharFilter(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
            CustomAnalyzer$Builder addCharFilter(const ::java::lang::String &, const ::java::util::Map &) const;
            CustomAnalyzer$Builder addCharFilter(const ::java::lang::Class &, const ::java::util::Map &) const;
            CustomAnalyzer$Builder addCharFilter(const ::java::lang::Class &, const JArray< ::java::lang::String > &) const;
            CustomAnalyzer$Builder addTokenFilter(const ::java::lang::Class &, const JArray< ::java::lang::String > &) const;
            CustomAnalyzer$Builder addTokenFilter(const ::java::lang::Class &, const ::java::util::Map &) const;
            CustomAnalyzer$Builder addTokenFilter(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
            CustomAnalyzer$Builder addTokenFilter(const ::java::lang::String &, const ::java::util::Map &) const;
            ::org::apache::lucene::analysis::custom::CustomAnalyzer build() const;
            ::org::apache::lucene::analysis::custom::CustomAnalyzer$ConditionBuilder when(const ::org::apache::lucene::analysis::miscellaneous::ConditionalTokenFilterFactory &) const;
            ::org::apache::lucene::analysis::custom::CustomAnalyzer$ConditionBuilder when(const ::java::lang::Class &, const ::java::util::Map &) const;
            ::org::apache::lucene::analysis::custom::CustomAnalyzer$ConditionBuilder when(const ::java::lang::Class &, const JArray< ::java::lang::String > &) const;
            ::org::apache::lucene::analysis::custom::CustomAnalyzer$ConditionBuilder when(const ::java::lang::String &, const ::java::util::Map &) const;
            ::org::apache::lucene::analysis::custom::CustomAnalyzer$ConditionBuilder when(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
            CustomAnalyzer$Builder withDefaultMatchVersion(const ::org::apache::lucene::util::Version &) const;
            CustomAnalyzer$Builder withOffsetGap(jint) const;
            CustomAnalyzer$Builder withPositionIncrementGap(jint) const;
            CustomAnalyzer$Builder withTokenizer(const ::java::lang::Class &, const JArray< ::java::lang::String > &) const;
            CustomAnalyzer$Builder withTokenizer(const ::java::lang::String &, const ::java::util::Map &) const;
            CustomAnalyzer$Builder withTokenizer(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
            CustomAnalyzer$Builder withTokenizer(const ::java::lang::Class &, const ::java::util::Map &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace custom {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(CustomAnalyzer$Builder);
          _dll_lucene extern PyTypeObject *PY_TYPE(CustomAnalyzer$Builder);

          class _dll_lucene t_CustomAnalyzer$Builder {
          public:
            PyObject_HEAD
            CustomAnalyzer$Builder object;
            static PyObject *wrap_Object(const CustomAnalyzer$Builder&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
