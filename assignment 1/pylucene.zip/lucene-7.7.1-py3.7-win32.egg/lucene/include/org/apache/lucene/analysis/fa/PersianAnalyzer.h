#ifndef org_apache_lucene_analysis_fa_PersianAnalyzer_H
#define org_apache_lucene_analysis_fa_PersianAnalyzer_H

#include "org/apache/lucene/analysis/StopwordAnalyzerBase.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArraySet;
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace fa {

          class _dll_lucene PersianAnalyzer : public ::org::apache::lucene::analysis::StopwordAnalyzerBase {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_init$_ffffffffae3a4519,
              mid_getDefaultStopSet_fffffffff150072b,
              mid_normalize_000000001d1e9a51,
              mid_initReader_ffffffff978ef084,
              mid_createComponents_000000003a09807f,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit PersianAnalyzer(jobject obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            PersianAnalyzer(const PersianAnalyzer& obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {}

            static ::java::lang::String *DEFAULT_STOPWORD_FILE;
            static ::java::lang::String *STOPWORDS_COMMENT;

            PersianAnalyzer();
            PersianAnalyzer(const ::org::apache::lucene::analysis::CharArraySet &);

            static ::org::apache::lucene::analysis::CharArraySet getDefaultStopSet();
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace fa {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(PersianAnalyzer);
          _dll_lucene extern PyTypeObject *PY_TYPE(PersianAnalyzer);

          class _dll_lucene t_PersianAnalyzer {
          public:
            PyObject_HEAD
            PersianAnalyzer object;
            static PyObject *wrap_Object(const PersianAnalyzer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
