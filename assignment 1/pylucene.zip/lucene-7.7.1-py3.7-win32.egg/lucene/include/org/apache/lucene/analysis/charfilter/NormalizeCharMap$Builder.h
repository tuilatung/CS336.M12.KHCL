#ifndef org_apache_lucene_analysis_charfilter_NormalizeCharMap$Builder_H
#define org_apache_lucene_analysis_charfilter_NormalizeCharMap$Builder_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace charfilter {
          class NormalizeCharMap;
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace charfilter {

          class _dll_lucene NormalizeCharMap$Builder : public ::java::lang::Object {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_add_ffffffffea5c5690,
              mid_build_0000000007a3e00d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit NormalizeCharMap$Builder(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            NormalizeCharMap$Builder(const NormalizeCharMap$Builder& obj) : ::java::lang::Object(obj) {}

            NormalizeCharMap$Builder();

            void add(const ::java::lang::String &, const ::java::lang::String &) const;
            ::org::apache::lucene::analysis::charfilter::NormalizeCharMap build() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace charfilter {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(NormalizeCharMap$Builder);
          _dll_lucene extern PyTypeObject *PY_TYPE(NormalizeCharMap$Builder);

          class _dll_lucene t_NormalizeCharMap$Builder {
          public:
            PyObject_HEAD
            NormalizeCharMap$Builder object;
            static PyObject *wrap_Object(const NormalizeCharMap$Builder&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
