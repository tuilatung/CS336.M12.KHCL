#ifndef org_apache_lucene_analysis_miscellaneous_ConditionalTokenFilterFactory_H
#define org_apache_lucene_analysis_miscellaneous_ConditionalTokenFilterFactory_H

#include "org/apache/lucene/analysis/util/TokenFilterFactory.h"

namespace java {
  namespace lang {
    class Class;
  }
  namespace io {
    class IOException;
  }
  namespace util {
    class List;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace util {
          class ResourceLoaderAware;
          class ResourceLoader;
        }
        class TokenStream;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene ConditionalTokenFilterFactory : public ::org::apache::lucene::analysis::util::TokenFilterFactory {
           public:
            enum {
              mid_create_ffffffffe7fe3f38,
              mid_inform_ffffffffb7b5e7d8,
              mid_setInnerFilters_ffffffffe19bf3ee,
              mid_create_0000000034e7ef91,
              mid_doInform_ffffffffb7b5e7d8,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ConditionalTokenFilterFactory(jobject obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ConditionalTokenFilterFactory(const ConditionalTokenFilterFactory& obj) : ::org::apache::lucene::analysis::util::TokenFilterFactory(obj) {}

            ::org::apache::lucene::analysis::TokenStream create(const ::org::apache::lucene::analysis::TokenStream &) const;
            void inform(const ::org::apache::lucene::analysis::util::ResourceLoader &) const;
            void setInnerFilters(const ::java::util::List &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ConditionalTokenFilterFactory);
          _dll_lucene extern PyTypeObject *PY_TYPE(ConditionalTokenFilterFactory);

          class _dll_lucene t_ConditionalTokenFilterFactory {
          public:
            PyObject_HEAD
            ConditionalTokenFilterFactory object;
            static PyObject *wrap_Object(const ConditionalTokenFilterFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
