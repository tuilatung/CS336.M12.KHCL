#ifndef org_apache_lucene_analysis_miscellaneous_ProtectedTermFilterFactory_H
#define org_apache_lucene_analysis_miscellaneous_ProtectedTermFilterFactory_H

#include "org/apache/lucene/analysis/miscellaneous/ConditionalTokenFilterFactory.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Map;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArraySet;
        namespace util {
          class ResourceLoader;
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene ProtectedTermFilterFactory : public ::org::apache::lucene::analysis::miscellaneous::ConditionalTokenFilterFactory {
           public:
            enum {
              mid_init$_ffffffffd3ad6b94,
              mid_doInform_ffffffffb7b5e7d8,
              mid_getProtectedTerms_fffffffff150072b,
              mid_isIgnoreCase_0000000000c0c182,
              mid_create_0000000034e7ef91,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ProtectedTermFilterFactory(jobject obj) : ::org::apache::lucene::analysis::miscellaneous::ConditionalTokenFilterFactory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ProtectedTermFilterFactory(const ProtectedTermFilterFactory& obj) : ::org::apache::lucene::analysis::miscellaneous::ConditionalTokenFilterFactory(obj) {}

            static jchar FILTER_ARG_SEPARATOR;
            static jchar FILTER_NAME_ID_SEPARATOR;
            static ::java::lang::String *PROTECTED_TERMS;

            ProtectedTermFilterFactory(const ::java::util::Map &);

            void doInform(const ::org::apache::lucene::analysis::util::ResourceLoader &) const;
            ::org::apache::lucene::analysis::CharArraySet getProtectedTerms() const;
            jboolean isIgnoreCase() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ProtectedTermFilterFactory);
          _dll_lucene extern PyTypeObject *PY_TYPE(ProtectedTermFilterFactory);

          class _dll_lucene t_ProtectedTermFilterFactory {
          public:
            PyObject_HEAD
            ProtectedTermFilterFactory object;
            static PyObject *wrap_Object(const ProtectedTermFilterFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
