#ifndef org_apache_lucene_analysis_miscellaneous_ConcatenateGraphFilter_H
#define org_apache_lucene_analysis_miscellaneous_ConcatenateGraphFilter_H

#include "org/apache/lucene/analysis/TokenStream.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace util {
        namespace automaton {
          class Automaton;
        }
      }
    }
  }
}
namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene ConcatenateGraphFilter : public ::org::apache::lucene::analysis::TokenStream {
           public:
            enum {
              mid_init$_00000000419d1091,
              mid_init$_0000000021179c94,
              mid_close_ffffffffde902c42,
              mid_end_ffffffffde902c42,
              mid_incrementToken_0000000000c0c182,
              mid_reset_ffffffffde902c42,
              mid_toAutomaton_ffffffff94d5b0ba,
              mid_toAutomaton_0000000017e84b95,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ConcatenateGraphFilter(jobject obj) : ::org::apache::lucene::analysis::TokenStream(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ConcatenateGraphFilter(const ConcatenateGraphFilter& obj) : ::org::apache::lucene::analysis::TokenStream(obj) {}

            static jint DEFAULT_MAX_GRAPH_EXPANSIONS;
            static jboolean DEFAULT_PRESERVE_POSITION_INCREMENTS;
            static jboolean DEFAULT_PRESERVE_SEP;
            static jint SEP_LABEL;

            ConcatenateGraphFilter(const ::org::apache::lucene::analysis::TokenStream &);
            ConcatenateGraphFilter(const ::org::apache::lucene::analysis::TokenStream &, jboolean, jboolean, jint);

            void close() const;
            void end() const;
            jboolean incrementToken() const;
            void reset() const;
            ::org::apache::lucene::util::automaton::Automaton toAutomaton() const;
            ::org::apache::lucene::util::automaton::Automaton toAutomaton(jboolean) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ConcatenateGraphFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(ConcatenateGraphFilter);

          class _dll_lucene t_ConcatenateGraphFilter {
          public:
            PyObject_HEAD
            ConcatenateGraphFilter object;
            static PyObject *wrap_Object(const ConcatenateGraphFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
