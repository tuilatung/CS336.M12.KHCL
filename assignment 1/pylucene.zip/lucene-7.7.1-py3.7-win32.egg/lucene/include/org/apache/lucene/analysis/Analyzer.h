#ifndef org_apache_lucene_analysis_Analyzer_H
#define org_apache_lucene_analysis_Analyzer_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class Reader;
    class Closeable;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace util {
        class BytesRef;
        class Version;
      }
      namespace analysis {
        class Analyzer$ReuseStrategy;
        class TokenStream;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene Analyzer : public ::java::lang::Object {
         public:
          enum {
            mid_init$_ffffffffde902c42,
            mid_init$_ffffffffa9ea5727,
            mid_close_ffffffffde902c42,
            mid_getOffsetGap_0000000026f4dfbe,
            mid_getPositionIncrementGap_0000000026f4dfbe,
            mid_getReuseStrategy_ffffffffdb8ece6a,
            mid_getVersion_0000000018c9bdf6,
            mid_normalize_ffffffffdfc089fb,
            mid_setVersion_fffffffff5369c48,
            mid_tokenStream_000000002316488c,
            mid_tokenStream_000000007223cb33,
            mid_normalize_000000001d1e9a51,
            mid_initReader_ffffffff978ef084,
            mid_createComponents_000000003a09807f,
            mid_attributeFactory_ffffffffa3592994,
            mid_initReaderForNormalization_ffffffff978ef084,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit Analyzer(jobject obj) : ::java::lang::Object(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          Analyzer(const Analyzer& obj) : ::java::lang::Object(obj) {}

          static ::org::apache::lucene::analysis::Analyzer$ReuseStrategy *GLOBAL_REUSE_STRATEGY;
          static ::org::apache::lucene::analysis::Analyzer$ReuseStrategy *PER_FIELD_REUSE_STRATEGY;

          Analyzer();
          Analyzer(const ::org::apache::lucene::analysis::Analyzer$ReuseStrategy &);

          void close() const;
          jint getOffsetGap(const ::java::lang::String &) const;
          jint getPositionIncrementGap(const ::java::lang::String &) const;
          ::org::apache::lucene::analysis::Analyzer$ReuseStrategy getReuseStrategy() const;
          ::org::apache::lucene::util::Version getVersion() const;
          ::org::apache::lucene::util::BytesRef normalize(const ::java::lang::String &, const ::java::lang::String &) const;
          void setVersion(const ::org::apache::lucene::util::Version &) const;
          ::org::apache::lucene::analysis::TokenStream tokenStream(const ::java::lang::String &, const ::java::io::Reader &) const;
          ::org::apache::lucene::analysis::TokenStream tokenStream(const ::java::lang::String &, const ::java::lang::String &) const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(Analyzer);
        _dll_lucene extern PyTypeObject *PY_TYPE(Analyzer);

        class _dll_lucene t_Analyzer {
        public:
          PyObject_HEAD
          Analyzer object;
          static PyObject *wrap_Object(const Analyzer&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
