#ifndef org_apache_lucene_analysis_ja_JapaneseAnalyzer_H
#define org_apache_lucene_analysis_ja_JapaneseAnalyzer_H

#include "org/apache/lucene/analysis/StopwordAnalyzerBase.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Set;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            class UserDictionary;
          }
          class JapaneseTokenizer$Mode;
        }
        class CharArraySet;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {

          class _dll_lucene JapaneseAnalyzer : public ::org::apache::lucene::analysis::StopwordAnalyzerBase {
           public:
            enum {
              mid_init$_ffffffffde902c42,
              mid_init$_ffffffff82dda743,
              mid_getDefaultStopSet_fffffffff150072b,
              mid_getDefaultStopTags_000000007600271d,
              mid_normalize_000000001d1e9a51,
              mid_createComponents_000000003a09807f,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit JapaneseAnalyzer(jobject obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            JapaneseAnalyzer(const JapaneseAnalyzer& obj) : ::org::apache::lucene::analysis::StopwordAnalyzerBase(obj) {}

            JapaneseAnalyzer();
            JapaneseAnalyzer(const ::org::apache::lucene::analysis::ja::dict::UserDictionary &, const ::org::apache::lucene::analysis::ja::JapaneseTokenizer$Mode &, const ::org::apache::lucene::analysis::CharArraySet &, const ::java::util::Set &);

            static ::org::apache::lucene::analysis::CharArraySet getDefaultStopSet();
            static ::java::util::Set getDefaultStopTags();
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(JapaneseAnalyzer);
          _dll_lucene extern PyTypeObject *PY_TYPE(JapaneseAnalyzer);

          class _dll_lucene t_JapaneseAnalyzer {
          public:
            PyObject_HEAD
            JapaneseAnalyzer object;
            static PyObject *wrap_Object(const JapaneseAnalyzer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
