#ifndef org_apache_lucene_analysis_miscellaneous_ProtectedTermFilter_H
#define org_apache_lucene_analysis_miscellaneous_ProtectedTermFilter_H

#include "org/apache/lucene/analysis/miscellaneous/ConditionalTokenFilter.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArraySet;
        class TokenStream;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {

          class _dll_lucene ProtectedTermFilter : public ::org::apache::lucene::analysis::miscellaneous::ConditionalTokenFilter {
           public:
            enum {
              mid_shouldFilter_0000000000c0c182,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ProtectedTermFilter(jobject obj) : ::org::apache::lucene::analysis::miscellaneous::ConditionalTokenFilter(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ProtectedTermFilter(const ProtectedTermFilter& obj) : ::org::apache::lucene::analysis::miscellaneous::ConditionalTokenFilter(obj) {}
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace miscellaneous {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ProtectedTermFilter);
          _dll_lucene extern PyTypeObject *PY_TYPE(ProtectedTermFilter);

          class _dll_lucene t_ProtectedTermFilter {
          public:
            PyObject_HEAD
            ProtectedTermFilter object;
            static PyObject *wrap_Object(const ProtectedTermFilter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
