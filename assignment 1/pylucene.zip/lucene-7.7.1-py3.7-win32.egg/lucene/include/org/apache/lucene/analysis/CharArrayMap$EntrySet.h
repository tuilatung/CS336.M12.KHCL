#ifndef org_apache_lucene_analysis_CharArrayMap$EntrySet_H
#define org_apache_lucene_analysis_CharArrayMap$EntrySet_H

#include "java/util/AbstractSet.h"

namespace java {
  namespace lang {
    class Object;
    class Class;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class CharArrayMap$EntryIterator;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {

        class _dll_lucene CharArrayMap$EntrySet : public ::java::util::AbstractSet {
         public:
          enum {
            mid_clear_ffffffffde902c42,
            mid_contains_000000007b2e38e9,
            mid_iterator_000000002adb8125,
            mid_remove_000000007b2e38e9,
            mid_size_000000002043cb81,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit CharArrayMap$EntrySet(jobject obj) : ::java::util::AbstractSet(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          CharArrayMap$EntrySet(const CharArrayMap$EntrySet& obj) : ::java::util::AbstractSet(obj) {}

          void clear() const;
          jboolean contains(const ::java::lang::Object &) const;
          ::org::apache::lucene::analysis::CharArrayMap$EntryIterator iterator() const;
          jboolean remove(const ::java::lang::Object &) const;
          jint size() const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(CharArrayMap$EntrySet);
        _dll_lucene extern PyTypeObject *PY_TYPE(CharArrayMap$EntrySet);

        class _dll_lucene t_CharArrayMap$EntrySet {
        public:
          PyObject_HEAD
          CharArrayMap$EntrySet object;
          PyTypeObject *parameters[1];
          static PyTypeObject **parameters_(t_CharArrayMap$EntrySet *self)
          {
            return (PyTypeObject **) &(self->parameters);
          }
          static PyObject *wrap_Object(const CharArrayMap$EntrySet&);
          static PyObject *wrap_jobject(const jobject&);
          static PyObject *wrap_Object(const CharArrayMap$EntrySet&, PyTypeObject *);
          static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
