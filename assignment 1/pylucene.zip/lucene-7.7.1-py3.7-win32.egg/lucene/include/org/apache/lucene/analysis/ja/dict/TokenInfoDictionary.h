#ifndef org_apache_lucene_analysis_ja_dict_TokenInfoDictionary_H
#define org_apache_lucene_analysis_ja_dict_TokenInfoDictionary_H

#include "org/apache/lucene/analysis/ja/dict/BinaryDictionary.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            class TokenInfoFST;
            class TokenInfoDictionary;
          }
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {

            class _dll_lucene TokenInfoDictionary : public ::org::apache::lucene::analysis::ja::dict::BinaryDictionary {
             public:
              enum {
                mid_getFST_000000001848eee1,
                mid_getInstance_000000005beeb8cc,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit TokenInfoDictionary(jobject obj) : ::org::apache::lucene::analysis::ja::dict::BinaryDictionary(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              TokenInfoDictionary(const TokenInfoDictionary& obj) : ::org::apache::lucene::analysis::ja::dict::BinaryDictionary(obj) {}

              static ::java::lang::String *FST_FILENAME_SUFFIX;

              ::org::apache::lucene::analysis::ja::dict::TokenInfoFST getFST() const;
              static TokenInfoDictionary getInstance();
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        namespace ja {
          namespace dict {
            _dll_lucene extern PyType_Def PY_TYPE_DEF(TokenInfoDictionary);
            _dll_lucene extern PyTypeObject *PY_TYPE(TokenInfoDictionary);

            class _dll_lucene t_TokenInfoDictionary {
            public:
              PyObject_HEAD
              TokenInfoDictionary object;
              static PyObject *wrap_Object(const TokenInfoDictionary&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
