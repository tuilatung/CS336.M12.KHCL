#ifndef org_antlr_v4_runtime_atn_ParserATNSimulator_H
#define org_antlr_v4_runtime_atn_ParserATNSimulator_H

#include "org/antlr/v4/runtime/atn/ATNSimulator.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        namespace atn {

          class _dll_lucene ParserATNSimulator : public ::org::antlr::v4::runtime::atn::ATNSimulator {
           public:
            enum {
              mid_clearDFA_ffffffffde902c42,
              mid_getRuleName_0000000026c48400,
              mid_getTokenName_0000000026c48400,
              mid_reset_ffffffffde902c42,
              mid_closure_ffffffff857b468f,
              mid_getExistingTargetState_ffffffffc92df41d,
              mid_computeTargetState_00000000121ef7e1,
              mid_evalSemanticContext_ffffffffb3ecc3e0,
              mid_evalSemanticContext_0000000067f28814,
              mid_reportContextSensitivity_ffffffffdd00d92b,
              mid_getConflictingAlts_ffffffffe9a5e60d,
              mid_getPredicatePredictions_ffffffffedfa2078,
              mid_execATNWithFullContext_ffffffffb64c27ab,
              mid_getPredsForAmbigAlts_ffffffffcd1c1e4a,
              mid_getReachableTarget_000000002a85d8d6,
              mid_predicateDFAState_fffffffff1e64ffc,
              mid_closureCheckingStopState_ffffffffe6a31f0e,
              mid_computeStartState_ffffffff9f0d633f,
              mid_applyPrecedenceFilter_ffffffffd73a4aff,
              mid_getAltThatFinishedDecisionEntryRule_0000000031a27753,
              mid_removeAllConfigsNotInRuleStopState_ffffffff9b2f23d2,
              mid_getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule_000000004e002245,
              mid_getConflictingAltsOrUniqueAlt_ffffffffe9a5e60d,
              mid_splitAccordingToSemanticValidity_ffffffffdec41ea2,
              mid_reportAttemptingFullContext_000000001d6c2fa0,
              mid_reportAmbiguity_000000006c7b96f3,
              mid_computeReachSet_fffffffffce0e709,
              mid_getEpsilonTarget_00000000443f70f6,
              mid_addDFAEdge_00000000604b5c8e,
              mid_addDFAState_000000000d7a627b,
              mid_getUniqueAlt_0000000031a27753,
              mid_noViableAlt_0000000018ddc567,
              mid_ruleTransition_0000000016a82c10,
              mid_actionTransition_ffffffffe24e3b1e,
              mid_predTransition_ffffffffc0cfc670,
              mid_closure__ffffffffe6a31f0e,
              mid_execATN_000000000f426a88,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ParserATNSimulator(jobject obj) : ::org::antlr::v4::runtime::atn::ATNSimulator(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ParserATNSimulator(const ParserATNSimulator& obj) : ::org::antlr::v4::runtime::atn::ATNSimulator(obj) {}

            static jboolean debug;
            static jboolean debug_list_atn_decisions;
            static jboolean dfa_debug;
            static jboolean retry_debug;

            void clearDFA() const;
            ::java::lang::String getRuleName(jint) const;
            ::java::lang::String getTokenName(jint) const;
            void reset() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        namespace atn {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ParserATNSimulator);
          _dll_lucene extern PyTypeObject *PY_TYPE(ParserATNSimulator);

          class _dll_lucene t_ParserATNSimulator {
          public:
            PyObject_HEAD
            ParserATNSimulator object;
            static PyObject *wrap_Object(const ParserATNSimulator&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
