#ifndef org_antlr_v4_runtime_ParserRuleContext_H
#define org_antlr_v4_runtime_ParserRuleContext_H

#include "org/antlr/v4/runtime/RuleContext.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class List;
  }
}
namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        class ParserRuleContext;
        class Token;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {

        class _dll_lucene ParserRuleContext : public ::org::antlr::v4::runtime::RuleContext {
         public:
          enum {
            mid_init$_ffffffffde902c42,
            mid_init$_000000002c1b5058,
            mid_addChild_ffffffff8072879d,
            mid_copyFrom_ffffffffb318758a,
            mid_getChildCount_000000002043cb81,
            mid_getParent_ffffffff8b3e7080,
            mid_getRuleContext_ffffffffa552bf8a,
            mid_getRuleContexts_0000000022e8ad5c,
            mid_getStart_000000002b819e84,
            mid_getStop_000000002b819e84,
            mid_removeLastChild_ffffffffde902c42,
            max_mid
          };

          enum {
            fid_start,
            fid_stop,
            max_fid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static jfieldID *fids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit ParserRuleContext(jobject obj) : ::org::antlr::v4::runtime::RuleContext(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          ParserRuleContext(const ParserRuleContext& obj) : ::org::antlr::v4::runtime::RuleContext(obj) {}

          ::org::antlr::v4::runtime::Token _get_start() const;
          void _set_start(const ::org::antlr::v4::runtime::Token &) const;
          ::org::antlr::v4::runtime::Token _get_stop() const;
          void _set_stop(const ::org::antlr::v4::runtime::Token &) const;

          ParserRuleContext();
          ParserRuleContext(const ParserRuleContext &, jint);

          ::org::antlr::v4::runtime::RuleContext addChild(const ::org::antlr::v4::runtime::RuleContext &) const;
          void copyFrom(const ParserRuleContext &) const;
          jint getChildCount() const;
          ParserRuleContext getParent() const;
          ParserRuleContext getRuleContext(const ::java::lang::Class &, jint) const;
          ::java::util::List getRuleContexts(const ::java::lang::Class &) const;
          ::org::antlr::v4::runtime::Token getStart() const;
          ::org::antlr::v4::runtime::Token getStop() const;
          void removeLastChild() const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(ParserRuleContext);
        _dll_lucene extern PyTypeObject *PY_TYPE(ParserRuleContext);

        class _dll_lucene t_ParserRuleContext {
        public:
          PyObject_HEAD
          ParserRuleContext object;
          static PyObject *wrap_Object(const ParserRuleContext&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
