#ifndef org_antlr_v4_runtime_atn_ATNSimulator_H
#define org_antlr_v4_runtime_atn_ATNSimulator_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class UUID;
  }
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        namespace atn {

          class _dll_lucene ATNSimulator : public ::java::lang::Object {
           public:
            enum {
              mid_checkCondition_ffffffffd7cfea8c,
              mid_checkCondition_ffffffffa85bf073,
              mid_clearDFA_ffffffffde902c42,
              mid_reset_ffffffffde902c42,
              mid_toInt_0000000006a24218,
              mid_toInt32_000000004bc20cb9,
              mid_toLong_ffffffff88a10336,
              mid_toUUID_000000005a7dcbf4,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ATNSimulator(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ATNSimulator(const ATNSimulator& obj) : ::java::lang::Object(obj) {}

            static ::java::util::UUID *SERIALIZED_UUID;
            static jint SERIALIZED_VERSION;

            static void checkCondition(jboolean);
            static void checkCondition(jboolean, const ::java::lang::String &);
            void clearDFA() const;
            void reset() const;
            static jint toInt(jchar);
            static jint toInt32(const JArray< jchar > &, jint);
            static jlong toLong(const JArray< jchar > &, jint);
            static ::java::util::UUID toUUID(const JArray< jchar > &, jint);
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        namespace atn {
          _dll_lucene extern PyType_Def PY_TYPE_DEF(ATNSimulator);
          _dll_lucene extern PyTypeObject *PY_TYPE(ATNSimulator);

          class _dll_lucene t_ATNSimulator {
          public:
            PyObject_HEAD
            ATNSimulator object;
            static PyObject *wrap_Object(const ATNSimulator&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
