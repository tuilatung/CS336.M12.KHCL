#ifndef org_antlr_v4_runtime_Token_H
#define org_antlr_v4_runtime_Token_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {

        class _dll_lucene Token : public ::java::lang::Object {
         public:
          enum {
            mid_getChannel_000000002043cb81,
            mid_getCharPositionInLine_000000002043cb81,
            mid_getLine_000000002043cb81,
            mid_getStartIndex_000000002043cb81,
            mid_getStopIndex_000000002043cb81,
            mid_getText_000000001d4fc793,
            mid_getTokenIndex_000000002043cb81,
            mid_getType_000000002043cb81,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit Token(jobject obj) : ::java::lang::Object(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          Token(const Token& obj) : ::java::lang::Object(obj) {}

          static jint DEFAULT_CHANNEL;
          static jint EOF;
          static jint EPSILON;
          static jint HIDDEN_CHANNEL;
          static jint INVALID_TYPE;
          static jint MIN_USER_CHANNEL_VALUE;
          static jint MIN_USER_TOKEN_TYPE;

          jint getChannel() const;
          jint getCharPositionInLine() const;
          jint getLine() const;
          jint getStartIndex() const;
          jint getStopIndex() const;
          ::java::lang::String getText() const;
          jint getTokenIndex() const;
          jint getType() const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(Token);
        _dll_lucene extern PyTypeObject *PY_TYPE(Token);

        class _dll_lucene t_Token {
        public:
          PyObject_HEAD
          Token object;
          static PyObject *wrap_Object(const Token&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
