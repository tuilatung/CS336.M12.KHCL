#ifndef org_antlr_v4_runtime_RuleContext_H
#define org_antlr_v4_runtime_RuleContext_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class List;
  }
}
namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        class ParserRuleContext;
        class RuleContext;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {

        class _dll_lucene RuleContext : public ::java::lang::Object {
         public:
          enum {
            mid_init$_ffffffffde902c42,
            mid_init$_000000006a150c7f,
            mid_depth_000000002043cb81,
            mid_getChildCount_000000002043cb81,
            mid_getParent_fffffffff54eb785,
            mid_getPayload_fffffffff54eb785,
            mid_getRuleContext_fffffffff54eb785,
            mid_getRuleIndex_000000002043cb81,
            mid_getText_000000001d4fc793,
            mid_isEmpty_0000000000c0c182,
            mid_toString_000000001d4fc793,
            mid_toString_0000000032935dda,
            mid_toString_ffffffffe15b4c31,
            mid_toStringTree_000000001d4fc793,
            mid_toStringTree_0000000032935dda,
            max_mid
          };

          enum {
            fid_invokingState,
            fid_parent,
            max_fid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static jfieldID *fids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit RuleContext(jobject obj) : ::java::lang::Object(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          RuleContext(const RuleContext& obj) : ::java::lang::Object(obj) {}

          static ::org::antlr::v4::runtime::ParserRuleContext *EMPTY;

          jint _get_invokingState() const;
          void _set_invokingState(jint) const;
          RuleContext _get_parent() const;
          void _set_parent(const RuleContext &) const;

          RuleContext();
          RuleContext(const RuleContext &, jint);

          jint depth() const;
          jint getChildCount() const;
          RuleContext getParent() const;
          RuleContext getPayload() const;
          RuleContext getRuleContext() const;
          jint getRuleIndex() const;
          ::java::lang::String getText() const;
          jboolean isEmpty() const;
          ::java::lang::String toString() const;
          ::java::lang::String toString(const ::java::util::List &) const;
          ::java::lang::String toString(const ::java::util::List &, const RuleContext &) const;
          ::java::lang::String toStringTree() const;
          ::java::lang::String toStringTree(const ::java::util::List &) const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace antlr {
    namespace v4 {
      namespace runtime {
        _dll_lucene extern PyType_Def PY_TYPE_DEF(RuleContext);
        _dll_lucene extern PyTypeObject *PY_TYPE(RuleContext);

        class _dll_lucene t_RuleContext {
        public:
          PyObject_HEAD
          RuleContext object;
          static PyObject *wrap_Object(const RuleContext&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
