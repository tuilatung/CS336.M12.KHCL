#ifndef java_nio_file_FileStore_H
#define java_nio_file_FileStore_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene FileStore : public ::java::lang::Object {
       public:
        enum {
          mid_getAttribute_ffffffffe4de0f65,
          mid_getTotalSpace_ffffffffb4c92ea6,
          mid_getUnallocatedSpace_ffffffffb4c92ea6,
          mid_getUsableSpace_ffffffffb4c92ea6,
          mid_isReadOnly_0000000000c0c182,
          mid_name_000000001d4fc793,
          mid_supportsFileAttributeView_ffffffffc94366ea,
          mid_type_000000001d4fc793,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit FileStore(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        FileStore(const FileStore& obj) : ::java::lang::Object(obj) {}

        ::java::lang::Object getAttribute(const ::java::lang::String &) const;
        jlong getTotalSpace() const;
        jlong getUnallocatedSpace() const;
        jlong getUsableSpace() const;
        jboolean isReadOnly() const;
        ::java::lang::String name() const;
        jboolean supportsFileAttributeView(const ::java::lang::String &) const;
        ::java::lang::String type() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(FileStore);
      _dll_lucene extern PyTypeObject *PY_TYPE(FileStore);

      class _dll_lucene t_FileStore {
      public:
        PyObject_HEAD
        FileStore object;
        static PyObject *wrap_Object(const FileStore&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
