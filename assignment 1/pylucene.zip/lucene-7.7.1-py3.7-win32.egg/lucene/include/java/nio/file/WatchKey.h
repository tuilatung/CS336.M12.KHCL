#ifndef java_nio_file_WatchKey_H
#define java_nio_file_WatchKey_H

#include "java/lang/Object.h"

namespace java {
  namespace nio {
    namespace file {
      class Watchable;
      class WatchEvent;
    }
  }
  namespace lang {
    class Class;
  }
  namespace util {
    class List;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene WatchKey : public ::java::lang::Object {
       public:
        enum {
          mid_cancel_ffffffffde902c42,
          mid_isValid_0000000000c0c182,
          mid_pollEvents_ffffffffbf1ee3ce,
          mid_reset_0000000000c0c182,
          mid_watchable_fffffffff223a707,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit WatchKey(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        WatchKey(const WatchKey& obj) : ::java::lang::Object(obj) {}

        void cancel() const;
        jboolean isValid() const;
        ::java::util::List pollEvents() const;
        jboolean reset() const;
        ::java::nio::file::Watchable watchable() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(WatchKey);
      _dll_lucene extern PyTypeObject *PY_TYPE(WatchKey);

      class _dll_lucene t_WatchKey {
      public:
        PyObject_HEAD
        WatchKey object;
        static PyObject *wrap_Object(const WatchKey&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
