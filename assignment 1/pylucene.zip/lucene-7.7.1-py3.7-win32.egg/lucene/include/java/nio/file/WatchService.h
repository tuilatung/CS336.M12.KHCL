#ifndef java_nio_file_WatchService_H
#define java_nio_file_WatchService_H

#include "java/io/Closeable.h"

namespace java {
  namespace lang {
    class InterruptedException;
    class Class;
  }
  namespace util {
    namespace concurrent {
      class TimeUnit;
    }
  }
  namespace nio {
    namespace file {
      class WatchKey;
    }
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene WatchService : public ::java::io::Closeable {
       public:
        enum {
          mid_close_ffffffffde902c42,
          mid_poll_000000006b4aac47,
          mid_poll_fffffffff5ac771f,
          mid_take_000000006b4aac47,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit WatchService(jobject obj) : ::java::io::Closeable(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        WatchService(const WatchService& obj) : ::java::io::Closeable(obj) {}

        void close() const;
        ::java::nio::file::WatchKey poll() const;
        ::java::nio::file::WatchKey poll(jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::nio::file::WatchKey take() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(WatchService);
      _dll_lucene extern PyTypeObject *PY_TYPE(WatchService);

      class _dll_lucene t_WatchService {
      public:
        PyObject_HEAD
        WatchService object;
        static PyObject *wrap_Object(const WatchService&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
