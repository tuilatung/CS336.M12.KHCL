#ifndef java_nio_file_Path_H
#define java_nio_file_Path_H

#include "java/lang/Comparable.h"

namespace java {
  namespace nio {
    namespace file {
      class LinkOption;
      class WatchService;
      class Watchable;
      class Path;
      class WatchEvent$Modifier;
      class FileSystem;
      class WatchKey;
      class WatchEvent$Kind;
    }
  }
  namespace io {
    class File;
    class IOException;
  }
  namespace lang {
    class Class;
    class Object;
    class Iterable;
    class String;
  }
  namespace util {
    class Iterator;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene Path : public ::java::lang::Comparable {
       public:
        enum {
          mid_compareTo_ffffffff9d644154,
          mid_endsWith_ffffffffe7360e24,
          mid_endsWith_ffffffffc94366ea,
          mid_equals_000000007b2e38e9,
          mid_getFileName_ffffffffe3b81ba8,
          mid_getFileSystem_ffffffffb77ce75b,
          mid_getName_000000007b8f0771,
          mid_getNameCount_000000002043cb81,
          mid_getParent_ffffffffe3b81ba8,
          mid_getRoot_ffffffffe3b81ba8,
          mid_hashCode_000000002043cb81,
          mid_isAbsolute_0000000000c0c182,
          mid_iterator_ffffffffafc8ac37,
          mid_normalize_ffffffffe3b81ba8,
          mid_register_fffffffffd1a167b,
          mid_register_0000000064b576b0,
          mid_relativize_0000000023344c39,
          mid_resolve_0000000023344c39,
          mid_resolve_000000006c93a351,
          mid_resolveSibling_0000000023344c39,
          mid_resolveSibling_000000006c93a351,
          mid_startsWith_ffffffffc94366ea,
          mid_startsWith_ffffffffe7360e24,
          mid_subpath_0000000059f3aab3,
          mid_toAbsolutePath_ffffffffe3b81ba8,
          mid_toFile_ffffffffc9f49bb5,
          mid_toRealPath_ffffffffa6a6c330,
          mid_toString_000000001d4fc793,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Path(jobject obj) : ::java::lang::Comparable(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Path(const Path& obj) : ::java::lang::Comparable(obj) {}

        jint compareTo(const Path &) const;
        jboolean endsWith(const Path &) const;
        jboolean endsWith(const ::java::lang::String &) const;
        jboolean equals(const ::java::lang::Object &) const;
        Path getFileName() const;
        ::java::nio::file::FileSystem getFileSystem() const;
        Path getName(jint) const;
        jint getNameCount() const;
        Path getParent() const;
        Path getRoot() const;
        jint hashCode() const;
        jboolean isAbsolute() const;
        ::java::util::Iterator iterator() const;
        Path normalize() const;
        ::java::nio::file::WatchKey register$(const ::java::nio::file::WatchService &, const JArray< ::java::nio::file::WatchEvent$Kind > &) const;
        ::java::nio::file::WatchKey register$(const ::java::nio::file::WatchService &, const JArray< ::java::nio::file::WatchEvent$Kind > &, const JArray< ::java::nio::file::WatchEvent$Modifier > &) const;
        Path relativize(const Path &) const;
        Path resolve(const Path &) const;
        Path resolve(const ::java::lang::String &) const;
        Path resolveSibling(const Path &) const;
        Path resolveSibling(const ::java::lang::String &) const;
        jboolean startsWith(const ::java::lang::String &) const;
        jboolean startsWith(const Path &) const;
        Path subpath(jint, jint) const;
        Path toAbsolutePath() const;
        ::java::io::File toFile() const;
        Path toRealPath(const JArray< ::java::nio::file::LinkOption > &) const;
        ::java::lang::String toString() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(Path);
      _dll_lucene extern PyTypeObject *PY_TYPE(Path);

      class _dll_lucene t_Path {
      public:
        PyObject_HEAD
        Path object;
        static PyObject *wrap_Object(const Path&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
