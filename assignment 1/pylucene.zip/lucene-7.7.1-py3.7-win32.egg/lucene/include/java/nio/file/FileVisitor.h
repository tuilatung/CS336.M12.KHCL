#ifndef java_nio_file_FileVisitor_H
#define java_nio_file_FileVisitor_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class IOException;
  }
  namespace nio {
    namespace file {
      class FileVisitResult;
    }
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene FileVisitor : public ::java::lang::Object {
       public:
        enum {
          mid_postVisitDirectory_ffffffffa8d31c94,
          mid_visitFileFailed_ffffffffa8d31c94,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit FileVisitor(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        FileVisitor(const FileVisitor& obj) : ::java::lang::Object(obj) {}

        ::java::nio::file::FileVisitResult postVisitDirectory(const ::java::lang::Object &, const ::java::io::IOException &) const;
        ::java::nio::file::FileVisitResult visitFileFailed(const ::java::lang::Object &, const ::java::io::IOException &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(FileVisitor);
      _dll_lucene extern PyTypeObject *PY_TYPE(FileVisitor);

      class _dll_lucene t_FileVisitor {
      public:
        PyObject_HEAD
        FileVisitor object;
        PyTypeObject *parameters[1];
        static PyTypeObject **parameters_(t_FileVisitor *self)
        {
          return (PyTypeObject **) &(self->parameters);
        }
        static PyObject *wrap_Object(const FileVisitor&);
        static PyObject *wrap_jobject(const jobject&);
        static PyObject *wrap_Object(const FileVisitor&, PyTypeObject *);
        static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
