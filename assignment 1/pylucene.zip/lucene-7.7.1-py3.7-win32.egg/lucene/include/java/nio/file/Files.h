#ifndef java_nio_file_Files_H
#define java_nio_file_Files_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class BufferedWriter;
    class BufferedReader;
    class OutputStream;
    class InputStream;
    class IOException;
  }
  namespace nio {
    namespace file {
      class DirectoryStream;
      class OpenOption;
      class FileVisitOption;
      class DirectoryStream$Filter;
      class CopyOption;
      class FileStore;
      class FileVisitor;
      class LinkOption;
      class Path;
    }
  }
  namespace lang {
    class Iterable;
    class String;
    class Class;
    class CharSequence;
  }
  namespace util {
    class Map;
    class List;
    class Set;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene Files : public ::java::lang::Object {
       public:
        enum {
          mid_copy_ffffffff9254ab15,
          mid_copy_0000000057e88195,
          mid_copy_ffffffffdcc5a1fa,
          mid_createLink_ffffffff844c42ff,
          mid_delete_000000005ef717a4,
          mid_deleteIfExists_ffffffffe7360e24,
          mid_exists_ffffffffb5d52fab,
          mid_getAttribute_00000000680b8db2,
          mid_getFileStore_00000000307ce153,
          mid_isDirectory_ffffffffb5d52fab,
          mid_isExecutable_ffffffffe7360e24,
          mid_isHidden_ffffffffe7360e24,
          mid_isReadable_ffffffffe7360e24,
          mid_isRegularFile_ffffffffb5d52fab,
          mid_isSameFile_0000000037d2efd9,
          mid_isSymbolicLink_ffffffffe7360e24,
          mid_isWritable_ffffffffe7360e24,
          mid_move_0000000057e88195,
          mid_newBufferedReader_000000006e7b9d09,
          mid_newBufferedWriter_ffffffffe5895b41,
          mid_newDirectoryStream_000000006da0cbc2,
          mid_newDirectoryStream_000000000e71cab0,
          mid_newDirectoryStream_000000002c1b7c1a,
          mid_newInputStream_fffffffffb76fa2f,
          mid_newOutputStream_0000000023832ed3,
          mid_notExists_ffffffffb5d52fab,
          mid_probeContentType_000000007f0d92e0,
          mid_readAllBytes_ffffffff95732ee3,
          mid_readAllLines_ffffffff815016fc,
          mid_readAttributes_000000005db5b592,
          mid_readSymbolicLink_0000000023344c39,
          mid_setAttribute_fffffffff3a3db1a,
          mid_size_000000002a5faa86,
          mid_walkFileTree_000000003211c357,
          mid_walkFileTree_ffffffff966c9b47,
          mid_write_ffffffffe753ca14,
          mid_write_ffffffffb2ab625b,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Files(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Files(const Files& obj) : ::java::lang::Object(obj) {}

        static jlong copy(const ::java::nio::file::Path &, const ::java::io::OutputStream &);
        static ::java::nio::file::Path copy(const ::java::nio::file::Path &, const ::java::nio::file::Path &, const JArray< ::java::nio::file::CopyOption > &);
        static jlong copy(const ::java::io::InputStream &, const ::java::nio::file::Path &, const JArray< ::java::nio::file::CopyOption > &);
        static ::java::nio::file::Path createLink(const ::java::nio::file::Path &, const ::java::nio::file::Path &);
        static void delete$(const ::java::nio::file::Path &);
        static jboolean deleteIfExists(const ::java::nio::file::Path &);
        static jboolean exists(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::lang::Object getAttribute(const ::java::nio::file::Path &, const ::java::lang::String &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::nio::file::FileStore getFileStore(const ::java::nio::file::Path &);
        static jboolean isDirectory(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static jboolean isExecutable(const ::java::nio::file::Path &);
        static jboolean isHidden(const ::java::nio::file::Path &);
        static jboolean isReadable(const ::java::nio::file::Path &);
        static jboolean isRegularFile(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static jboolean isSameFile(const ::java::nio::file::Path &, const ::java::nio::file::Path &);
        static jboolean isSymbolicLink(const ::java::nio::file::Path &);
        static jboolean isWritable(const ::java::nio::file::Path &);
        static ::java::nio::file::Path move(const ::java::nio::file::Path &, const ::java::nio::file::Path &, const JArray< ::java::nio::file::CopyOption > &);
        static ::java::io::BufferedReader newBufferedReader(const ::java::nio::file::Path &);
        static ::java::io::BufferedWriter newBufferedWriter(const ::java::nio::file::Path &, const JArray< ::java::nio::file::OpenOption > &);
        static ::java::nio::file::DirectoryStream newDirectoryStream(const ::java::nio::file::Path &);
        static ::java::nio::file::DirectoryStream newDirectoryStream(const ::java::nio::file::Path &, const ::java::nio::file::DirectoryStream$Filter &);
        static ::java::nio::file::DirectoryStream newDirectoryStream(const ::java::nio::file::Path &, const ::java::lang::String &);
        static ::java::io::InputStream newInputStream(const ::java::nio::file::Path &, const JArray< ::java::nio::file::OpenOption > &);
        static ::java::io::OutputStream newOutputStream(const ::java::nio::file::Path &, const JArray< ::java::nio::file::OpenOption > &);
        static jboolean notExists(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::lang::String probeContentType(const ::java::nio::file::Path &);
        static JArray< jbyte > readAllBytes(const ::java::nio::file::Path &);
        static ::java::util::List readAllLines(const ::java::nio::file::Path &);
        static ::java::util::Map readAttributes(const ::java::nio::file::Path &, const ::java::lang::String &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::nio::file::Path readSymbolicLink(const ::java::nio::file::Path &);
        static ::java::nio::file::Path setAttribute(const ::java::nio::file::Path &, const ::java::lang::String &, const ::java::lang::Object &, const JArray< ::java::nio::file::LinkOption > &);
        static jlong size(const ::java::nio::file::Path &);
        static ::java::nio::file::Path walkFileTree(const ::java::nio::file::Path &, const ::java::nio::file::FileVisitor &);
        static ::java::nio::file::Path walkFileTree(const ::java::nio::file::Path &, const ::java::util::Set &, jint, const ::java::nio::file::FileVisitor &);
        static ::java::nio::file::Path write(const ::java::nio::file::Path &, const ::java::lang::Iterable &, const JArray< ::java::nio::file::OpenOption > &);
        static ::java::nio::file::Path write(const ::java::nio::file::Path &, const JArray< jbyte > &, const JArray< ::java::nio::file::OpenOption > &);
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(Files);
      _dll_lucene extern PyTypeObject *PY_TYPE(Files);

      class _dll_lucene t_Files {
      public:
        PyObject_HEAD
        Files object;
        static PyObject *wrap_Object(const Files&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
