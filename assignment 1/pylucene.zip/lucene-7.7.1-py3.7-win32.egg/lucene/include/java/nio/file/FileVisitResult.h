#ifndef java_nio_file_FileVisitResult_H
#define java_nio_file_FileVisitResult_H

#include "java/lang/Enum.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace nio {
    namespace file {
      class FileVisitResult;
    }
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene FileVisitResult : public ::java::lang::Enum {
       public:
        enum {
          mid_valueOf_000000007722e629,
          mid_values_ffffffff8ba03296,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit FileVisitResult(jobject obj) : ::java::lang::Enum(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        FileVisitResult(const FileVisitResult& obj) : ::java::lang::Enum(obj) {}

        static FileVisitResult *CONTINUE;
        static FileVisitResult *SKIP_SIBLINGS;
        static FileVisitResult *SKIP_SUBTREE;
        static FileVisitResult *TERMINATE;

        static FileVisitResult valueOf(const ::java::lang::String &);
        static JArray< FileVisitResult > values();
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(FileVisitResult);
      _dll_lucene extern PyTypeObject *PY_TYPE(FileVisitResult);

      class _dll_lucene t_FileVisitResult {
      public:
        PyObject_HEAD
        FileVisitResult object;
        PyTypeObject *parameters[1];
        static PyTypeObject **parameters_(t_FileVisitResult *self)
        {
          return (PyTypeObject **) &(self->parameters);
        }
        static PyObject *wrap_Object(const FileVisitResult&);
        static PyObject *wrap_jobject(const jobject&);
        static PyObject *wrap_Object(const FileVisitResult&, PyTypeObject *);
        static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
