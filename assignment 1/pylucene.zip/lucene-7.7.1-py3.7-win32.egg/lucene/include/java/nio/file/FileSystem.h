#ifndef java_nio_file_FileSystem_H
#define java_nio_file_FileSystem_H

#include "java/lang/Object.h"

namespace java {
  namespace nio {
    namespace file {
      class WatchService;
      class FileStore;
      class Path;
      class PathMatcher;
    }
  }
  namespace lang {
    class Class;
    class Iterable;
    class String;
  }
  namespace io {
    class Closeable;
    class IOException;
  }
  namespace util {
    class Set;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class _dll_lucene FileSystem : public ::java::lang::Object {
       public:
        enum {
          mid_close_ffffffffde902c42,
          mid_getFileStores_ffffffffe2f2f7d1,
          mid_getPath_ffffffffc8f6e9bc,
          mid_getPathMatcher_0000000064b18d7b,
          mid_getRootDirectories_ffffffffe2f2f7d1,
          mid_getSeparator_000000001d4fc793,
          mid_isOpen_0000000000c0c182,
          mid_isReadOnly_0000000000c0c182,
          mid_newWatchService_00000000357e486a,
          mid_supportedFileAttributeViews_000000007600271d,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit FileSystem(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        FileSystem(const FileSystem& obj) : ::java::lang::Object(obj) {}

        void close() const;
        ::java::lang::Iterable getFileStores() const;
        ::java::nio::file::Path getPath(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
        ::java::nio::file::PathMatcher getPathMatcher(const ::java::lang::String &) const;
        ::java::lang::Iterable getRootDirectories() const;
        ::java::lang::String getSeparator() const;
        jboolean isOpen() const;
        jboolean isReadOnly() const;
        ::java::nio::file::WatchService newWatchService() const;
        ::java::util::Set supportedFileAttributeViews() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(FileSystem);
      _dll_lucene extern PyTypeObject *PY_TYPE(FileSystem);

      class _dll_lucene t_FileSystem {
      public:
        PyObject_HEAD
        FileSystem object;
        static PyObject *wrap_Object(const FileSystem&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
