#ifndef java_lang_ClassLoader_H
#define java_lang_ClassLoader_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class ClassLoader;
    class ClassNotFoundException;
  }
  namespace util {
    class Enumeration;
  }
  namespace io {
    class InputStream;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene ClassLoader : public ::java::lang::Object {
     public:
      enum {
        mid_clearAssertionStatus_ffffffffde902c42,
        mid_getParent_ffffffff8730a17b,
        mid_getResourceAsStream_00000000041da0eb,
        mid_getSystemClassLoader_ffffffff8730a17b,
        mid_getSystemResourceAsStream_00000000041da0eb,
        mid_loadClass_ffffffffaa4df882,
        mid_setClassAssertionStatus_fffffffff36851b2,
        mid_setDefaultAssertionStatus_ffffffffd7cfea8c,
        mid_setPackageAssertionStatus_fffffffff36851b2,
        mid_loadClass_000000006d33b76c,
        mid_getPackage_ffffffff8a5d8af2,
        mid_setSigners_fffffffff70ed61e,
        mid_defineClass_000000006347b9f5,
        mid_defineClass_ffffffffae6fef55,
        mid_defineClass_00000000089c9d8c,
        mid_defineClass_ffffffffbe75ff7d,
        mid_definePackage_0000000019f13e90,
        mid_findClass_ffffffffaa4df882,
        mid_findLibrary_ffffffffbf6eae52,
        mid_findLoadedClass_ffffffffaa4df882,
        mid_findResource_ffffffff97081a5f,
        mid_findResources_000000004c1bdc3e,
        mid_findSystemClass_ffffffffaa4df882,
        mid_getClassLoadingLock_ffffffffe4de0f65,
        mid_getPackages_000000000c338e58,
        mid_registerAsParallelCapable_0000000000c0c182,
        mid_resolveClass_ffffffffd699f537,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ClassLoader(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ClassLoader(const ClassLoader& obj) : ::java::lang::Object(obj) {}

      void clearAssertionStatus() const;
      ClassLoader getParent() const;
      ::java::io::InputStream getResourceAsStream(const ::java::lang::String &) const;
      static ClassLoader getSystemClassLoader();
      static ::java::io::InputStream getSystemResourceAsStream(const ::java::lang::String &);
      ::java::lang::Class loadClass(const ::java::lang::String &) const;
      void setClassAssertionStatus(const ::java::lang::String &, jboolean) const;
      void setDefaultAssertionStatus(jboolean) const;
      void setPackageAssertionStatus(const ::java::lang::String &, jboolean) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(ClassLoader);
    _dll_lucene extern PyTypeObject *PY_TYPE(ClassLoader);

    class _dll_lucene t_ClassLoader {
    public:
      PyObject_HEAD
      ClassLoader object;
      static PyObject *wrap_Object(const ClassLoader&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
