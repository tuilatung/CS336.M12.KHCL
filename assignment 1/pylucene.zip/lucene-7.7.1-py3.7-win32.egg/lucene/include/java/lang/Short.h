#ifndef java_lang_Short_H
#define java_lang_Short_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class Class;
    class Short;
    class Object;
    class Comparable;
    class String;
    class NumberFormatException;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Short : public ::java::lang::Number {
     public:
      enum {
        mid_init$_ffffffffae3ccf1a,
        mid_init$_0000000048822f5e,
        mid_byteValue_ffffffffb58647b4,
        mid_compare_000000001436030e,
        mid_compareTo_000000007f2567b1,
        mid_decode_fffffffffbed9e0c,
        mid_doubleValue_0000000046402c15,
        mid_equals_000000007b2e38e9,
        mid_floatValue_ffffffffee5e3be1,
        mid_hashCode_000000002043cb81,
        mid_hashCode_ffffffff853c9d4f,
        mid_intValue_000000002043cb81,
        mid_longValue_ffffffffb4c92ea6,
        mid_parseShort_000000001c7ab2a9,
        mid_parseShort_ffffffff9652434a,
        mid_reverseBytes_0000000036effd02,
        mid_shortValue_00000000001347c2,
        mid_toString_000000001d4fc793,
        mid_toString_000000006b5a8dcb,
        mid_toUnsignedInt_ffffffff853c9d4f,
        mid_toUnsignedLong_fffffffffd358f9b,
        mid_valueOf_000000006f41cfa9,
        mid_valueOf_fffffffffbed9e0c,
        mid_valueOf_ffffffffb7178309,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Short(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Short(const Short& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jshort MAX_VALUE;
      static jshort MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Short(jshort);
      Short(const ::java::lang::String &);

      jbyte byteValue() const;
      static jint compare(jshort, jshort);
      jint compareTo(const Short &) const;
      static Short decode(const ::java::lang::String &);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jshort);
      jint intValue() const;
      jlong longValue() const;
      static jshort parseShort(const ::java::lang::String &);
      static jshort parseShort(const ::java::lang::String &, jint);
      static jshort reverseBytes(jshort);
      jshort shortValue() const;
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jshort);
      static jint toUnsignedInt(jshort);
      static jlong toUnsignedLong(jshort);
      static Short valueOf(jshort);
      static Short valueOf(const ::java::lang::String &);
      static Short valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Short);
    _dll_lucene extern PyTypeObject *PY_TYPE(Short);

    class _dll_lucene t_Short {
    public:
      PyObject_HEAD
      Short object;
      static PyObject *wrap_Object(const Short&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
