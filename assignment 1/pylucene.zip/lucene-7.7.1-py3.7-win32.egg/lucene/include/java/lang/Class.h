#ifndef java_lang_Class_H
#define java_lang_Class_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class ClassLoader;
    class ClassNotFoundException;
    class IllegalAccessException;
    class Package;
    class InstantiationException;
    class SecurityException;
  }
  namespace io {
    class InputStream;
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Class : public ::java::lang::Object {
     public:
      enum {
        mid_asSubclass_fffffffff9d581f7,
        mid_cast_ffffffff8bf08471,
        mid_desiredAssertionStatus_0000000000c0c182,
        mid_forName_ffffffffaa4df882,
        mid_forName_0000000078a9cc9e,
        mid_getCanonicalName_000000001d4fc793,
        mid_getClassLoader_ffffffff8730a17b,
        mid_getClasses_000000005195133c,
        mid_getComponentType_000000001a21d18a,
        mid_getDeclaredClasses_000000005195133c,
        mid_getDeclaringClass_000000001a21d18a,
        mid_getEnclosingClass_000000001a21d18a,
        mid_getEnumConstants_000000000a31633c,
        mid_getInterfaces_000000005195133c,
        mid_getModifiers_000000002043cb81,
        mid_getName_000000001d4fc793,
        mid_getPackage_0000000019249132,
        mid_getResourceAsStream_00000000041da0eb,
        mid_getSigners_000000000a31633c,
        mid_getSimpleName_000000001d4fc793,
        mid_getSuperclass_000000001a21d18a,
        mid_getTypeName_000000001d4fc793,
        mid_isAnnotation_0000000000c0c182,
        mid_isAnonymousClass_0000000000c0c182,
        mid_isArray_0000000000c0c182,
        mid_isAssignableFrom_ffffffffe7c90753,
        mid_isEnum_0000000000c0c182,
        mid_isInstance_000000007b2e38e9,
        mid_isInterface_0000000000c0c182,
        mid_isLocalClass_0000000000c0c182,
        mid_isMemberClass_0000000000c0c182,
        mid_isPrimitive_0000000000c0c182,
        mid_isSynthetic_0000000000c0c182,
        mid_newInstance_ffffffffdcc2e1cc,
        mid_toGenericString_000000001d4fc793,
        mid_toString_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Class(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Class(const Class& obj) : ::java::lang::Object(obj) {}

      Class asSubclass(const Class &) const;
      ::java::lang::Object cast(const ::java::lang::Object &) const;
      jboolean desiredAssertionStatus() const;
      static Class forName(const ::java::lang::String &);
      static Class forName(const ::java::lang::String &, jboolean, const ::java::lang::ClassLoader &);
      ::java::lang::String getCanonicalName() const;
      ::java::lang::ClassLoader getClassLoader() const;
      JArray< Class > getClasses() const;
      Class getComponentType() const;
      JArray< Class > getDeclaredClasses() const;
      Class getDeclaringClass() const;
      Class getEnclosingClass() const;
      JArray< ::java::lang::Object > getEnumConstants() const;
      JArray< Class > getInterfaces() const;
      jint getModifiers() const;
      ::java::lang::String getName() const;
      ::java::lang::Package getPackage() const;
      ::java::io::InputStream getResourceAsStream(const ::java::lang::String &) const;
      JArray< ::java::lang::Object > getSigners() const;
      ::java::lang::String getSimpleName() const;
      Class getSuperclass() const;
      ::java::lang::String getTypeName() const;
      jboolean isAnnotation() const;
      jboolean isAnonymousClass() const;
      jboolean isArray() const;
      jboolean isAssignableFrom(const Class &) const;
      jboolean isEnum() const;
      jboolean isInstance(const ::java::lang::Object &) const;
      jboolean isInterface() const;
      jboolean isLocalClass() const;
      jboolean isMemberClass() const;
      jboolean isPrimitive() const;
      jboolean isSynthetic() const;
      ::java::lang::Object newInstance() const;
      ::java::lang::String toGenericString() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Class);
    _dll_lucene extern PyTypeObject *PY_TYPE(Class);

    class _dll_lucene t_Class {
    public:
      PyObject_HEAD
      Class object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_Class *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Class&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Class&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
