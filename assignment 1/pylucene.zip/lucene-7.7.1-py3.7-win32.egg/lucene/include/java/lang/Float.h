#ifndef java_lang_Float_H
#define java_lang_Float_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class Float;
    class Class;
    class Object;
    class Comparable;
    class String;
    class NumberFormatException;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Float : public ::java::lang::Number {
     public:
      enum {
        mid_init$_0000000048822f5e,
        mid_init$_000000003e46d501,
        mid_init$_fffffffffc2a4e56,
        mid_byteValue_ffffffffb58647b4,
        mid_compare_000000004dd41e19,
        mid_compareTo_0000000027839461,
        mid_doubleValue_0000000046402c15,
        mid_equals_000000007b2e38e9,
        mid_floatToIntBits_ffffffff9f6f3b77,
        mid_floatToRawIntBits_ffffffff9f6f3b77,
        mid_floatValue_ffffffffee5e3be1,
        mid_hashCode_000000002043cb81,
        mid_hashCode_ffffffff9f6f3b77,
        mid_intBitsToFloat_ffffffffa0abd3c6,
        mid_intValue_000000002043cb81,
        mid_isFinite_ffffffffa65d80f3,
        mid_isInfinite_0000000000c0c182,
        mid_isInfinite_ffffffffa65d80f3,
        mid_isNaN_0000000000c0c182,
        mid_isNaN_ffffffffa65d80f3,
        mid_longValue_ffffffffb4c92ea6,
        mid_max_ffffffff9d55c698,
        mid_min_ffffffff9d55c698,
        mid_parseFloat_000000000416d205,
        mid_shortValue_00000000001347c2,
        mid_sum_ffffffff9d55c698,
        mid_toHexString_ffffffffc25c34b0,
        mid_toString_000000001d4fc793,
        mid_toString_ffffffffc25c34b0,
        mid_valueOf_00000000434301aa,
        mid_valueOf_000000004f457252,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Float(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Float(const Float& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jint MAX_EXPONENT;
      static jfloat MAX_VALUE;
      static jint MIN_EXPONENT;
      static jfloat MIN_NORMAL;
      static jfloat MIN_VALUE;
      static jfloat NEGATIVE_INFINITY;
      static jfloat NaN;
      static jfloat POSITIVE_INFINITY;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Float(const ::java::lang::String &);
      Float(jdouble);
      Float(jfloat);

      jbyte byteValue() const;
      static jint compare(jfloat, jfloat);
      jint compareTo(const Float &) const;
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      static jint floatToIntBits(jfloat);
      static jint floatToRawIntBits(jfloat);
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jfloat);
      static jfloat intBitsToFloat(jint);
      jint intValue() const;
      static jboolean isFinite(jfloat);
      jboolean isInfinite() const;
      static jboolean isInfinite(jfloat);
      jboolean isNaN() const;
      static jboolean isNaN(jfloat);
      jlong longValue() const;
      static jfloat max$(jfloat, jfloat);
      static jfloat min$(jfloat, jfloat);
      static jfloat parseFloat(const ::java::lang::String &);
      jshort shortValue() const;
      static jfloat sum(jfloat, jfloat);
      static ::java::lang::String toHexString(jfloat);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jfloat);
      static Float valueOf(jfloat);
      static Float valueOf(const ::java::lang::String &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Float);
    _dll_lucene extern PyTypeObject *PY_TYPE(Float);

    class _dll_lucene t_Float {
    public:
      PyObject_HEAD
      Float object;
      static PyObject *wrap_Object(const Float&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
