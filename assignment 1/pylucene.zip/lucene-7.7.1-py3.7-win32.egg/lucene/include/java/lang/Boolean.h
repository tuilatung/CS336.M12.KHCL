#ifndef java_lang_Boolean_H
#define java_lang_Boolean_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class Comparable;
    class String;
    class Boolean;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Boolean : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffd7cfea8c,
        mid_init$_0000000048822f5e,
        mid_booleanValue_0000000000c0c182,
        mid_compare_0000000016122751,
        mid_compareTo_0000000068d894cb,
        mid_equals_000000007b2e38e9,
        mid_getBoolean_ffffffffc94366ea,
        mid_hashCode_000000002043cb81,
        mid_hashCode_000000006b56ebdc,
        mid_logicalAnd_ffffffffad2ab262,
        mid_logicalOr_ffffffffad2ab262,
        mid_logicalXor_ffffffffad2ab262,
        mid_parseBoolean_ffffffffc94366ea,
        mid_toString_000000001d4fc793,
        mid_toString_000000002e6aae49,
        mid_valueOf_ffffffffa09ea2b2,
        mid_valueOf_ffffffffa62c93dc,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Boolean(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Boolean(const Boolean& obj) : ::java::lang::Object(obj) {}

      static Boolean *FALSE;
      static Boolean *TRUE;
      static ::java::lang::Class *TYPE;

      Boolean(jboolean);
      Boolean(const ::java::lang::String &);

      jboolean booleanValue() const;
      static jint compare(jboolean, jboolean);
      jint compareTo(const Boolean &) const;
      jboolean equals(const ::java::lang::Object &) const;
      static jboolean getBoolean(const ::java::lang::String &);
      jint hashCode() const;
      static jint hashCode(jboolean);
      static jboolean logicalAnd(jboolean, jboolean);
      static jboolean logicalOr(jboolean, jboolean);
      static jboolean logicalXor(jboolean, jboolean);
      static jboolean parseBoolean(const ::java::lang::String &);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jboolean);
      static Boolean valueOf(jboolean);
      static Boolean valueOf(const ::java::lang::String &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Boolean);
    _dll_lucene extern PyTypeObject *PY_TYPE(Boolean);

    class _dll_lucene t_Boolean {
    public:
      PyObject_HEAD
      Boolean object;
      static PyObject *wrap_Object(const Boolean&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
