#ifndef java_lang_Number_H
#define java_lang_Number_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class Serializable;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Number : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_byteValue_ffffffffb58647b4,
        mid_doubleValue_0000000046402c15,
        mid_floatValue_ffffffffee5e3be1,
        mid_intValue_000000002043cb81,
        mid_longValue_ffffffffb4c92ea6,
        mid_shortValue_00000000001347c2,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Number(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Number(const Number& obj) : ::java::lang::Object(obj) {}

      Number();

      jbyte byteValue() const;
      jdouble doubleValue() const;
      jfloat floatValue() const;
      jint intValue() const;
      jlong longValue() const;
      jshort shortValue() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Number);
    _dll_lucene extern PyTypeObject *PY_TYPE(Number);

    class _dll_lucene t_Number {
    public:
      PyObject_HEAD
      Number object;
      static PyObject *wrap_Object(const Number&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
