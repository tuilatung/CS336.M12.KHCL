#ifndef java_lang_Character_H
#define java_lang_Character_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class Comparable;
    class CharSequence;
    class Character;
    class String;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Character : public ::java::lang::Object {
     public:
      enum {
        mid_init$_000000005e56173b,
        mid_charCount_000000007930bd1c,
        mid_charValue_ffffffffb606c467,
        mid_codePointAt_000000002a7b9a9f,
        mid_codePointAt_000000004bc20cb9,
        mid_codePointAt_ffffffffc9e60873,
        mid_codePointBefore_000000004bc20cb9,
        mid_codePointBefore_000000002a7b9a9f,
        mid_codePointBefore_ffffffffc9e60873,
        mid_codePointCount_000000004cb19fa1,
        mid_codePointCount_ffffffffc9e60873,
        mid_compare_00000000538851f9,
        mid_compareTo_0000000076af0946,
        mid_digit_ffffffffbefe0b2f,
        mid_digit_ffffffff8e94c441,
        mid_equals_000000007b2e38e9,
        mid_forDigit_ffffffffd4c5901d,
        mid_getDirectionality_00000000650b48f4,
        mid_getDirectionality_0000000036747980,
        mid_getName_0000000026c48400,
        mid_getNumericValue_0000000006a24218,
        mid_getNumericValue_000000007930bd1c,
        mid_getType_0000000006a24218,
        mid_getType_000000007930bd1c,
        mid_hashCode_000000002043cb81,
        mid_hashCode_0000000006a24218,
        mid_highSurrogate_000000007fc4e57c,
        mid_isAlphabetic_0000000052d4339a,
        mid_isBmpCodePoint_0000000052d4339a,
        mid_isDefined_0000000052d4339a,
        mid_isDefined_ffffffffe9b4328a,
        mid_isDigit_0000000052d4339a,
        mid_isDigit_ffffffffe9b4328a,
        mid_isHighSurrogate_ffffffffe9b4328a,
        mid_isISOControl_0000000052d4339a,
        mid_isISOControl_ffffffffe9b4328a,
        mid_isIdentifierIgnorable_0000000052d4339a,
        mid_isIdentifierIgnorable_ffffffffe9b4328a,
        mid_isIdeographic_0000000052d4339a,
        mid_isJavaIdentifierPart_0000000052d4339a,
        mid_isJavaIdentifierPart_ffffffffe9b4328a,
        mid_isJavaIdentifierStart_ffffffffe9b4328a,
        mid_isJavaIdentifierStart_0000000052d4339a,
        mid_isJavaLetter_ffffffffe9b4328a,
        mid_isJavaLetterOrDigit_ffffffffe9b4328a,
        mid_isLetter_ffffffffe9b4328a,
        mid_isLetter_0000000052d4339a,
        mid_isLetterOrDigit_ffffffffe9b4328a,
        mid_isLetterOrDigit_0000000052d4339a,
        mid_isLowSurrogate_ffffffffe9b4328a,
        mid_isLowerCase_ffffffffe9b4328a,
        mid_isLowerCase_0000000052d4339a,
        mid_isMirrored_ffffffffe9b4328a,
        mid_isMirrored_0000000052d4339a,
        mid_isSpace_ffffffffe9b4328a,
        mid_isSpaceChar_ffffffffe9b4328a,
        mid_isSpaceChar_0000000052d4339a,
        mid_isSupplementaryCodePoint_0000000052d4339a,
        mid_isSurrogate_ffffffffe9b4328a,
        mid_isSurrogatePair_000000000a74894f,
        mid_isTitleCase_ffffffffe9b4328a,
        mid_isTitleCase_0000000052d4339a,
        mid_isUnicodeIdentifierPart_ffffffffe9b4328a,
        mid_isUnicodeIdentifierPart_0000000052d4339a,
        mid_isUnicodeIdentifierStart_ffffffffe9b4328a,
        mid_isUnicodeIdentifierStart_0000000052d4339a,
        mid_isUpperCase_0000000052d4339a,
        mid_isUpperCase_ffffffffe9b4328a,
        mid_isValidCodePoint_0000000052d4339a,
        mid_isWhitespace_ffffffffe9b4328a,
        mid_isWhitespace_0000000052d4339a,
        mid_lowSurrogate_000000007fc4e57c,
        mid_offsetByCodePoints_000000004cb19fa1,
        mid_offsetByCodePoints_ffffffffebdd466d,
        mid_reverseBytes_00000000787f5354,
        mid_toChars_000000004f585a36,
        mid_toChars_00000000242532ff,
        mid_toCodePoint_00000000538851f9,
        mid_toLowerCase_000000007930bd1c,
        mid_toLowerCase_00000000787f5354,
        mid_toString_000000001d4fc793,
        mid_toString_000000005a3d97d7,
        mid_toTitleCase_00000000787f5354,
        mid_toTitleCase_000000007930bd1c,
        mid_toUpperCase_000000007930bd1c,
        mid_toUpperCase_00000000787f5354,
        mid_valueOf_00000000574969f0,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Character(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Character(const Character& obj) : ::java::lang::Object(obj) {}

      static jint BYTES;
      static jbyte COMBINING_SPACING_MARK;
      static jbyte CONNECTOR_PUNCTUATION;
      static jbyte CONTROL;
      static jbyte CURRENCY_SYMBOL;
      static jbyte DASH_PUNCTUATION;
      static jbyte DECIMAL_DIGIT_NUMBER;
      static jbyte DIRECTIONALITY_ARABIC_NUMBER;
      static jbyte DIRECTIONALITY_BOUNDARY_NEUTRAL;
      static jbyte DIRECTIONALITY_COMMON_NUMBER_SEPARATOR;
      static jbyte DIRECTIONALITY_EUROPEAN_NUMBER;
      static jbyte DIRECTIONALITY_EUROPEAN_NUMBER_SEPARATOR;
      static jbyte DIRECTIONALITY_EUROPEAN_NUMBER_TERMINATOR;
      static jbyte DIRECTIONALITY_LEFT_TO_RIGHT;
      static jbyte DIRECTIONALITY_LEFT_TO_RIGHT_EMBEDDING;
      static jbyte DIRECTIONALITY_LEFT_TO_RIGHT_OVERRIDE;
      static jbyte DIRECTIONALITY_NONSPACING_MARK;
      static jbyte DIRECTIONALITY_OTHER_NEUTRALS;
      static jbyte DIRECTIONALITY_PARAGRAPH_SEPARATOR;
      static jbyte DIRECTIONALITY_POP_DIRECTIONAL_FORMAT;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT_EMBEDDING;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT_OVERRIDE;
      static jbyte DIRECTIONALITY_SEGMENT_SEPARATOR;
      static jbyte DIRECTIONALITY_UNDEFINED;
      static jbyte DIRECTIONALITY_WHITESPACE;
      static jbyte ENCLOSING_MARK;
      static jbyte END_PUNCTUATION;
      static jbyte FINAL_QUOTE_PUNCTUATION;
      static jbyte FORMAT;
      static jbyte INITIAL_QUOTE_PUNCTUATION;
      static jbyte LETTER_NUMBER;
      static jbyte LINE_SEPARATOR;
      static jbyte LOWERCASE_LETTER;
      static jbyte MATH_SYMBOL;
      static jint MAX_CODE_POINT;
      static jchar MAX_HIGH_SURROGATE;
      static jchar MAX_LOW_SURROGATE;
      static jint MAX_RADIX;
      static jchar MAX_SURROGATE;
      static jchar MAX_VALUE;
      static jint MIN_CODE_POINT;
      static jchar MIN_HIGH_SURROGATE;
      static jchar MIN_LOW_SURROGATE;
      static jint MIN_RADIX;
      static jint MIN_SUPPLEMENTARY_CODE_POINT;
      static jchar MIN_SURROGATE;
      static jchar MIN_VALUE;
      static jbyte MODIFIER_LETTER;
      static jbyte MODIFIER_SYMBOL;
      static jbyte NON_SPACING_MARK;
      static jbyte OTHER_LETTER;
      static jbyte OTHER_NUMBER;
      static jbyte OTHER_PUNCTUATION;
      static jbyte OTHER_SYMBOL;
      static jbyte PARAGRAPH_SEPARATOR;
      static jbyte PRIVATE_USE;
      static jint SIZE;
      static jbyte SPACE_SEPARATOR;
      static jbyte START_PUNCTUATION;
      static jbyte SURROGATE;
      static jbyte TITLECASE_LETTER;
      static ::java::lang::Class *TYPE;
      static jbyte UNASSIGNED;
      static jbyte UPPERCASE_LETTER;

      Character(jchar);

      static jint charCount(jint);
      jchar charValue() const;
      static jint codePointAt(const ::java::lang::CharSequence &, jint);
      static jint codePointAt(const JArray< jchar > &, jint);
      static jint codePointAt(const JArray< jchar > &, jint, jint);
      static jint codePointBefore(const JArray< jchar > &, jint);
      static jint codePointBefore(const ::java::lang::CharSequence &, jint);
      static jint codePointBefore(const JArray< jchar > &, jint, jint);
      static jint codePointCount(const ::java::lang::CharSequence &, jint, jint);
      static jint codePointCount(const JArray< jchar > &, jint, jint);
      static jint compare(jchar, jchar);
      jint compareTo(const Character &) const;
      static jint digit(jint, jint);
      static jint digit(jchar, jint);
      jboolean equals(const ::java::lang::Object &) const;
      static jchar forDigit(jint, jint);
      static jbyte getDirectionality(jint);
      static jbyte getDirectionality(jchar);
      static ::java::lang::String getName(jint);
      static jint getNumericValue(jchar);
      static jint getNumericValue(jint);
      static jint getType(jchar);
      static jint getType(jint);
      jint hashCode() const;
      static jint hashCode(jchar);
      static jchar highSurrogate(jint);
      static jboolean isAlphabetic(jint);
      static jboolean isBmpCodePoint(jint);
      static jboolean isDefined(jint);
      static jboolean isDefined(jchar);
      static jboolean isDigit(jint);
      static jboolean isDigit(jchar);
      static jboolean isHighSurrogate(jchar);
      static jboolean isISOControl(jint);
      static jboolean isISOControl(jchar);
      static jboolean isIdentifierIgnorable(jint);
      static jboolean isIdentifierIgnorable(jchar);
      static jboolean isIdeographic(jint);
      static jboolean isJavaIdentifierPart(jint);
      static jboolean isJavaIdentifierPart(jchar);
      static jboolean isJavaIdentifierStart(jchar);
      static jboolean isJavaIdentifierStart(jint);
      static jboolean isJavaLetter(jchar);
      static jboolean isJavaLetterOrDigit(jchar);
      static jboolean isLetter(jchar);
      static jboolean isLetter(jint);
      static jboolean isLetterOrDigit(jchar);
      static jboolean isLetterOrDigit(jint);
      static jboolean isLowSurrogate(jchar);
      static jboolean isLowerCase(jchar);
      static jboolean isLowerCase(jint);
      static jboolean isMirrored(jchar);
      static jboolean isMirrored(jint);
      static jboolean isSpace(jchar);
      static jboolean isSpaceChar(jchar);
      static jboolean isSpaceChar(jint);
      static jboolean isSupplementaryCodePoint(jint);
      static jboolean isSurrogate(jchar);
      static jboolean isSurrogatePair(jchar, jchar);
      static jboolean isTitleCase(jchar);
      static jboolean isTitleCase(jint);
      static jboolean isUnicodeIdentifierPart(jchar);
      static jboolean isUnicodeIdentifierPart(jint);
      static jboolean isUnicodeIdentifierStart(jchar);
      static jboolean isUnicodeIdentifierStart(jint);
      static jboolean isUpperCase(jint);
      static jboolean isUpperCase(jchar);
      static jboolean isValidCodePoint(jint);
      static jboolean isWhitespace(jchar);
      static jboolean isWhitespace(jint);
      static jchar lowSurrogate(jint);
      static jint offsetByCodePoints(const ::java::lang::CharSequence &, jint, jint);
      static jint offsetByCodePoints(const JArray< jchar > &, jint, jint, jint, jint);
      static jchar reverseBytes(jchar);
      static JArray< jchar > toChars(jint);
      static jint toChars(jint, const JArray< jchar > &, jint);
      static jint toCodePoint(jchar, jchar);
      static jint toLowerCase(jint);
      static jchar toLowerCase(jchar);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jchar);
      static jchar toTitleCase(jchar);
      static jint toTitleCase(jint);
      static jint toUpperCase(jint);
      static jchar toUpperCase(jchar);
      static Character valueOf(jchar);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Character);
    _dll_lucene extern PyTypeObject *PY_TYPE(Character);

    class _dll_lucene t_Character {
    public:
      PyObject_HEAD
      Character object;
      static PyObject *wrap_Object(const Character&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
