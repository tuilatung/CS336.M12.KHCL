#ifndef java_lang_StringBuffer_H
#define java_lang_StringBuffer_H

#include "java/lang/AbstractStringBuilder.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class Object;
    class CharSequence;
    class String;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene StringBuffer : public ::java::lang::AbstractStringBuilder {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffb7151c43,
        mid_init$_0000000048822f5e,
        mid_init$_ffffffffa0b31ff5,
        mid_append_fffffffff27c7db3,
        mid_append_ffffffffc89786a5,
        mid_append_000000002478a4d5,
        mid_append_000000001d7afb8a,
        mid_append_ffffffffdd7a68dc,
        mid_append_000000006afc57a1,
        mid_append_ffffffff984d3374,
        mid_append_00000000477c626b,
        mid_append_ffffffffc5d847c4,
        mid_append_ffffffffca808d2e,
        mid_append_ffffffffee56684d,
        mid_append_000000002aafd9bc,
        mid_append_ffffffffac2c65a4,
        mid_appendCodePoint_ffffffffdd7a68dc,
        mid_capacity_000000002043cb81,
        mid_charAt_000000007fc4e57c,
        mid_codePointAt_000000007930bd1c,
        mid_codePointBefore_000000007930bd1c,
        mid_codePointCount_ffffffffbefe0b2f,
        mid_delete_0000000058b19a3e,
        mid_deleteCharAt_ffffffffdd7a68dc,
        mid_ensureCapacity_ffffffffa0b31ff5,
        mid_getChars_ffffffffbc4221b9,
        mid_indexOf_0000000026f4dfbe,
        mid_indexOf_ffffffffb3f873c8,
        mid_insert_ffffffffaa67c0b8,
        mid_insert_ffffffffb84ce254,
        mid_insert_ffffffff9dbd4182,
        mid_insert_0000000058b19a3e,
        mid_insert_ffffffff924cd80a,
        mid_insert_00000000663bb0c5,
        mid_insert_ffffffff865c3706,
        mid_insert_fffffffff9aacc48,
        mid_insert_000000004ca4406c,
        mid_insert_ffffffffa4d4f9f8,
        mid_insert_fffffffff7267ecb,
        mid_insert_ffffffffd030892f,
        mid_lastIndexOf_0000000026f4dfbe,
        mid_lastIndexOf_ffffffffb3f873c8,
        mid_length_000000002043cb81,
        mid_offsetByCodePoints_ffffffffbefe0b2f,
        mid_replace_ffffffffeab03261,
        mid_reverse_ffffffffe3d2e3e6,
        mid_setCharAt_00000000680774e8,
        mid_setLength_ffffffffa0b31ff5,
        mid_subSequence_ffffffffe01cf115,
        mid_substring_0000000026c48400,
        mid_substring_000000001f671572,
        mid_toString_000000001d4fc793,
        mid_trimToSize_ffffffffde902c42,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit StringBuffer(jobject obj) : ::java::lang::AbstractStringBuilder(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      StringBuffer(const StringBuffer& obj) : ::java::lang::AbstractStringBuilder(obj) {}

      StringBuffer();
      StringBuffer(const ::java::lang::CharSequence &);
      StringBuffer(const ::java::lang::String &);
      StringBuffer(jint);

      StringBuffer append(jfloat) const;
      StringBuffer append(jdouble) const;
      StringBuffer append(jboolean) const;
      StringBuffer append(jchar) const;
      StringBuffer append(jint) const;
      StringBuffer append(jlong) const;
      StringBuffer append(const ::java::lang::Object &) const;
      StringBuffer append(const ::java::lang::String &) const;
      StringBuffer append(const ::java::lang::CharSequence &) const;
      StringBuffer append(const JArray< jchar > &) const;
      StringBuffer append(const StringBuffer &) const;
      StringBuffer append(const ::java::lang::CharSequence &, jint, jint) const;
      StringBuffer append(const JArray< jchar > &, jint, jint) const;
      StringBuffer appendCodePoint(jint) const;
      jint capacity() const;
      jchar charAt(jint) const;
      jint codePointAt(jint) const;
      jint codePointBefore(jint) const;
      jint codePointCount(jint, jint) const;
      StringBuffer delete$(jint, jint) const;
      StringBuffer deleteCharAt(jint) const;
      void ensureCapacity(jint) const;
      void getChars(jint, jint, const JArray< jchar > &, jint) const;
      jint indexOf(const ::java::lang::String &) const;
      jint indexOf(const ::java::lang::String &, jint) const;
      StringBuffer insert(jint, const ::java::lang::CharSequence &) const;
      StringBuffer insert(jint, jboolean) const;
      StringBuffer insert(jint, jchar) const;
      StringBuffer insert(jint, jint) const;
      StringBuffer insert(jint, jfloat) const;
      StringBuffer insert(jint, jdouble) const;
      StringBuffer insert(jint, const ::java::lang::Object &) const;
      StringBuffer insert(jint, const ::java::lang::String &) const;
      StringBuffer insert(jint, const JArray< jchar > &) const;
      StringBuffer insert(jint, jlong) const;
      StringBuffer insert(jint, const ::java::lang::CharSequence &, jint, jint) const;
      StringBuffer insert(jint, const JArray< jchar > &, jint, jint) const;
      jint lastIndexOf(const ::java::lang::String &) const;
      jint lastIndexOf(const ::java::lang::String &, jint) const;
      jint length() const;
      jint offsetByCodePoints(jint, jint) const;
      StringBuffer replace(jint, jint, const ::java::lang::String &) const;
      StringBuffer reverse() const;
      void setCharAt(jint, jchar) const;
      void setLength(jint) const;
      ::java::lang::CharSequence subSequence(jint, jint) const;
      ::java::lang::String substring(jint) const;
      ::java::lang::String substring(jint, jint) const;
      ::java::lang::String toString() const;
      void trimToSize() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(StringBuffer);
    _dll_lucene extern PyTypeObject *PY_TYPE(StringBuffer);

    class _dll_lucene t_StringBuffer {
    public:
      PyObject_HEAD
      StringBuffer object;
      static PyObject *wrap_Object(const StringBuffer&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
