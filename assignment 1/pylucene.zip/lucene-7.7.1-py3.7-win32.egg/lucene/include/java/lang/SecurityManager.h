#ifndef java_lang_SecurityManager_H
#define java_lang_SecurityManager_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class ThreadGroup;
    class String;
    class Thread;
  }
  namespace io {
    class FileDescriptor;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene SecurityManager : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_checkAccept_ffffffffea1f9590,
        mid_checkAccess_fffffffff71f9ece,
        mid_checkAccess_000000003eb067cc,
        mid_checkAwtEventQueueAccess_ffffffffde902c42,
        mid_checkConnect_ffffffffea1f9590,
        mid_checkConnect_000000000e35d22d,
        mid_checkCreateClassLoader_ffffffffde902c42,
        mid_checkDelete_0000000048822f5e,
        mid_checkExec_0000000048822f5e,
        mid_checkExit_ffffffffa0b31ff5,
        mid_checkLink_0000000048822f5e,
        mid_checkListen_ffffffffa0b31ff5,
        mid_checkMemberAccess_000000001edbb43b,
        mid_checkPackageAccess_0000000048822f5e,
        mid_checkPackageDefinition_0000000048822f5e,
        mid_checkPrintJobAccess_ffffffffde902c42,
        mid_checkPropertiesAccess_ffffffffde902c42,
        mid_checkPropertyAccess_0000000048822f5e,
        mid_checkRead_0000000048822f5e,
        mid_checkRead_00000000590559a4,
        mid_checkRead_ffffffff9ef1a0eb,
        mid_checkSecurityAccess_0000000048822f5e,
        mid_checkSetFactory_ffffffffde902c42,
        mid_checkSystemClipboardAccess_ffffffffde902c42,
        mid_checkTopLevelWindow_000000007b2e38e9,
        mid_checkWrite_0000000048822f5e,
        mid_checkWrite_00000000590559a4,
        mid_getInCheck_0000000000c0c182,
        mid_getSecurityContext_ffffffffdcc2e1cc,
        mid_getThreadGroup_0000000050db18ea,
        mid_getClassContext_000000005195133c,
        mid_classDepth_0000000026f4dfbe,
        mid_classLoaderDepth_000000002043cb81,
        mid_currentClassLoader_ffffffff8730a17b,
        mid_currentLoadedClass_000000001a21d18a,
        mid_inClass_ffffffffc94366ea,
        mid_inClassLoader_0000000000c0c182,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SecurityManager(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SecurityManager(const SecurityManager& obj) : ::java::lang::Object(obj) {}

      SecurityManager();

      void checkAccept(const ::java::lang::String &, jint) const;
      void checkAccess(const ::java::lang::ThreadGroup &) const;
      void checkAccess(const ::java::lang::Thread &) const;
      void checkAwtEventQueueAccess() const;
      void checkConnect(const ::java::lang::String &, jint) const;
      void checkConnect(const ::java::lang::String &, jint, const ::java::lang::Object &) const;
      void checkCreateClassLoader() const;
      void checkDelete(const ::java::lang::String &) const;
      void checkExec(const ::java::lang::String &) const;
      void checkExit(jint) const;
      void checkLink(const ::java::lang::String &) const;
      void checkListen(jint) const;
      void checkMemberAccess(const ::java::lang::Class &, jint) const;
      void checkPackageAccess(const ::java::lang::String &) const;
      void checkPackageDefinition(const ::java::lang::String &) const;
      void checkPrintJobAccess() const;
      void checkPropertiesAccess() const;
      void checkPropertyAccess(const ::java::lang::String &) const;
      void checkRead(const ::java::lang::String &) const;
      void checkRead(const ::java::io::FileDescriptor &) const;
      void checkRead(const ::java::lang::String &, const ::java::lang::Object &) const;
      void checkSecurityAccess(const ::java::lang::String &) const;
      void checkSetFactory() const;
      void checkSystemClipboardAccess() const;
      jboolean checkTopLevelWindow(const ::java::lang::Object &) const;
      void checkWrite(const ::java::lang::String &) const;
      void checkWrite(const ::java::io::FileDescriptor &) const;
      jboolean getInCheck() const;
      ::java::lang::Object getSecurityContext() const;
      ::java::lang::ThreadGroup getThreadGroup() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(SecurityManager);
    _dll_lucene extern PyTypeObject *PY_TYPE(SecurityManager);

    class _dll_lucene t_SecurityManager {
    public:
      PyObject_HEAD
      SecurityManager object;
      static PyObject *wrap_Object(const SecurityManager&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
