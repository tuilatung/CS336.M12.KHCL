#ifndef java_lang_Object_H
#define java_lang_Object_H

#include "JObject.h"

namespace java {
  namespace lang {
    class Object;
    class String;
    class InterruptedException;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Object : public ::JObject {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_equals_000000007b2e38e9,
        mid_getClass_000000001a21d18a,
        mid_hashCode_000000002043cb81,
        mid_notify_ffffffffde902c42,
        mid_notifyAll_ffffffffde902c42,
        mid_toString_000000001d4fc793,
        mid_wait_ffffffffde902c42,
        mid_wait_ffffffff985e9c5c,
        mid_wait_fffffffff251986f,
        mid_finalize_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Object(jobject obj) : ::JObject(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Object(const Object& obj) : ::JObject(obj) {}

      Object();

      jboolean equals(const Object &) const;
      ::java::lang::Class getClass() const;
      jint hashCode() const;
      void notify() const;
      void notifyAll() const;
      ::java::lang::String toString() const;
      void wait() const;
      void wait(jlong) const;
      void wait(jlong, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Object);
    _dll_lucene extern PyTypeObject *PY_TYPE(Object);

    class _dll_lucene t_Object {
    public:
      PyObject_HEAD
      Object object;
      static PyObject *wrap_Object(const Object&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
