#ifndef java_lang_AbstractStringBuilder_H
#define java_lang_AbstractStringBuilder_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class AbstractStringBuilder;
    class Appendable;
    class CharSequence;
    class String;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene AbstractStringBuilder : public ::java::lang::Object {
     public:
      enum {
        mid_append_0000000044758455,
        mid_append_ffffffff871df2ec,
        mid_append_ffffffffcb6406a9,
        mid_append_000000006add50b5,
        mid_append_ffffffffdfa74820,
        mid_append_000000001f2544cb,
        mid_append_0000000055feefc4,
        mid_append_ffffffffb645f295,
        mid_append_0000000063be65d7,
        mid_append_000000007a72e3e3,
        mid_append_ffffffffe936d82b,
        mid_append_fffffffff66138df,
        mid_append_00000000544b8940,
        mid_appendCodePoint_0000000063be65d7,
        mid_capacity_000000002043cb81,
        mid_charAt_000000007fc4e57c,
        mid_codePointAt_000000007930bd1c,
        mid_codePointBefore_000000007930bd1c,
        mid_codePointCount_ffffffffbefe0b2f,
        mid_delete_0000000031864fca,
        mid_deleteCharAt_0000000063be65d7,
        mid_ensureCapacity_ffffffffa0b31ff5,
        mid_getChars_ffffffffbc4221b9,
        mid_indexOf_0000000026f4dfbe,
        mid_indexOf_ffffffffb3f873c8,
        mid_insert_ffffffffd6ce8242,
        mid_insert_0000000031864fca,
        mid_insert_00000000587f9817,
        mid_insert_ffffffffec9b1ec3,
        mid_insert_ffffffffde45821e,
        mid_insert_00000000596c9e0d,
        mid_insert_ffffffffe4e81c8c,
        mid_insert_ffffffff9d5be865,
        mid_insert_000000000cb52226,
        mid_insert_000000007b8d99e0,
        mid_insert_fffffffffe14de2b,
        mid_insert_ffffffff9961e86c,
        mid_lastIndexOf_0000000026f4dfbe,
        mid_lastIndexOf_ffffffffb3f873c8,
        mid_length_000000002043cb81,
        mid_offsetByCodePoints_ffffffffbefe0b2f,
        mid_replace_ffffffff96926a4f,
        mid_reverse_00000000595a1e24,
        mid_setCharAt_00000000680774e8,
        mid_setLength_ffffffffa0b31ff5,
        mid_subSequence_ffffffffe01cf115,
        mid_substring_0000000026c48400,
        mid_substring_000000001f671572,
        mid_toString_000000001d4fc793,
        mid_trimToSize_ffffffffde902c42,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit AbstractStringBuilder(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      AbstractStringBuilder(const AbstractStringBuilder& obj) : ::java::lang::Object(obj) {}

      AbstractStringBuilder append(const JArray< jchar > &) const;
      AbstractStringBuilder append(jboolean) const;
      AbstractStringBuilder append(jchar) const;
      AbstractStringBuilder append(const ::java::lang::CharSequence &) const;
      AbstractStringBuilder append(const ::java::lang::StringBuffer &) const;
      AbstractStringBuilder append(jdouble) const;
      AbstractStringBuilder append(jfloat) const;
      AbstractStringBuilder append(jlong) const;
      AbstractStringBuilder append(jint) const;
      AbstractStringBuilder append(const ::java::lang::String &) const;
      AbstractStringBuilder append(const ::java::lang::Object &) const;
      AbstractStringBuilder append(const JArray< jchar > &, jint, jint) const;
      AbstractStringBuilder append(const ::java::lang::CharSequence &, jint, jint) const;
      AbstractStringBuilder appendCodePoint(jint) const;
      jint capacity() const;
      jchar charAt(jint) const;
      jint codePointAt(jint) const;
      jint codePointBefore(jint) const;
      jint codePointCount(jint, jint) const;
      AbstractStringBuilder delete$(jint, jint) const;
      AbstractStringBuilder deleteCharAt(jint) const;
      void ensureCapacity(jint) const;
      void getChars(jint, jint, const JArray< jchar > &, jint) const;
      jint indexOf(const ::java::lang::String &) const;
      jint indexOf(const ::java::lang::String &, jint) const;
      AbstractStringBuilder insert(jint, jlong) const;
      AbstractStringBuilder insert(jint, jint) const;
      AbstractStringBuilder insert(jint, jchar) const;
      AbstractStringBuilder insert(jint, jboolean) const;
      AbstractStringBuilder insert(jint, jfloat) const;
      AbstractStringBuilder insert(jint, jdouble) const;
      AbstractStringBuilder insert(jint, const ::java::lang::Object &) const;
      AbstractStringBuilder insert(jint, const ::java::lang::String &) const;
      AbstractStringBuilder insert(jint, const JArray< jchar > &) const;
      AbstractStringBuilder insert(jint, const ::java::lang::CharSequence &) const;
      AbstractStringBuilder insert(jint, const JArray< jchar > &, jint, jint) const;
      AbstractStringBuilder insert(jint, const ::java::lang::CharSequence &, jint, jint) const;
      jint lastIndexOf(const ::java::lang::String &) const;
      jint lastIndexOf(const ::java::lang::String &, jint) const;
      jint length() const;
      jint offsetByCodePoints(jint, jint) const;
      AbstractStringBuilder replace(jint, jint, const ::java::lang::String &) const;
      AbstractStringBuilder reverse() const;
      void setCharAt(jint, jchar) const;
      void setLength(jint) const;
      ::java::lang::CharSequence subSequence(jint, jint) const;
      ::java::lang::String substring(jint) const;
      ::java::lang::String substring(jint, jint) const;
      ::java::lang::String toString() const;
      void trimToSize() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(AbstractStringBuilder);
    _dll_lucene extern PyTypeObject *PY_TYPE(AbstractStringBuilder);

    class _dll_lucene t_AbstractStringBuilder {
    public:
      PyObject_HEAD
      AbstractStringBuilder object;
      static PyObject *wrap_Object(const AbstractStringBuilder&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
