#ifndef java_lang_Thread_H
#define java_lang_Thread_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Thread$UncaughtExceptionHandler;
    class Thread$State;
    class InterruptedException;
    class Class;
    class ThreadGroup;
    class Runnable;
    class StackTraceElement;
    class String;
    class ClassLoader;
    class Thread;
    class Throwable;
  }
  namespace util {
    class Map;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Thread : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffe6fa4421,
        mid_init$_0000000048822f5e,
        mid_init$_0000000034ff9f7a,
        mid_init$_ffffffffb3c4a58b,
        mid_init$_ffffffffd6ee89a5,
        mid_init$_0000000040dce8a4,
        mid_init$_ffffffff94a0a825,
        mid_activeCount_000000002043cb81,
        mid_checkAccess_ffffffffde902c42,
        mid_countStackFrames_000000002043cb81,
        mid_currentThread_00000000727dbb50,
        mid_destroy_ffffffffde902c42,
        mid_dumpStack_ffffffffde902c42,
        mid_enumerate_00000000208b6c5b,
        mid_getAllStackTraces_000000007d6a46b0,
        mid_getContextClassLoader_ffffffff8730a17b,
        mid_getDefaultUncaughtExceptionHandler_0000000045428f7b,
        mid_getId_ffffffffb4c92ea6,
        mid_getName_000000001d4fc793,
        mid_getPriority_000000002043cb81,
        mid_getStackTrace_ffffffffafa093a2,
        mid_getState_0000000008d3c187,
        mid_getThreadGroup_0000000050db18ea,
        mid_getUncaughtExceptionHandler_0000000045428f7b,
        mid_holdsLock_000000007b2e38e9,
        mid_interrupt_ffffffffde902c42,
        mid_interrupted_0000000000c0c182,
        mid_isAlive_0000000000c0c182,
        mid_isDaemon_0000000000c0c182,
        mid_isInterrupted_0000000000c0c182,
        mid_join_ffffffffde902c42,
        mid_join_ffffffff985e9c5c,
        mid_join_fffffffff251986f,
        mid_resume_ffffffffde902c42,
        mid_run_ffffffffde902c42,
        mid_setContextClassLoader_000000004e63561a,
        mid_setDaemon_ffffffffd7cfea8c,
        mid_setDefaultUncaughtExceptionHandler_000000005bc61c90,
        mid_setName_0000000048822f5e,
        mid_setPriority_ffffffffa0b31ff5,
        mid_setUncaughtExceptionHandler_000000005bc61c90,
        mid_sleep_ffffffff985e9c5c,
        mid_sleep_fffffffff251986f,
        mid_start_ffffffffde902c42,
        mid_stop_ffffffffde902c42,
        mid_stop_0000000011312d29,
        mid_suspend_ffffffffde902c42,
        mid_toString_000000001d4fc793,
        mid_yield_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Thread(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Thread(const Thread& obj) : ::java::lang::Object(obj) {}

      static jint MAX_PRIORITY;
      static jint MIN_PRIORITY;
      static jint NORM_PRIORITY;

      Thread();
      Thread(const ::java::lang::Runnable &);
      Thread(const ::java::lang::String &);
      Thread(const ::java::lang::Runnable &, const ::java::lang::String &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::String &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::Runnable &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::Runnable &, const ::java::lang::String &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::Runnable &, const ::java::lang::String &, jlong);

      static jint activeCount();
      void checkAccess() const;
      jint countStackFrames() const;
      static Thread currentThread();
      void destroy() const;
      static void dumpStack();
      static jint enumerate(const JArray< Thread > &);
      static ::java::util::Map getAllStackTraces();
      ::java::lang::ClassLoader getContextClassLoader() const;
      static ::java::lang::Thread$UncaughtExceptionHandler getDefaultUncaughtExceptionHandler();
      jlong getId() const;
      ::java::lang::String getName() const;
      jint getPriority() const;
      JArray< ::java::lang::StackTraceElement > getStackTrace() const;
      ::java::lang::Thread$State getState() const;
      ::java::lang::ThreadGroup getThreadGroup() const;
      ::java::lang::Thread$UncaughtExceptionHandler getUncaughtExceptionHandler() const;
      static jboolean holdsLock(const ::java::lang::Object &);
      void interrupt() const;
      static jboolean interrupted();
      jboolean isAlive() const;
      jboolean isDaemon() const;
      jboolean isInterrupted() const;
      void join() const;
      void join(jlong) const;
      void join(jlong, jint) const;
      void resume() const;
      void run() const;
      void setContextClassLoader(const ::java::lang::ClassLoader &) const;
      void setDaemon(jboolean) const;
      static void setDefaultUncaughtExceptionHandler(const ::java::lang::Thread$UncaughtExceptionHandler &);
      void setName(const ::java::lang::String &) const;
      void setPriority(jint) const;
      void setUncaughtExceptionHandler(const ::java::lang::Thread$UncaughtExceptionHandler &) const;
      static void sleep(jlong);
      static void sleep(jlong, jint);
      void start() const;
      void stop() const;
      void stop(const ::java::lang::Throwable &) const;
      void suspend() const;
      ::java::lang::String toString() const;
      static void yield();
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Thread);
    _dll_lucene extern PyTypeObject *PY_TYPE(Thread);

    class _dll_lucene t_Thread {
    public:
      PyObject_HEAD
      Thread object;
      static PyObject *wrap_Object(const Thread&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
