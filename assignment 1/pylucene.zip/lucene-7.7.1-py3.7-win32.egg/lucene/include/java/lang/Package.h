#ifndef java_lang_Package_H
#define java_lang_Package_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class NumberFormatException;
    class String;
    class Package;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Package : public ::java::lang::Object {
     public:
      enum {
        mid_getImplementationTitle_000000001d4fc793,
        mid_getImplementationVendor_000000001d4fc793,
        mid_getImplementationVersion_000000001d4fc793,
        mid_getName_000000001d4fc793,
        mid_getPackage_ffffffff8a5d8af2,
        mid_getPackages_000000000c338e58,
        mid_getSpecificationTitle_000000001d4fc793,
        mid_getSpecificationVendor_000000001d4fc793,
        mid_getSpecificationVersion_000000001d4fc793,
        mid_hashCode_000000002043cb81,
        mid_isCompatibleWith_ffffffffc94366ea,
        mid_isSealed_0000000000c0c182,
        mid_toString_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Package(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Package(const Package& obj) : ::java::lang::Object(obj) {}

      ::java::lang::String getImplementationTitle() const;
      ::java::lang::String getImplementationVendor() const;
      ::java::lang::String getImplementationVersion() const;
      ::java::lang::String getName() const;
      static Package getPackage(const ::java::lang::String &);
      static JArray< Package > getPackages();
      ::java::lang::String getSpecificationTitle() const;
      ::java::lang::String getSpecificationVendor() const;
      ::java::lang::String getSpecificationVersion() const;
      jint hashCode() const;
      jboolean isCompatibleWith(const ::java::lang::String &) const;
      jboolean isSealed() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Package);
    _dll_lucene extern PyTypeObject *PY_TYPE(Package);

    class _dll_lucene t_Package {
    public:
      PyObject_HEAD
      Package object;
      static PyObject *wrap_Object(const Package&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
