#ifndef java_lang_Long_H
#define java_lang_Long_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class Long;
    class Class;
    class Object;
    class Comparable;
    class String;
    class NumberFormatException;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Long : public ::java::lang::Number {
     public:
      enum {
        mid_init$_ffffffff985e9c5c,
        mid_init$_0000000048822f5e,
        mid_bitCount_0000000051dc7901,
        mid_byteValue_ffffffffb58647b4,
        mid_compare_000000005632f05a,
        mid_compareTo_ffffffff9d56ecd7,
        mid_compareUnsigned_000000005632f05a,
        mid_decode_ffffffff9c9fd382,
        mid_divideUnsigned_000000000588491e,
        mid_doubleValue_0000000046402c15,
        mid_equals_000000007b2e38e9,
        mid_floatValue_ffffffffee5e3be1,
        mid_getLong_ffffffff9c9fd382,
        mid_getLong_ffffffffed2f7d91,
        mid_getLong_ffffffff94aba00e,
        mid_hashCode_000000002043cb81,
        mid_hashCode_0000000051dc7901,
        mid_highestOneBit_0000000032d92391,
        mid_intValue_000000002043cb81,
        mid_longValue_ffffffffb4c92ea6,
        mid_lowestOneBit_0000000032d92391,
        mid_max_000000000588491e,
        mid_min_000000000588491e,
        mid_numberOfLeadingZeros_0000000051dc7901,
        mid_numberOfTrailingZeros_0000000051dc7901,
        mid_parseLong_ffffffff8bdd7b1d,
        mid_parseLong_0000000054ec13ae,
        mid_parseUnsignedLong_ffffffff8bdd7b1d,
        mid_parseUnsignedLong_0000000054ec13ae,
        mid_remainderUnsigned_000000000588491e,
        mid_reverse_0000000032d92391,
        mid_reverseBytes_0000000032d92391,
        mid_rotateLeft_ffffffff9230d505,
        mid_rotateRight_ffffffff9230d505,
        mid_shortValue_00000000001347c2,
        mid_signum_0000000051dc7901,
        mid_sum_000000000588491e,
        mid_toBinaryString_ffffffffcf2540a8,
        mid_toHexString_ffffffffcf2540a8,
        mid_toOctalString_ffffffffcf2540a8,
        mid_toString_000000001d4fc793,
        mid_toString_ffffffffcf2540a8,
        mid_toString_ffffffffb1811168,
        mid_toUnsignedString_ffffffffcf2540a8,
        mid_toUnsignedString_ffffffffb1811168,
        mid_valueOf_ffffffff99bd5eb2,
        mid_valueOf_ffffffff9c9fd382,
        mid_valueOf_ffffffffddc7e4ed,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Long(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Long(const Long& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jlong MAX_VALUE;
      static jlong MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Long(jlong);
      Long(const ::java::lang::String &);

      static jint bitCount(jlong);
      jbyte byteValue() const;
      static jint compare(jlong, jlong);
      jint compareTo(const Long &) const;
      static jint compareUnsigned(jlong, jlong);
      static Long decode(const ::java::lang::String &);
      static jlong divideUnsigned(jlong, jlong);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      static Long getLong(const ::java::lang::String &);
      static Long getLong(const ::java::lang::String &, const Long &);
      static Long getLong(const ::java::lang::String &, jlong);
      jint hashCode() const;
      static jint hashCode(jlong);
      static jlong highestOneBit(jlong);
      jint intValue() const;
      jlong longValue() const;
      static jlong lowestOneBit(jlong);
      static jlong max$(jlong, jlong);
      static jlong min$(jlong, jlong);
      static jint numberOfLeadingZeros(jlong);
      static jint numberOfTrailingZeros(jlong);
      static jlong parseLong(const ::java::lang::String &);
      static jlong parseLong(const ::java::lang::String &, jint);
      static jlong parseUnsignedLong(const ::java::lang::String &);
      static jlong parseUnsignedLong(const ::java::lang::String &, jint);
      static jlong remainderUnsigned(jlong, jlong);
      static jlong reverse(jlong);
      static jlong reverseBytes(jlong);
      static jlong rotateLeft(jlong, jint);
      static jlong rotateRight(jlong, jint);
      jshort shortValue() const;
      static jint signum(jlong);
      static jlong sum(jlong, jlong);
      static ::java::lang::String toBinaryString(jlong);
      static ::java::lang::String toHexString(jlong);
      static ::java::lang::String toOctalString(jlong);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jlong);
      static ::java::lang::String toString(jlong, jint);
      static ::java::lang::String toUnsignedString(jlong);
      static ::java::lang::String toUnsignedString(jlong, jint);
      static Long valueOf(jlong);
      static Long valueOf(const ::java::lang::String &);
      static Long valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Long);
    _dll_lucene extern PyTypeObject *PY_TYPE(Long);

    class _dll_lucene t_Long {
    public:
      PyObject_HEAD
      Long object;
      static PyObject *wrap_Object(const Long&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
