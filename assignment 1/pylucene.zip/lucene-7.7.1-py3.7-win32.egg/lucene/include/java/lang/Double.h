#ifndef java_lang_Double_H
#define java_lang_Double_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class Comparable;
    class Double;
    class String;
    class NumberFormatException;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Double : public ::java::lang::Number {
     public:
      enum {
        mid_init$_000000003e46d501,
        mid_init$_0000000048822f5e,
        mid_byteValue_ffffffffb58647b4,
        mid_compare_000000002c6600f0,
        mid_compareTo_ffffffff8f3ccf10,
        mid_doubleToLongBits_ffffffffe3fcac95,
        mid_doubleToRawLongBits_ffffffffe3fcac95,
        mid_doubleValue_0000000046402c15,
        mid_equals_000000007b2e38e9,
        mid_floatValue_ffffffffee5e3be1,
        mid_hashCode_000000002043cb81,
        mid_hashCode_000000002cb0d68d,
        mid_intValue_000000002043cb81,
        mid_isFinite_ffffffffc2cfe9e2,
        mid_isInfinite_0000000000c0c182,
        mid_isInfinite_ffffffffc2cfe9e2,
        mid_isNaN_0000000000c0c182,
        mid_isNaN_ffffffffc2cfe9e2,
        mid_longBitsToDouble_0000000038d3c69f,
        mid_longValue_ffffffffb4c92ea6,
        mid_max_ffffffffd7386b9c,
        mid_min_ffffffffd7386b9c,
        mid_parseDouble_000000007dcb7ad3,
        mid_shortValue_00000000001347c2,
        mid_sum_ffffffffd7386b9c,
        mid_toHexString_ffffffffeb4cfa37,
        mid_toString_000000001d4fc793,
        mid_toString_ffffffffeb4cfa37,
        mid_valueOf_0000000028fb7c22,
        mid_valueOf_ffffffffb2a9fd81,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Double(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Double(const Double& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jint MAX_EXPONENT;
      static jdouble MAX_VALUE;
      static jint MIN_EXPONENT;
      static jdouble MIN_NORMAL;
      static jdouble MIN_VALUE;
      static jdouble NEGATIVE_INFINITY;
      static jdouble NaN;
      static jdouble POSITIVE_INFINITY;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Double(jdouble);
      Double(const ::java::lang::String &);

      jbyte byteValue() const;
      static jint compare(jdouble, jdouble);
      jint compareTo(const Double &) const;
      static jlong doubleToLongBits(jdouble);
      static jlong doubleToRawLongBits(jdouble);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jdouble);
      jint intValue() const;
      static jboolean isFinite(jdouble);
      jboolean isInfinite() const;
      static jboolean isInfinite(jdouble);
      jboolean isNaN() const;
      static jboolean isNaN(jdouble);
      static jdouble longBitsToDouble(jlong);
      jlong longValue() const;
      static jdouble max$(jdouble, jdouble);
      static jdouble min$(jdouble, jdouble);
      static jdouble parseDouble(const ::java::lang::String &);
      jshort shortValue() const;
      static jdouble sum(jdouble, jdouble);
      static ::java::lang::String toHexString(jdouble);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jdouble);
      static Double valueOf(const ::java::lang::String &);
      static Double valueOf(jdouble);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Double);
    _dll_lucene extern PyTypeObject *PY_TYPE(Double);

    class _dll_lucene t_Double {
    public:
      PyObject_HEAD
      Double object;
      static PyObject *wrap_Object(const Double&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
