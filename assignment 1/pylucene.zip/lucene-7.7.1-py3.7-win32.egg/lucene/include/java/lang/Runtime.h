#ifndef java_lang_Runtime_H
#define java_lang_Runtime_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class File;
    class OutputStream;
    class InputStream;
    class IOException;
  }
  namespace lang {
    class Class;
    class Runtime;
    class String;
    class Process;
    class Thread;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Runtime : public ::java::lang::Object {
     public:
      enum {
        mid_addShutdownHook_000000003eb067cc,
        mid_availableProcessors_000000002043cb81,
        mid_exec_ffffffffe2050e69,
        mid_exec_ffffffffe47ef001,
        mid_exec_ffffffffc65da31d,
        mid_exec_fffffffff7aacf2c,
        mid_exec_ffffffffea598b25,
        mid_exec_00000000342df0dc,
        mid_exit_ffffffffa0b31ff5,
        mid_freeMemory_ffffffffb4c92ea6,
        mid_gc_ffffffffde902c42,
        mid_getLocalizedInputStream_ffffffff80f880c6,
        mid_getLocalizedOutputStream_000000002add07d6,
        mid_getRuntime_ffffffffb205b821,
        mid_halt_ffffffffa0b31ff5,
        mid_load_0000000048822f5e,
        mid_loadLibrary_0000000048822f5e,
        mid_maxMemory_ffffffffb4c92ea6,
        mid_removeShutdownHook_ffffffffa969a21e,
        mid_runFinalization_ffffffffde902c42,
        mid_runFinalizersOnExit_ffffffffd7cfea8c,
        mid_totalMemory_ffffffffb4c92ea6,
        mid_traceInstructions_ffffffffd7cfea8c,
        mid_traceMethodCalls_ffffffffd7cfea8c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Runtime(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Runtime(const Runtime& obj) : ::java::lang::Object(obj) {}

      void addShutdownHook(const ::java::lang::Thread &) const;
      jint availableProcessors() const;
      ::java::lang::Process exec(const ::java::lang::String &) const;
      ::java::lang::Process exec(const JArray< ::java::lang::String > &) const;
      ::java::lang::Process exec(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
      ::java::lang::Process exec(const JArray< ::java::lang::String > &, const JArray< ::java::lang::String > &) const;
      ::java::lang::Process exec(const JArray< ::java::lang::String > &, const JArray< ::java::lang::String > &, const ::java::io::File &) const;
      ::java::lang::Process exec(const ::java::lang::String &, const JArray< ::java::lang::String > &, const ::java::io::File &) const;
      void exit(jint) const;
      jlong freeMemory() const;
      void gc() const;
      ::java::io::InputStream getLocalizedInputStream(const ::java::io::InputStream &) const;
      ::java::io::OutputStream getLocalizedOutputStream(const ::java::io::OutputStream &) const;
      static Runtime getRuntime();
      void halt(jint) const;
      void load(const ::java::lang::String &) const;
      void loadLibrary(const ::java::lang::String &) const;
      jlong maxMemory() const;
      jboolean removeShutdownHook(const ::java::lang::Thread &) const;
      void runFinalization() const;
      static void runFinalizersOnExit(jboolean);
      jlong totalMemory() const;
      void traceInstructions(jboolean) const;
      void traceMethodCalls(jboolean) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Runtime);
    _dll_lucene extern PyTypeObject *PY_TYPE(Runtime);

    class _dll_lucene t_Runtime {
    public:
      PyObject_HEAD
      Runtime object;
      static PyObject *wrap_Object(const Runtime&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
