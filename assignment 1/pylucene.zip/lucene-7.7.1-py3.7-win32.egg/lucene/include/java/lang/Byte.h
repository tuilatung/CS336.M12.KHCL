#ifndef java_lang_Byte_H
#define java_lang_Byte_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class Byte;
    class Class;
    class Object;
    class Comparable;
    class String;
    class NumberFormatException;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Byte : public ::java::lang::Number {
     public:
      enum {
        mid_init$_000000005220b8a7,
        mid_init$_0000000048822f5e,
        mid_byteValue_ffffffffb58647b4,
        mid_compare_000000004b57e623,
        mid_compareTo_000000000cb5e7aa,
        mid_decode_ffffffffbabc4efd,
        mid_doubleValue_0000000046402c15,
        mid_equals_000000007b2e38e9,
        mid_floatValue_ffffffffee5e3be1,
        mid_hashCode_000000002043cb81,
        mid_hashCode_ffffffffab304cca,
        mid_intValue_000000002043cb81,
        mid_longValue_ffffffffb4c92ea6,
        mid_parseByte_0000000003fad650,
        mid_parseByte_000000006010f291,
        mid_shortValue_00000000001347c2,
        mid_toString_000000001d4fc793,
        mid_toString_ffffffffe71207f6,
        mid_toUnsignedInt_ffffffffab304cca,
        mid_toUnsignedLong_ffffffffec843cea,
        mid_valueOf_ffffffffbabc4efd,
        mid_valueOf_000000001a30b023,
        mid_valueOf_0000000019f7e2f1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Byte(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Byte(const Byte& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jbyte MAX_VALUE;
      static jbyte MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Byte(jbyte);
      Byte(const ::java::lang::String &);

      jbyte byteValue() const;
      static jint compare(jbyte, jbyte);
      jint compareTo(const Byte &) const;
      static Byte decode(const ::java::lang::String &);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jbyte);
      jint intValue() const;
      jlong longValue() const;
      static jbyte parseByte(const ::java::lang::String &);
      static jbyte parseByte(const ::java::lang::String &, jint);
      jshort shortValue() const;
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jbyte);
      static jint toUnsignedInt(jbyte);
      static jlong toUnsignedLong(jbyte);
      static Byte valueOf(const ::java::lang::String &);
      static Byte valueOf(jbyte);
      static Byte valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Byte);
    _dll_lucene extern PyTypeObject *PY_TYPE(Byte);

    class _dll_lucene t_Byte {
    public:
      PyObject_HEAD
      Byte object;
      static PyObject *wrap_Object(const Byte&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
