#ifndef java_lang_StringBuilder_H
#define java_lang_StringBuilder_H

#include "java/lang/AbstractStringBuilder.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class Object;
    class CharSequence;
    class StringBuilder;
    class String;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene StringBuilder : public ::java::lang::AbstractStringBuilder {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffb7151c43,
        mid_init$_0000000048822f5e,
        mid_init$_ffffffffa0b31ff5,
        mid_append_0000000039992e95,
        mid_append_000000003383e356,
        mid_append_000000005ff7b6b1,
        mid_append_000000002c18c9fe,
        mid_append_ffffffffd8caaffb,
        mid_append_ffffffffafc0d881,
        mid_append_000000000ebd8a8f,
        mid_append_ffffffffa0584f66,
        mid_append_ffffffffbd5867e5,
        mid_append_ffffffff8b05857a,
        mid_append_0000000057edf692,
        mid_append_000000005192c0e3,
        mid_append_ffffffffb3c12f64,
        mid_appendCodePoint_000000000ebd8a8f,
        mid_delete_ffffffffd8f3f0d8,
        mid_deleteCharAt_000000000ebd8a8f,
        mid_indexOf_0000000026f4dfbe,
        mid_indexOf_ffffffffb3f873c8,
        mid_insert_ffffffffd210e90e,
        mid_insert_000000007c49acb2,
        mid_insert_000000005ce8777d,
        mid_insert_ffffffffd8f3f0d8,
        mid_insert_0000000059bb2bd5,
        mid_insert_000000004308fd79,
        mid_insert_0000000026a59cd3,
        mid_insert_00000000171afacb,
        mid_insert_000000002725b0fe,
        mid_insert_000000004f1e9f93,
        mid_insert_000000002534fc25,
        mid_insert_ffffffff9703df76,
        mid_lastIndexOf_0000000026f4dfbe,
        mid_lastIndexOf_ffffffffb3f873c8,
        mid_replace_00000000103937bf,
        mid_reverse_0000000034b25dc7,
        mid_toString_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit StringBuilder(jobject obj) : ::java::lang::AbstractStringBuilder(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      StringBuilder(const StringBuilder& obj) : ::java::lang::AbstractStringBuilder(obj) {}

      StringBuilder();
      StringBuilder(const ::java::lang::CharSequence &);
      StringBuilder(const ::java::lang::String &);
      StringBuilder(jint);

      StringBuilder append(jfloat) const;
      StringBuilder append(jlong) const;
      StringBuilder append(const JArray< jchar > &) const;
      StringBuilder append(jdouble) const;
      StringBuilder append(const ::java::lang::StringBuffer &) const;
      StringBuilder append(const ::java::lang::CharSequence &) const;
      StringBuilder append(jint) const;
      StringBuilder append(jchar) const;
      StringBuilder append(const ::java::lang::Object &) const;
      StringBuilder append(jboolean) const;
      StringBuilder append(const ::java::lang::String &) const;
      StringBuilder append(const ::java::lang::CharSequence &, jint, jint) const;
      StringBuilder append(const JArray< jchar > &, jint, jint) const;
      StringBuilder appendCodePoint(jint) const;
      StringBuilder delete$(jint, jint) const;
      StringBuilder deleteCharAt(jint) const;
      jint indexOf(const ::java::lang::String &) const;
      jint indexOf(const ::java::lang::String &, jint) const;
      StringBuilder insert(jint, jdouble) const;
      StringBuilder insert(jint, jfloat) const;
      StringBuilder insert(jint, jlong) const;
      StringBuilder insert(jint, jint) const;
      StringBuilder insert(jint, const ::java::lang::Object &) const;
      StringBuilder insert(jint, const ::java::lang::String &) const;
      StringBuilder insert(jint, const JArray< jchar > &) const;
      StringBuilder insert(jint, const ::java::lang::CharSequence &) const;
      StringBuilder insert(jint, jboolean) const;
      StringBuilder insert(jint, jchar) const;
      StringBuilder insert(jint, const JArray< jchar > &, jint, jint) const;
      StringBuilder insert(jint, const ::java::lang::CharSequence &, jint, jint) const;
      jint lastIndexOf(const ::java::lang::String &) const;
      jint lastIndexOf(const ::java::lang::String &, jint) const;
      StringBuilder replace(jint, jint, const ::java::lang::String &) const;
      StringBuilder reverse() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(StringBuilder);
    _dll_lucene extern PyTypeObject *PY_TYPE(StringBuilder);

    class _dll_lucene t_StringBuilder {
    public:
      PyObject_HEAD
      StringBuilder object;
      static PyObject *wrap_Object(const StringBuilder&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
