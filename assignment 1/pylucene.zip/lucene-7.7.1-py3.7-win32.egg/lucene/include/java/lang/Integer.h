#ifndef java_lang_Integer_H
#define java_lang_Integer_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class Comparable;
    class Integer;
    class String;
    class NumberFormatException;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Integer : public ::java::lang::Number {
     public:
      enum {
        mid_init$_ffffffffa0b31ff5,
        mid_init$_0000000048822f5e,
        mid_bitCount_000000007930bd1c,
        mid_byteValue_ffffffffb58647b4,
        mid_compare_ffffffffbefe0b2f,
        mid_compareTo_ffffffffbbc9a5fd,
        mid_compareUnsigned_ffffffffbefe0b2f,
        mid_decode_00000000014375c4,
        mid_divideUnsigned_ffffffffbefe0b2f,
        mid_doubleValue_0000000046402c15,
        mid_equals_000000007b2e38e9,
        mid_floatValue_ffffffffee5e3be1,
        mid_getInteger_00000000014375c4,
        mid_getInteger_000000004c5b9e2d,
        mid_getInteger_0000000048e10151,
        mid_hashCode_000000002043cb81,
        mid_hashCode_000000007930bd1c,
        mid_highestOneBit_000000007930bd1c,
        mid_intValue_000000002043cb81,
        mid_longValue_ffffffffb4c92ea6,
        mid_lowestOneBit_000000007930bd1c,
        mid_max_ffffffffbefe0b2f,
        mid_min_ffffffffbefe0b2f,
        mid_numberOfLeadingZeros_000000007930bd1c,
        mid_numberOfTrailingZeros_000000007930bd1c,
        mid_parseInt_0000000026f4dfbe,
        mid_parseInt_ffffffffb3f873c8,
        mid_parseUnsignedInt_0000000026f4dfbe,
        mid_parseUnsignedInt_ffffffffb3f873c8,
        mid_remainderUnsigned_ffffffffbefe0b2f,
        mid_reverse_000000007930bd1c,
        mid_reverseBytes_000000007930bd1c,
        mid_rotateLeft_ffffffffbefe0b2f,
        mid_rotateRight_ffffffffbefe0b2f,
        mid_shortValue_00000000001347c2,
        mid_signum_000000007930bd1c,
        mid_sum_ffffffffbefe0b2f,
        mid_toBinaryString_0000000026c48400,
        mid_toHexString_0000000026c48400,
        mid_toOctalString_0000000026c48400,
        mid_toString_000000001d4fc793,
        mid_toString_0000000026c48400,
        mid_toString_000000001f671572,
        mid_toUnsignedLong_ffffffff8f6816e0,
        mid_toUnsignedString_0000000026c48400,
        mid_toUnsignedString_000000001f671572,
        mid_valueOf_fffffffff0849136,
        mid_valueOf_00000000014375c4,
        mid_valueOf_0000000048e10151,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Integer(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Integer(const Integer& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jint MAX_VALUE;
      static jint MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Integer(jint);
      Integer(const ::java::lang::String &);

      static jint bitCount(jint);
      jbyte byteValue() const;
      static jint compare(jint, jint);
      jint compareTo(const Integer &) const;
      static jint compareUnsigned(jint, jint);
      static Integer decode(const ::java::lang::String &);
      static jint divideUnsigned(jint, jint);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      static Integer getInteger(const ::java::lang::String &);
      static Integer getInteger(const ::java::lang::String &, const Integer &);
      static Integer getInteger(const ::java::lang::String &, jint);
      jint hashCode() const;
      static jint hashCode(jint);
      static jint highestOneBit(jint);
      jint intValue() const;
      jlong longValue() const;
      static jint lowestOneBit(jint);
      static jint max$(jint, jint);
      static jint min$(jint, jint);
      static jint numberOfLeadingZeros(jint);
      static jint numberOfTrailingZeros(jint);
      static jint parseInt(const ::java::lang::String &);
      static jint parseInt(const ::java::lang::String &, jint);
      static jint parseUnsignedInt(const ::java::lang::String &);
      static jint parseUnsignedInt(const ::java::lang::String &, jint);
      static jint remainderUnsigned(jint, jint);
      static jint reverse(jint);
      static jint reverseBytes(jint);
      static jint rotateLeft(jint, jint);
      static jint rotateRight(jint, jint);
      jshort shortValue() const;
      static jint signum(jint);
      static jint sum(jint, jint);
      static ::java::lang::String toBinaryString(jint);
      static ::java::lang::String toHexString(jint);
      static ::java::lang::String toOctalString(jint);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jint);
      static ::java::lang::String toString(jint, jint);
      static jlong toUnsignedLong(jint);
      static ::java::lang::String toUnsignedString(jint);
      static ::java::lang::String toUnsignedString(jint, jint);
      static Integer valueOf(jint);
      static Integer valueOf(const ::java::lang::String &);
      static Integer valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Integer);
    _dll_lucene extern PyTypeObject *PY_TYPE(Integer);

    class _dll_lucene t_Integer {
    public:
      PyObject_HEAD
      Integer object;
      static PyObject *wrap_Object(const Integer&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
