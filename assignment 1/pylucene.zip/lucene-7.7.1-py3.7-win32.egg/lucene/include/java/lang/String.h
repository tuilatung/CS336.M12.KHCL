#ifndef java_lang_String_H
#define java_lang_String_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class Comparable;
    class Iterable;
    class CharSequence;
    class StringBuilder;
    class String;
  }
  namespace util {
    class Locale;
    class Comparator;
  }
  namespace io {
    class UnsupportedEncodingException;
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene String : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_fffffffff054ed10,
        mid_init$_0000000052fe6a8d,
        mid_init$_0000000038c78f53,
        mid_init$_ffffffffa23b19d5,
        mid_init$_ffffffffb0f793a7,
        mid_init$_ffffffff98ab79e7,
        mid_init$_00000000311f6778,
        mid_init$_0000000046ada8e7,
        mid_init$_0000000052290416,
        mid_init$_ffffffffd7a474fe,
        mid_init$_000000003eac371d,
        mid_charAt_000000007fc4e57c,
        mid_codePointAt_000000007930bd1c,
        mid_codePointBefore_000000007930bd1c,
        mid_codePointCount_ffffffffbefe0b2f,
        mid_compareTo_0000000026f4dfbe,
        mid_compareToIgnoreCase_0000000026f4dfbe,
        mid_concat_ffffffffbf6eae52,
        mid_contains_fffffffffec8a33a,
        mid_contentEquals_fffffffffec8a33a,
        mid_contentEquals_0000000006543213,
        mid_copyValueOf_0000000015a5f85f,
        mid_copyValueOf_ffffffffbc557773,
        mid_endsWith_ffffffffc94366ea,
        mid_equals_000000007b2e38e9,
        mid_equalsIgnoreCase_ffffffffc94366ea,
        mid_format_000000005295caa2,
        mid_format_ffffffffce566de3,
        mid_getBytes_000000007043ab9b,
        mid_getBytes_fffffffffa870425,
        mid_getBytes_fffffffffb8897d7,
        mid_getChars_ffffffffbc4221b9,
        mid_hashCode_000000002043cb81,
        mid_indexOf_0000000026f4dfbe,
        mid_indexOf_000000007930bd1c,
        mid_indexOf_ffffffffb3f873c8,
        mid_indexOf_ffffffffbefe0b2f,
        mid_intern_000000001d4fc793,
        mid_isEmpty_0000000000c0c182,
        mid_join_ffffffffdef137c9,
        mid_join_ffffffff89e698b6,
        mid_lastIndexOf_000000007930bd1c,
        mid_lastIndexOf_0000000026f4dfbe,
        mid_lastIndexOf_ffffffffb3f873c8,
        mid_lastIndexOf_ffffffffbefe0b2f,
        mid_length_000000002043cb81,
        mid_matches_ffffffffc94366ea,
        mid_offsetByCodePoints_ffffffffbefe0b2f,
        mid_regionMatches_000000004a718f0d,
        mid_regionMatches_00000000255f175d,
        mid_replace_ffffffff9c70ad10,
        mid_replace_ffffffffed97907a,
        mid_replaceAll_ffffffffe73080ee,
        mid_replaceFirst_ffffffffe73080ee,
        mid_split_000000007ee02930,
        mid_split_0000000000936772,
        mid_startsWith_ffffffffc94366ea,
        mid_startsWith_0000000025b9d0b7,
        mid_subSequence_ffffffffe01cf115,
        mid_substring_0000000026c48400,
        mid_substring_000000001f671572,
        mid_toCharArray_00000000698c608a,
        mid_toLowerCase_000000001d4fc793,
        mid_toLowerCase_000000003408a0c5,
        mid_toString_000000001d4fc793,
        mid_toUpperCase_000000001d4fc793,
        mid_toUpperCase_000000003408a0c5,
        mid_trim_000000001d4fc793,
        mid_valueOf_0000000026c48400,
        mid_valueOf_ffffffffcf2540a8,
        mid_valueOf_ffffffffc25c34b0,
        mid_valueOf_000000002e6aae49,
        mid_valueOf_0000000015a5f85f,
        mid_valueOf_0000000068d7ebb0,
        mid_valueOf_000000005a3d97d7,
        mid_valueOf_ffffffffeb4cfa37,
        mid_valueOf_ffffffffbc557773,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit String(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      String(const String& obj) : ::java::lang::Object(obj) {}

      static ::java::util::Comparator *CASE_INSENSITIVE_ORDER;

      String();
      String(const ::java::lang::StringBuilder &);
      String(const ::java::lang::StringBuffer &);
      String(const JArray< jbyte > &);
      String(const JArray< jchar > &);
      String(const JArray< jbyte > &, const String &);
      String(const JArray< jbyte > &, jint);
      String(const JArray< jbyte > &, jint, jint);
      String(const JArray< jint > &, jint, jint);
      String(const JArray< jchar > &, jint, jint);
      String(const JArray< jbyte > &, jint, jint, const String &);
      String(const JArray< jbyte > &, jint, jint, jint);

      jchar charAt(jint) const;
      jint codePointAt(jint) const;
      jint codePointBefore(jint) const;
      jint codePointCount(jint, jint) const;
      jint compareTo(const String &) const;
      jint compareToIgnoreCase(const String &) const;
      String concat(const String &) const;
      jboolean contains(const ::java::lang::CharSequence &) const;
      jboolean contentEquals(const ::java::lang::CharSequence &) const;
      jboolean contentEquals(const ::java::lang::StringBuffer &) const;
      static String copyValueOf(const JArray< jchar > &);
      static String copyValueOf(const JArray< jchar > &, jint, jint);
      jboolean endsWith(const String &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jboolean equalsIgnoreCase(const String &) const;
      static String format(const String &, const JArray< ::java::lang::Object > &);
      static String format(const ::java::util::Locale &, const String &, const JArray< ::java::lang::Object > &);
      JArray< jbyte > getBytes() const;
      JArray< jbyte > getBytes(const String &) const;
      void getBytes(jint, jint, const JArray< jbyte > &, jint) const;
      void getChars(jint, jint, const JArray< jchar > &, jint) const;
      jint hashCode() const;
      jint indexOf(const String &) const;
      jint indexOf(jint) const;
      jint indexOf(const String &, jint) const;
      jint indexOf(jint, jint) const;
      String intern() const;
      jboolean isEmpty() const;
      static String join(const ::java::lang::CharSequence &, const JArray< ::java::lang::CharSequence > &);
      static String join(const ::java::lang::CharSequence &, const ::java::lang::Iterable &);
      jint lastIndexOf(jint) const;
      jint lastIndexOf(const String &) const;
      jint lastIndexOf(const String &, jint) const;
      jint lastIndexOf(jint, jint) const;
      jint length() const;
      jboolean matches(const String &) const;
      jint offsetByCodePoints(jint, jint) const;
      jboolean regionMatches(jint, const String &, jint, jint) const;
      jboolean regionMatches(jboolean, jint, const String &, jint, jint) const;
      String replace(jchar, jchar) const;
      String replace(const ::java::lang::CharSequence &, const ::java::lang::CharSequence &) const;
      String replaceAll(const String &, const String &) const;
      String replaceFirst(const String &, const String &) const;
      JArray< String > split(const String &) const;
      JArray< String > split(const String &, jint) const;
      jboolean startsWith(const String &) const;
      jboolean startsWith(const String &, jint) const;
      ::java::lang::CharSequence subSequence(jint, jint) const;
      String substring(jint) const;
      String substring(jint, jint) const;
      JArray< jchar > toCharArray() const;
      String toLowerCase() const;
      String toLowerCase(const ::java::util::Locale &) const;
      String toString() const;
      String toUpperCase() const;
      String toUpperCase(const ::java::util::Locale &) const;
      String trim() const;
      static String valueOf(jint);
      static String valueOf(jlong);
      static String valueOf(jfloat);
      static String valueOf(jboolean);
      static String valueOf(const JArray< jchar > &);
      static String valueOf(const ::java::lang::Object &);
      static String valueOf(jchar);
      static String valueOf(jdouble);
      static String valueOf(const JArray< jchar > &, jint, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(String);
    _dll_lucene extern PyTypeObject *PY_TYPE(String);

    class _dll_lucene t_String {
    public:
      PyObject_HEAD
      String object;
      static PyObject *wrap_Object(const String&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
