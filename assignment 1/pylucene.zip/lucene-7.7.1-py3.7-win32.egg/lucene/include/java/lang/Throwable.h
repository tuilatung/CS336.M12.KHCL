#ifndef java_lang_Throwable_H
#define java_lang_Throwable_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class PrintWriter;
    class Serializable;
    class PrintStream;
  }
  namespace lang {
    class Class;
    class StackTraceElement;
    class String;
    class Throwable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Throwable : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_0000000048822f5e,
        mid_init$_000000002f4ccf89,
        mid_addSuppressed_0000000011312d29,
        mid_fillInStackTrace_00000000215c3af9,
        mid_getCause_00000000215c3af9,
        mid_getLocalizedMessage_000000001d4fc793,
        mid_getMessage_000000001d4fc793,
        mid_getStackTrace_ffffffffafa093a2,
        mid_getSuppressed_ffffffffc9049405,
        mid_initCause_0000000075224f3f,
        mid_printStackTrace_ffffffffde902c42,
        mid_printStackTrace_000000005702bab7,
        mid_printStackTrace_0000000065dd8cbc,
        mid_setStackTrace_fffffffff385cbd4,
        mid_toString_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Throwable(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Throwable(const Throwable& obj) : ::java::lang::Object(obj) {}

      Throwable();
      Throwable(const ::java::lang::String &);
      Throwable(const ::java::lang::String &, const Throwable &);

      void addSuppressed(const Throwable &) const;
      Throwable fillInStackTrace() const;
      Throwable getCause() const;
      ::java::lang::String getLocalizedMessage() const;
      ::java::lang::String getMessage() const;
      JArray< ::java::lang::StackTraceElement > getStackTrace() const;
      JArray< Throwable > getSuppressed() const;
      Throwable initCause(const Throwable &) const;
      void printStackTrace() const;
      void printStackTrace(const ::java::io::PrintWriter &) const;
      void printStackTrace(const ::java::io::PrintStream &) const;
      void setStackTrace(const JArray< ::java::lang::StackTraceElement > &) const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Throwable);
    _dll_lucene extern PyTypeObject *PY_TYPE(Throwable);

    class _dll_lucene t_Throwable {
    public:
      PyObject_HEAD
      Throwable object;
      static PyObject *wrap_Object(const Throwable&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
