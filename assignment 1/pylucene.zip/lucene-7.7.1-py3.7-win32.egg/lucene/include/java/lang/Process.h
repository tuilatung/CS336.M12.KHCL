#ifndef java_lang_Process_H
#define java_lang_Process_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class InterruptedException;
    class Class;
    class Process;
  }
  namespace io {
    class OutputStream;
    class InputStream;
  }
  namespace util {
    namespace concurrent {
      class TimeUnit;
    }
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene Process : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_destroy_ffffffffde902c42,
        mid_destroyForcibly_fffffffff21ca866,
        mid_exitValue_000000002043cb81,
        mid_getErrorStream_ffffffffb6aab0b0,
        mid_getInputStream_ffffffffb6aab0b0,
        mid_getOutputStream_000000001d0d7945,
        mid_isAlive_0000000000c0c182,
        mid_waitFor_000000002043cb81,
        mid_waitFor_000000000ed34bf7,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Process(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Process(const Process& obj) : ::java::lang::Object(obj) {}

      Process();

      void destroy() const;
      Process destroyForcibly() const;
      jint exitValue() const;
      ::java::io::InputStream getErrorStream() const;
      ::java::io::InputStream getInputStream() const;
      ::java::io::OutputStream getOutputStream() const;
      jboolean isAlive() const;
      jint waitFor() const;
      jboolean waitFor(jlong, const ::java::util::concurrent::TimeUnit &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Process);
    _dll_lucene extern PyTypeObject *PY_TYPE(Process);

    class _dll_lucene t_Process {
    public:
      PyObject_HEAD
      Process object;
      static PyObject *wrap_Object(const Process&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
