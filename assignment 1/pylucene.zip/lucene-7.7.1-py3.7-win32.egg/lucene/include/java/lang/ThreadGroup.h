#ifndef java_lang_ThreadGroup_H
#define java_lang_ThreadGroup_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Thread$UncaughtExceptionHandler;
    class Class;
    class ThreadGroup;
    class String;
    class Thread;
    class Throwable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene ThreadGroup : public ::java::lang::Object {
     public:
      enum {
        mid_init$_0000000048822f5e,
        mid_init$_ffffffffb3c4a58b,
        mid_activeCount_000000002043cb81,
        mid_activeGroupCount_000000002043cb81,
        mid_allowThreadSuspension_0000000038de4f94,
        mid_checkAccess_ffffffffde902c42,
        mid_destroy_ffffffffde902c42,
        mid_enumerate_ffffffff88258c0e,
        mid_enumerate_00000000208b6c5b,
        mid_enumerate_ffffffff9e9f4ad1,
        mid_enumerate_000000006dc1bee2,
        mid_getMaxPriority_000000002043cb81,
        mid_getName_000000001d4fc793,
        mid_getParent_0000000050db18ea,
        mid_interrupt_ffffffffde902c42,
        mid_isDaemon_0000000000c0c182,
        mid_isDestroyed_0000000000c0c182,
        mid_list_ffffffffde902c42,
        mid_parentOf_000000004906115c,
        mid_resume_ffffffffde902c42,
        mid_setDaemon_ffffffffd7cfea8c,
        mid_setMaxPriority_ffffffffa0b31ff5,
        mid_stop_ffffffffde902c42,
        mid_suspend_ffffffffde902c42,
        mid_toString_000000001d4fc793,
        mid_uncaughtException_00000000494690d7,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ThreadGroup(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ThreadGroup(const ThreadGroup& obj) : ::java::lang::Object(obj) {}

      ThreadGroup(const ::java::lang::String &);
      ThreadGroup(const ThreadGroup &, const ::java::lang::String &);

      jint activeCount() const;
      jint activeGroupCount() const;
      jboolean allowThreadSuspension(jboolean) const;
      void checkAccess() const;
      void destroy() const;
      jint enumerate(const JArray< ThreadGroup > &) const;
      jint enumerate(const JArray< ::java::lang::Thread > &) const;
      jint enumerate(const JArray< ThreadGroup > &, jboolean) const;
      jint enumerate(const JArray< ::java::lang::Thread > &, jboolean) const;
      jint getMaxPriority() const;
      ::java::lang::String getName() const;
      ThreadGroup getParent() const;
      void interrupt() const;
      jboolean isDaemon() const;
      jboolean isDestroyed() const;
      void list() const;
      jboolean parentOf(const ThreadGroup &) const;
      void resume() const;
      void setDaemon(jboolean) const;
      void setMaxPriority(jint) const;
      void stop() const;
      void suspend() const;
      ::java::lang::String toString() const;
      void uncaughtException(const ::java::lang::Thread &, const ::java::lang::Throwable &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(ThreadGroup);
    _dll_lucene extern PyTypeObject *PY_TYPE(ThreadGroup);

    class _dll_lucene t_ThreadGroup {
    public:
      PyObject_HEAD
      ThreadGroup object;
      static PyObject *wrap_Object(const ThreadGroup&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
