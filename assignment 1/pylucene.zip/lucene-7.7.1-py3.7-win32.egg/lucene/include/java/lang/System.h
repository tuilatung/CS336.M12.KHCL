#ifndef java_lang_System_H
#define java_lang_System_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class SecurityManager;
  }
  namespace util {
    class Properties;
    class Map;
  }
  namespace io {
    class Console;
    class InputStream;
    class PrintStream;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class _dll_lucene System : public ::java::lang::Object {
     public:
      enum {
        mid_arraycopy_000000003906473f,
        mid_clearProperty_ffffffffbf6eae52,
        mid_console_ffffffffe7e9c8b5,
        mid_currentTimeMillis_ffffffffb4c92ea6,
        mid_exit_ffffffffa0b31ff5,
        mid_gc_ffffffffde902c42,
        mid_getProperties_fffffffffce0f3ee,
        mid_getProperty_ffffffffbf6eae52,
        mid_getProperty_ffffffffe73080ee,
        mid_getSecurityManager_ffffffffa2e15b71,
        mid_getenv_000000007d6a46b0,
        mid_getenv_ffffffffbf6eae52,
        mid_identityHashCode_fffffffffdd5cef1,
        mid_lineSeparator_000000001d4fc793,
        mid_load_0000000048822f5e,
        mid_loadLibrary_0000000048822f5e,
        mid_mapLibraryName_ffffffffbf6eae52,
        mid_nanoTime_ffffffffb4c92ea6,
        mid_runFinalization_ffffffffde902c42,
        mid_runFinalizersOnExit_ffffffffd7cfea8c,
        mid_setErr_0000000065dd8cbc,
        mid_setIn_ffffffffbb1e543a,
        mid_setOut_0000000065dd8cbc,
        mid_setProperties_000000001082eaed,
        mid_setProperty_ffffffffe73080ee,
        mid_setSecurityManager_ffffffff8c1dca0a,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit System(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      System(const System& obj) : ::java::lang::Object(obj) {}

      static ::java::io::PrintStream *err;
      static ::java::io::InputStream *in;
      static ::java::io::PrintStream *out;

      static void arraycopy(const ::java::lang::Object &, jint, const ::java::lang::Object &, jint, jint);
      static ::java::lang::String clearProperty(const ::java::lang::String &);
      static ::java::io::Console console();
      static jlong currentTimeMillis();
      static void exit(jint);
      static void gc();
      static ::java::util::Properties getProperties();
      static ::java::lang::String getProperty(const ::java::lang::String &);
      static ::java::lang::String getProperty(const ::java::lang::String &, const ::java::lang::String &);
      static ::java::lang::SecurityManager getSecurityManager();
      static ::java::util::Map getenv();
      static ::java::lang::String getenv(const ::java::lang::String &);
      static jint identityHashCode(const ::java::lang::Object &);
      static ::java::lang::String lineSeparator();
      static void load(const ::java::lang::String &);
      static void loadLibrary(const ::java::lang::String &);
      static ::java::lang::String mapLibraryName(const ::java::lang::String &);
      static jlong nanoTime();
      static void runFinalization();
      static void runFinalizersOnExit(jboolean);
      static void setErr(const ::java::io::PrintStream &);
      static void setIn(const ::java::io::InputStream &);
      static void setOut(const ::java::io::PrintStream &);
      static void setProperties(const ::java::util::Properties &);
      static ::java::lang::String setProperty(const ::java::lang::String &, const ::java::lang::String &);
      static void setSecurityManager(const ::java::lang::SecurityManager &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(System);
    _dll_lucene extern PyTypeObject *PY_TYPE(System);

    class _dll_lucene t_System {
    public:
      PyObject_HEAD
      System object;
      static PyObject *wrap_Object(const System&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
