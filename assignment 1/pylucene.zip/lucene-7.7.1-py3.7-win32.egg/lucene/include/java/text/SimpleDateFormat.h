#ifndef java_text_SimpleDateFormat_H
#define java_text_SimpleDateFormat_H

#include "java/text/DateFormat.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class Object;
    class String;
  }
  namespace util {
    class Date;
    class Locale;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class _dll_lucene SimpleDateFormat : public ::java::text::DateFormat {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_0000000048822f5e,
        mid_init$_0000000025b07e5c,
        mid_applyLocalizedPattern_0000000048822f5e,
        mid_applyPattern_0000000048822f5e,
        mid_clone_ffffffffdcc2e1cc,
        mid_equals_000000007b2e38e9,
        mid_get2DigitYearStart_000000007d22f21a,
        mid_hashCode_000000002043cb81,
        mid_set2DigitYearStart_ffffffff97836a5b,
        mid_toLocalizedPattern_000000001d4fc793,
        mid_toPattern_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SimpleDateFormat(jobject obj) : ::java::text::DateFormat(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SimpleDateFormat(const SimpleDateFormat& obj) : ::java::text::DateFormat(obj) {}

      SimpleDateFormat();
      SimpleDateFormat(const ::java::lang::String &);
      SimpleDateFormat(const ::java::lang::String &, const ::java::util::Locale &);

      void applyLocalizedPattern(const ::java::lang::String &) const;
      void applyPattern(const ::java::lang::String &) const;
      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::util::Date get2DigitYearStart() const;
      jint hashCode() const;
      void set2DigitYearStart(const ::java::util::Date &) const;
      ::java::lang::String toLocalizedPattern() const;
      ::java::lang::String toPattern() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(SimpleDateFormat);
    _dll_lucene extern PyTypeObject *PY_TYPE(SimpleDateFormat);

    class _dll_lucene t_SimpleDateFormat {
    public:
      PyObject_HEAD
      SimpleDateFormat object;
      static PyObject *wrap_Object(const SimpleDateFormat&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
