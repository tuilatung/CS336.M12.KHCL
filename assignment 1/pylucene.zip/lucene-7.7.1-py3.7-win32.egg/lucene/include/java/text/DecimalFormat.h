#ifndef java_text_DecimalFormat_H
#define java_text_DecimalFormat_H

#include "java/text/NumberFormat.h"

namespace java {
  namespace lang {
    class Number;
    class StringBuffer;
    class Class;
    class Object;
    class String;
  }
  namespace util {
    class Currency;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class _dll_lucene DecimalFormat : public ::java::text::NumberFormat {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_0000000048822f5e,
        mid_applyLocalizedPattern_0000000048822f5e,
        mid_applyPattern_0000000048822f5e,
        mid_clone_ffffffffdcc2e1cc,
        mid_equals_000000007b2e38e9,
        mid_getCurrency_ffffffffbec98e78,
        mid_getGroupingSize_000000002043cb81,
        mid_getMaximumFractionDigits_000000002043cb81,
        mid_getMaximumIntegerDigits_000000002043cb81,
        mid_getMinimumFractionDigits_000000002043cb81,
        mid_getMinimumIntegerDigits_000000002043cb81,
        mid_getMultiplier_000000002043cb81,
        mid_getNegativePrefix_000000001d4fc793,
        mid_getNegativeSuffix_000000001d4fc793,
        mid_getPositivePrefix_000000001d4fc793,
        mid_getPositiveSuffix_000000001d4fc793,
        mid_hashCode_000000002043cb81,
        mid_isDecimalSeparatorAlwaysShown_0000000000c0c182,
        mid_isParseBigDecimal_0000000000c0c182,
        mid_setCurrency_ffffffff98542fbb,
        mid_setDecimalSeparatorAlwaysShown_ffffffffd7cfea8c,
        mid_setGroupingSize_ffffffffa0b31ff5,
        mid_setGroupingUsed_ffffffffd7cfea8c,
        mid_setMaximumFractionDigits_ffffffffa0b31ff5,
        mid_setMaximumIntegerDigits_ffffffffa0b31ff5,
        mid_setMinimumFractionDigits_ffffffffa0b31ff5,
        mid_setMinimumIntegerDigits_ffffffffa0b31ff5,
        mid_setMultiplier_ffffffffa0b31ff5,
        mid_setNegativePrefix_0000000048822f5e,
        mid_setNegativeSuffix_0000000048822f5e,
        mid_setParseBigDecimal_ffffffffd7cfea8c,
        mid_setPositivePrefix_0000000048822f5e,
        mid_setPositiveSuffix_0000000048822f5e,
        mid_toLocalizedPattern_000000001d4fc793,
        mid_toPattern_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit DecimalFormat(jobject obj) : ::java::text::NumberFormat(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      DecimalFormat(const DecimalFormat& obj) : ::java::text::NumberFormat(obj) {}

      DecimalFormat();
      DecimalFormat(const ::java::lang::String &);

      void applyLocalizedPattern(const ::java::lang::String &) const;
      void applyPattern(const ::java::lang::String &) const;
      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::util::Currency getCurrency() const;
      jint getGroupingSize() const;
      jint getMaximumFractionDigits() const;
      jint getMaximumIntegerDigits() const;
      jint getMinimumFractionDigits() const;
      jint getMinimumIntegerDigits() const;
      jint getMultiplier() const;
      ::java::lang::String getNegativePrefix() const;
      ::java::lang::String getNegativeSuffix() const;
      ::java::lang::String getPositivePrefix() const;
      ::java::lang::String getPositiveSuffix() const;
      jint hashCode() const;
      jboolean isDecimalSeparatorAlwaysShown() const;
      jboolean isParseBigDecimal() const;
      void setCurrency(const ::java::util::Currency &) const;
      void setDecimalSeparatorAlwaysShown(jboolean) const;
      void setGroupingSize(jint) const;
      void setGroupingUsed(jboolean) const;
      void setMaximumFractionDigits(jint) const;
      void setMaximumIntegerDigits(jint) const;
      void setMinimumFractionDigits(jint) const;
      void setMinimumIntegerDigits(jint) const;
      void setMultiplier(jint) const;
      void setNegativePrefix(const ::java::lang::String &) const;
      void setNegativeSuffix(const ::java::lang::String &) const;
      void setParseBigDecimal(jboolean) const;
      void setPositivePrefix(const ::java::lang::String &) const;
      void setPositiveSuffix(const ::java::lang::String &) const;
      ::java::lang::String toLocalizedPattern() const;
      ::java::lang::String toPattern() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(DecimalFormat);
    _dll_lucene extern PyTypeObject *PY_TYPE(DecimalFormat);

    class _dll_lucene t_DecimalFormat {
    public:
      PyObject_HEAD
      DecimalFormat object;
      static PyObject *wrap_Object(const DecimalFormat&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
