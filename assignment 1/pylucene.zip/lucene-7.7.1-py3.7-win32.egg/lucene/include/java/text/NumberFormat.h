#ifndef java_text_NumberFormat_H
#define java_text_NumberFormat_H

#include "java/text/Format.h"

namespace java {
  namespace lang {
    class Number;
    class StringBuffer;
    class Class;
    class Object;
    class String;
  }
  namespace util {
    class Locale;
    class Currency;
  }
  namespace text {
    class NumberFormat;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class _dll_lucene NumberFormat : public ::java::text::Format {
     public:
      enum {
        mid_clone_ffffffffdcc2e1cc,
        mid_equals_000000007b2e38e9,
        mid_format_ffffffffeb4cfa37,
        mid_format_ffffffffcf2540a8,
        mid_getAvailableLocales_0000000003b4de94,
        mid_getCurrency_ffffffffbec98e78,
        mid_getCurrencyInstance_000000002dfaca34,
        mid_getCurrencyInstance_ffffffff8d690b9c,
        mid_getInstance_000000002dfaca34,
        mid_getInstance_ffffffff8d690b9c,
        mid_getIntegerInstance_000000002dfaca34,
        mid_getIntegerInstance_ffffffff8d690b9c,
        mid_getMaximumFractionDigits_000000002043cb81,
        mid_getMaximumIntegerDigits_000000002043cb81,
        mid_getMinimumFractionDigits_000000002043cb81,
        mid_getMinimumIntegerDigits_000000002043cb81,
        mid_getNumberInstance_000000002dfaca34,
        mid_getNumberInstance_ffffffff8d690b9c,
        mid_getPercentInstance_000000002dfaca34,
        mid_getPercentInstance_ffffffff8d690b9c,
        mid_hashCode_000000002043cb81,
        mid_isGroupingUsed_0000000000c0c182,
        mid_isParseIntegerOnly_0000000000c0c182,
        mid_parse_000000000b9f1c63,
        mid_setCurrency_ffffffff98542fbb,
        mid_setGroupingUsed_ffffffffd7cfea8c,
        mid_setMaximumFractionDigits_ffffffffa0b31ff5,
        mid_setMaximumIntegerDigits_ffffffffa0b31ff5,
        mid_setMinimumFractionDigits_ffffffffa0b31ff5,
        mid_setMinimumIntegerDigits_ffffffffa0b31ff5,
        mid_setParseIntegerOnly_ffffffffd7cfea8c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit NumberFormat(jobject obj) : ::java::text::Format(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      NumberFormat(const NumberFormat& obj) : ::java::text::Format(obj) {}

      static jint FRACTION_FIELD;
      static jint INTEGER_FIELD;

      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::lang::String format(jdouble) const;
      ::java::lang::String format(jlong) const;
      static JArray< ::java::util::Locale > getAvailableLocales();
      ::java::util::Currency getCurrency() const;
      static NumberFormat getCurrencyInstance();
      static NumberFormat getCurrencyInstance(const ::java::util::Locale &);
      static NumberFormat getInstance();
      static NumberFormat getInstance(const ::java::util::Locale &);
      static NumberFormat getIntegerInstance();
      static NumberFormat getIntegerInstance(const ::java::util::Locale &);
      jint getMaximumFractionDigits() const;
      jint getMaximumIntegerDigits() const;
      jint getMinimumFractionDigits() const;
      jint getMinimumIntegerDigits() const;
      static NumberFormat getNumberInstance();
      static NumberFormat getNumberInstance(const ::java::util::Locale &);
      static NumberFormat getPercentInstance();
      static NumberFormat getPercentInstance(const ::java::util::Locale &);
      jint hashCode() const;
      jboolean isGroupingUsed() const;
      jboolean isParseIntegerOnly() const;
      ::java::lang::Number parse(const ::java::lang::String &) const;
      void setCurrency(const ::java::util::Currency &) const;
      void setGroupingUsed(jboolean) const;
      void setMaximumFractionDigits(jint) const;
      void setMaximumIntegerDigits(jint) const;
      void setMinimumFractionDigits(jint) const;
      void setMinimumIntegerDigits(jint) const;
      void setParseIntegerOnly(jboolean) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(NumberFormat);
    _dll_lucene extern PyTypeObject *PY_TYPE(NumberFormat);

    class _dll_lucene t_NumberFormat {
    public:
      PyObject_HEAD
      NumberFormat object;
      static PyObject *wrap_Object(const NumberFormat&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
