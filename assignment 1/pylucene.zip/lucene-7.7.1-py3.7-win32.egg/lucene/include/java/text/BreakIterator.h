#ifndef java_text_BreakIterator_H
#define java_text_BreakIterator_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class Cloneable;
    class String;
  }
  namespace text {
    class BreakIterator;
  }
  namespace util {
    class Locale;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class _dll_lucene BreakIterator : public ::java::lang::Object {
     public:
      enum {
        mid_clone_ffffffffdcc2e1cc,
        mid_current_000000002043cb81,
        mid_first_000000002043cb81,
        mid_following_000000007930bd1c,
        mid_getAvailableLocales_0000000003b4de94,
        mid_getCharacterInstance_ffffffffe921f128,
        mid_getCharacterInstance_000000006f5d5139,
        mid_getLineInstance_ffffffffe921f128,
        mid_getLineInstance_000000006f5d5139,
        mid_getSentenceInstance_ffffffffe921f128,
        mid_getSentenceInstance_000000006f5d5139,
        mid_getWordInstance_ffffffffe921f128,
        mid_getWordInstance_000000006f5d5139,
        mid_isBoundary_0000000052d4339a,
        mid_last_000000002043cb81,
        mid_next_000000002043cb81,
        mid_next_000000007930bd1c,
        mid_preceding_000000007930bd1c,
        mid_previous_000000002043cb81,
        mid_setText_0000000048822f5e,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit BreakIterator(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      BreakIterator(const BreakIterator& obj) : ::java::lang::Object(obj) {}

      static jint DONE;

      ::java::lang::Object clone() const;
      jint current() const;
      jint first() const;
      jint following(jint) const;
      static JArray< ::java::util::Locale > getAvailableLocales();
      static BreakIterator getCharacterInstance();
      static BreakIterator getCharacterInstance(const ::java::util::Locale &);
      static BreakIterator getLineInstance();
      static BreakIterator getLineInstance(const ::java::util::Locale &);
      static BreakIterator getSentenceInstance();
      static BreakIterator getSentenceInstance(const ::java::util::Locale &);
      static BreakIterator getWordInstance();
      static BreakIterator getWordInstance(const ::java::util::Locale &);
      jboolean isBoundary(jint) const;
      jint last() const;
      jint next() const;
      jint next(jint) const;
      jint preceding(jint) const;
      jint previous() const;
      void setText(const ::java::lang::String &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(BreakIterator);
    _dll_lucene extern PyTypeObject *PY_TYPE(BreakIterator);

    class _dll_lucene t_BreakIterator {
    public:
      PyObject_HEAD
      BreakIterator object;
      static PyObject *wrap_Object(const BreakIterator&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
