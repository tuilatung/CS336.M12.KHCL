#ifndef java_text_DateFormat_H
#define java_text_DateFormat_H

#include "java/text/Format.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class Object;
    class String;
  }
  namespace util {
    class Date;
    class Locale;
    class Calendar;
    class TimeZone;
  }
  namespace text {
    class DateFormat;
    class NumberFormat;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class _dll_lucene DateFormat : public ::java::text::Format {
     public:
      enum {
        mid_clone_ffffffffdcc2e1cc,
        mid_equals_000000007b2e38e9,
        mid_format_ffffffffd45a32fc,
        mid_getAvailableLocales_0000000003b4de94,
        mid_getCalendar_ffffffff9d06bdb3,
        mid_getDateInstance_000000004f8360b3,
        mid_getDateInstance_fffffffff381e1fc,
        mid_getDateInstance_ffffffff835ccf66,
        mid_getDateTimeInstance_000000004f8360b3,
        mid_getDateTimeInstance_0000000019ef5100,
        mid_getDateTimeInstance_0000000061c0f47f,
        mid_getInstance_000000004f8360b3,
        mid_getNumberFormat_000000002dfaca34,
        mid_getTimeInstance_000000004f8360b3,
        mid_getTimeInstance_fffffffff381e1fc,
        mid_getTimeInstance_ffffffff835ccf66,
        mid_getTimeZone_ffffffffe7c9416c,
        mid_hashCode_000000002043cb81,
        mid_isLenient_0000000000c0c182,
        mid_parse_000000005c82191f,
        mid_setCalendar_0000000076825d1a,
        mid_setLenient_ffffffffd7cfea8c,
        mid_setNumberFormat_ffffffffca9af0ff,
        mid_setTimeZone_ffffffffb7edc0e7,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit DateFormat(jobject obj) : ::java::text::Format(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      DateFormat(const DateFormat& obj) : ::java::text::Format(obj) {}

      static jint AM_PM_FIELD;
      static jint DATE_FIELD;
      static jint DAY_OF_WEEK_FIELD;
      static jint DAY_OF_WEEK_IN_MONTH_FIELD;
      static jint DAY_OF_YEAR_FIELD;
      static jint DEFAULT;
      static jint ERA_FIELD;
      static jint FULL;
      static jint HOUR0_FIELD;
      static jint HOUR1_FIELD;
      static jint HOUR_OF_DAY0_FIELD;
      static jint HOUR_OF_DAY1_FIELD;
      static jint LONG;
      static jint MEDIUM;
      static jint MILLISECOND_FIELD;
      static jint MINUTE_FIELD;
      static jint MONTH_FIELD;
      static jint SECOND_FIELD;
      static jint SHORT;
      static jint TIMEZONE_FIELD;
      static jint WEEK_OF_MONTH_FIELD;
      static jint WEEK_OF_YEAR_FIELD;
      static jint YEAR_FIELD;

      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::lang::String format(const ::java::util::Date &) const;
      static JArray< ::java::util::Locale > getAvailableLocales();
      ::java::util::Calendar getCalendar() const;
      static DateFormat getDateInstance();
      static DateFormat getDateInstance(jint);
      static DateFormat getDateInstance(jint, const ::java::util::Locale &);
      static DateFormat getDateTimeInstance();
      static DateFormat getDateTimeInstance(jint, jint);
      static DateFormat getDateTimeInstance(jint, jint, const ::java::util::Locale &);
      static DateFormat getInstance();
      ::java::text::NumberFormat getNumberFormat() const;
      static DateFormat getTimeInstance();
      static DateFormat getTimeInstance(jint);
      static DateFormat getTimeInstance(jint, const ::java::util::Locale &);
      ::java::util::TimeZone getTimeZone() const;
      jint hashCode() const;
      jboolean isLenient() const;
      ::java::util::Date parse(const ::java::lang::String &) const;
      void setCalendar(const ::java::util::Calendar &) const;
      void setLenient(jboolean) const;
      void setNumberFormat(const ::java::text::NumberFormat &) const;
      void setTimeZone(const ::java::util::TimeZone &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(DateFormat);
    _dll_lucene extern PyTypeObject *PY_TYPE(DateFormat);

    class _dll_lucene t_DateFormat {
    public:
      PyObject_HEAD
      DateFormat object;
      static PyObject *wrap_Object(const DateFormat&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
