#ifndef java_util_UUID_H
#define java_util_UUID_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class Comparable;
    class String;
  }
  namespace util {
    class UUID;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene UUID : public ::java::lang::Object {
     public:
      enum {
        mid_init$_000000004e103c94,
        mid_clockSequence_000000002043cb81,
        mid_compareTo_ffffffffb8bd968a,
        mid_equals_000000007b2e38e9,
        mid_fromString_000000002296ffda,
        mid_getLeastSignificantBits_ffffffffb4c92ea6,
        mid_getMostSignificantBits_ffffffffb4c92ea6,
        mid_hashCode_000000002043cb81,
        mid_nameUUIDFromBytes_0000000050ee59d4,
        mid_node_ffffffffb4c92ea6,
        mid_randomUUID_000000002d087094,
        mid_timestamp_ffffffffb4c92ea6,
        mid_toString_000000001d4fc793,
        mid_variant_000000002043cb81,
        mid_version_000000002043cb81,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit UUID(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      UUID(const UUID& obj) : ::java::lang::Object(obj) {}

      UUID(jlong, jlong);

      jint clockSequence() const;
      jint compareTo(const UUID &) const;
      jboolean equals(const ::java::lang::Object &) const;
      static UUID fromString(const ::java::lang::String &);
      jlong getLeastSignificantBits() const;
      jlong getMostSignificantBits() const;
      jint hashCode() const;
      static UUID nameUUIDFromBytes(const JArray< jbyte > &);
      jlong node() const;
      static UUID randomUUID();
      jlong timestamp() const;
      ::java::lang::String toString() const;
      jint variant() const;
      jint version() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(UUID);
    _dll_lucene extern PyTypeObject *PY_TYPE(UUID);

    class _dll_lucene t_UUID {
    public:
      PyObject_HEAD
      UUID object;
      static PyObject *wrap_Object(const UUID&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
