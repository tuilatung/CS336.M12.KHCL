#ifndef java_util_AbstractList_H
#define java_util_AbstractList_H

#include "java/util/AbstractCollection.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
  }
  namespace util {
    class ListIterator;
    class Iterator;
    class List;
    class Collection;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene AbstractList : public ::java::util::AbstractCollection {
     public:
      enum {
        mid_add_000000007b2e38e9,
        mid_add_0000000031a8cc28,
        mid_addAll_ffffffff9a0bb60f,
        mid_clear_ffffffffde902c42,
        mid_equals_000000007b2e38e9,
        mid_get_ffffffff9d560ea6,
        mid_hashCode_000000002043cb81,
        mid_indexOf_fffffffffdd5cef1,
        mid_iterator_ffffffffafc8ac37,
        mid_lastIndexOf_fffffffffdd5cef1,
        mid_listIterator_ffffffffe601cdd2,
        mid_listIterator_ffffffff942d51ab,
        mid_remove_ffffffff9d560ea6,
        mid_set_ffffffff8855d074,
        mid_subList_ffffffff98332b9b,
        mid_removeRange_fffffffffa24a7fc,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit AbstractList(jobject obj) : ::java::util::AbstractCollection(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      AbstractList(const AbstractList& obj) : ::java::util::AbstractCollection(obj) {}

      jboolean add(const ::java::lang::Object &) const;
      void add(jint, const ::java::lang::Object &) const;
      jboolean addAll(jint, const ::java::util::Collection &) const;
      void clear() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::lang::Object get(jint) const;
      jint hashCode() const;
      jint indexOf(const ::java::lang::Object &) const;
      ::java::util::Iterator iterator() const;
      jint lastIndexOf(const ::java::lang::Object &) const;
      ::java::util::ListIterator listIterator() const;
      ::java::util::ListIterator listIterator(jint) const;
      ::java::lang::Object remove(jint) const;
      ::java::lang::Object set(jint, const ::java::lang::Object &) const;
      ::java::util::List subList(jint, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(AbstractList);
    _dll_lucene extern PyTypeObject *PY_TYPE(AbstractList);

    class _dll_lucene t_AbstractList {
    public:
      PyObject_HEAD
      AbstractList object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_AbstractList *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const AbstractList&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const AbstractList&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
