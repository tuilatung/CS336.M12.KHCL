#ifndef java_util_NavigableMap_H
#define java_util_NavigableMap_H

#include "java/util/SortedMap.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
  }
  namespace util {
    class NavigableSet;
    class NavigableMap;
    class Map$Entry;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene NavigableMap : public ::java::util::SortedMap {
     public:
      enum {
        mid_ceilingEntry_0000000067d81f07,
        mid_ceilingKey_ffffffff8bf08471,
        mid_descendingKeySet_ffffffffaa354270,
        mid_descendingMap_ffffffff8a3485b5,
        mid_firstEntry_ffffffffd4d24527,
        mid_floorEntry_0000000067d81f07,
        mid_floorKey_ffffffff8bf08471,
        mid_headMap_ffffffffaa7aa2b8,
        mid_headMap_fffffffffde4b2cf,
        mid_higherEntry_0000000067d81f07,
        mid_higherKey_ffffffff8bf08471,
        mid_lastEntry_ffffffffd4d24527,
        mid_lowerEntry_0000000067d81f07,
        mid_lowerKey_ffffffff8bf08471,
        mid_navigableKeySet_ffffffffaa354270,
        mid_pollFirstEntry_ffffffffd4d24527,
        mid_pollLastEntry_ffffffffd4d24527,
        mid_subMap_ffffffffb0367bf9,
        mid_subMap_000000006341e5e2,
        mid_tailMap_ffffffffaa7aa2b8,
        mid_tailMap_fffffffffde4b2cf,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit NavigableMap(jobject obj) : ::java::util::SortedMap(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      NavigableMap(const NavigableMap& obj) : ::java::util::SortedMap(obj) {}

      ::java::util::Map$Entry ceilingEntry(const ::java::lang::Object &) const;
      ::java::lang::Object ceilingKey(const ::java::lang::Object &) const;
      ::java::util::NavigableSet descendingKeySet() const;
      NavigableMap descendingMap() const;
      ::java::util::Map$Entry firstEntry() const;
      ::java::util::Map$Entry floorEntry(const ::java::lang::Object &) const;
      ::java::lang::Object floorKey(const ::java::lang::Object &) const;
      ::java::util::SortedMap headMap(const ::java::lang::Object &) const;
      NavigableMap headMap(const ::java::lang::Object &, jboolean) const;
      ::java::util::Map$Entry higherEntry(const ::java::lang::Object &) const;
      ::java::lang::Object higherKey(const ::java::lang::Object &) const;
      ::java::util::Map$Entry lastEntry() const;
      ::java::util::Map$Entry lowerEntry(const ::java::lang::Object &) const;
      ::java::lang::Object lowerKey(const ::java::lang::Object &) const;
      ::java::util::NavigableSet navigableKeySet() const;
      ::java::util::Map$Entry pollFirstEntry() const;
      ::java::util::Map$Entry pollLastEntry() const;
      ::java::util::SortedMap subMap(const ::java::lang::Object &, const ::java::lang::Object &) const;
      NavigableMap subMap(const ::java::lang::Object &, jboolean, const ::java::lang::Object &, jboolean) const;
      ::java::util::SortedMap tailMap(const ::java::lang::Object &) const;
      NavigableMap tailMap(const ::java::lang::Object &, jboolean) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(NavigableMap);
    _dll_lucene extern PyTypeObject *PY_TYPE(NavigableMap);

    class _dll_lucene t_NavigableMap {
    public:
      PyObject_HEAD
      NavigableMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_NavigableMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const NavigableMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const NavigableMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
