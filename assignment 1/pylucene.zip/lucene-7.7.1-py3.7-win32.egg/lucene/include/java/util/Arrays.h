#ifndef java_util_Arrays_H
#define java_util_Arrays_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class Comparable;
    class String;
  }
  namespace util {
    class Spliterator$OfLong;
    class Spliterator;
    class Spliterator$OfDouble;
    class Spliterator$OfInt;
    class List;
    class Comparator;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Arrays : public ::java::lang::Object {
     public:
      enum {
        mid_asList_fffffffffa577d65,
        mid_binarySearch_000000001f73d2ee,
        mid_binarySearch_00000000419e9b25,
        mid_binarySearch_ffffffffa13a757c,
        mid_binarySearch_000000004a97eea2,
        mid_binarySearch_fffffffff25946f8,
        mid_binarySearch_ffffffff8aa26759,
        mid_binarySearch_000000004f9763ff,
        mid_binarySearch_ffffffffa091f3f6,
        mid_binarySearch_ffffffff851c4b62,
        mid_binarySearch_0000000044cd2de2,
        mid_binarySearch_ffffffffbad1b630,
        mid_binarySearch_000000003d7ade38,
        mid_binarySearch_000000007673cb24,
        mid_binarySearch_00000000699b7cf5,
        mid_binarySearch_ffffffffb8208925,
        mid_binarySearch_0000000078aea9de,
        mid_binarySearch_ffffffff942bce51,
        mid_binarySearch_ffffffffe63dd4e4,
        mid_copyOf_ffffffff843fd47f,
        mid_copyOf_ffffffff921277a6,
        mid_copyOf_ffffffffa225d398,
        mid_copyOf_ffffffff9f1dc145,
        mid_copyOf_000000004383b1a5,
        mid_copyOf_ffffffffdc9a6e52,
        mid_copyOf_ffffffffed08fa4f,
        mid_copyOf_000000002b312fe4,
        mid_copyOf_0000000020e1283f,
        mid_copyOf_ffffffffcbc31003,
        mid_copyOfRange_ffffffffce1b5852,
        mid_copyOfRange_000000000d237f14,
        mid_copyOfRange_000000002cec6935,
        mid_copyOfRange_000000001e38ff3a,
        mid_copyOfRange_ffffffffb064fd07,
        mid_copyOfRange_ffffffffaf39f15c,
        mid_copyOfRange_ffffffffb8eea541,
        mid_copyOfRange_000000001224469a,
        mid_copyOfRange_00000000677aea82,
        mid_copyOfRange_ffffffffd075de3a,
        mid_deepEquals_000000004cf358df,
        mid_deepHashCode_0000000051894836,
        mid_deepToString_ffffffff9c8660a6,
        mid_equals_ffffffffb1c999ef,
        mid_equals_ffffffffc63aa8f7,
        mid_equals_00000000371a9384,
        mid_equals_ffffffff9fa7630b,
        mid_equals_000000004cf358df,
        mid_equals_ffffffff9b7aaab6,
        mid_equals_0000000064f13cb0,
        mid_equals_00000000311cf984,
        mid_equals_000000002698093f,
        mid_fill_0000000067a0e8fa,
        mid_fill_ffffffffd8589b2b,
        mid_fill_ffffffffc2fc33b0,
        mid_fill_000000000e6213f8,
        mid_fill_fffffffff1bf7537,
        mid_fill_ffffffffc9f600d2,
        mid_fill_ffffffffec789d03,
        mid_fill_000000005eb3d3ff,
        mid_fill_ffffffffa9c23400,
        mid_fill_00000000629e2240,
        mid_fill_ffffffff99926fd6,
        mid_fill_000000005284e932,
        mid_fill_000000003786ba47,
        mid_fill_0000000024607243,
        mid_fill_0000000072c173e4,
        mid_fill_000000005dbf2359,
        mid_fill_00000000167aa94d,
        mid_fill_000000004acefe06,
        mid_hashCode_ffffffffceb14ffc,
        mid_hashCode_fffffffff4e7b1f1,
        mid_hashCode_0000000016e12ada,
        mid_hashCode_ffffffff83e0f68b,
        mid_hashCode_000000007d1cd7f2,
        mid_hashCode_0000000055d24cba,
        mid_hashCode_000000000acf9af3,
        mid_hashCode_0000000015233544,
        mid_hashCode_0000000051894836,
        mid_parallelSort_0000000078ea9df7,
        mid_parallelSort_000000002dcf6646,
        mid_parallelSort_000000003d269aa7,
        mid_parallelSort_0000000071cd5c7a,
        mid_parallelSort_ffffffffa23b19d5,
        mid_parallelSort_ffffffffbb90d5bc,
        mid_parallelSort_0000000038c78f53,
        mid_parallelSort_000000006aab6159,
        mid_parallelSort_ffffffff99bfc960,
        mid_parallelSort_ffffffffc0fafb2c,
        mid_parallelSort_000000004431e79d,
        mid_parallelSort_0000000046ada8e7,
        mid_parallelSort_ffffffffc7518f5e,
        mid_parallelSort_0000000075b1d19b,
        mid_parallelSort_00000000311f6778,
        mid_parallelSort_000000003dcaa7e5,
        mid_parallelSort_0000000052290416,
        mid_parallelSort_000000003721511a,
        mid_sort_000000002dcf6646,
        mid_sort_0000000038c78f53,
        mid_sort_0000000078ea9df7,
        mid_sort_ffffffffa23b19d5,
        mid_sort_000000006aab6159,
        mid_sort_ffffffff923044da,
        mid_sort_ffffffffbb90d5bc,
        mid_sort_0000000071cd5c7a,
        mid_sort_ffffffff99bfc960,
        mid_sort_ffffffffc0fafb2c,
        mid_sort_00000000311f6778,
        mid_sort_000000003dcaa7e5,
        mid_sort_0000000052290416,
        mid_sort_ffffffffdc3cde90,
        mid_sort_000000004431e79d,
        mid_sort_0000000075b1d19b,
        mid_sort_0000000046ada8e7,
        mid_sort_000000003721511a,
        mid_spliterator_0000000047cf1f22,
        mid_spliterator_ffffffffb581217a,
        mid_spliterator_ffffffffd3c907fb,
        mid_spliterator_00000000160b729f,
        mid_spliterator_00000000569f02c0,
        mid_spliterator_00000000427bd97a,
        mid_spliterator_00000000076b8c83,
        mid_spliterator_000000001349d850,
        mid_toString_ffffffff89f3ecc6,
        mid_toString_000000006845af60,
        mid_toString_000000004d04aa1b,
        mid_toString_00000000084e090e,
        mid_toString_ffffffffabc42191,
        mid_toString_ffffffffa88dcfcb,
        mid_toString_ffffffffbafe3c2a,
        mid_toString_0000000015a5f85f,
        mid_toString_ffffffff9c8660a6,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Arrays(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Arrays(const Arrays& obj) : ::java::lang::Object(obj) {}

      static ::java::util::List asList(const JArray< ::java::lang::Object > &);
      static jint binarySearch(const JArray< jlong > &, jlong);
      static jint binarySearch(const JArray< jint > &, jint);
      static jint binarySearch(const JArray< ::java::lang::Object > &, const ::java::lang::Object &);
      static jint binarySearch(const JArray< jfloat > &, jfloat);
      static jint binarySearch(const JArray< jshort > &, jshort);
      static jint binarySearch(const JArray< jchar > &, jchar);
      static jint binarySearch(const JArray< jbyte > &, jbyte);
      static jint binarySearch(const JArray< jdouble > &, jdouble);
      static jint binarySearch(const JArray< ::java::lang::Object > &, const ::java::lang::Object &, const ::java::util::Comparator &);
      static jint binarySearch(const JArray< jint > &, jint, jint, jint);
      static jint binarySearch(const JArray< jlong > &, jint, jint, jlong);
      static jint binarySearch(const JArray< jfloat > &, jint, jint, jfloat);
      static jint binarySearch(const JArray< jdouble > &, jint, jint, jdouble);
      static jint binarySearch(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Object &);
      static jint binarySearch(const JArray< jshort > &, jint, jint, jshort);
      static jint binarySearch(const JArray< jchar > &, jint, jint, jchar);
      static jint binarySearch(const JArray< jbyte > &, jint, jint, jbyte);
      static jint binarySearch(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Object &, const ::java::util::Comparator &);
      static JArray< jfloat > copyOf(const JArray< jfloat > &, jint);
      static JArray< jchar > copyOf(const JArray< jchar > &, jint);
      static JArray< jlong > copyOf(const JArray< jlong > &, jint);
      static JArray< jdouble > copyOf(const JArray< jdouble > &, jint);
      static JArray< jboolean > copyOf(const JArray< jboolean > &, jint);
      static JArray< ::java::lang::Object > copyOf(const JArray< ::java::lang::Object > &, jint);
      static JArray< jbyte > copyOf(const JArray< jbyte > &, jint);
      static JArray< jshort > copyOf(const JArray< jshort > &, jint);
      static JArray< jint > copyOf(const JArray< jint > &, jint);
      static JArray< ::java::lang::Object > copyOf(const JArray< ::java::lang::Object > &, jint, const ::java::lang::Class &);
      static JArray< jbyte > copyOfRange(const JArray< jbyte > &, jint, jint);
      static JArray< jshort > copyOfRange(const JArray< jshort > &, jint, jint);
      static JArray< ::java::lang::Object > copyOfRange(const JArray< ::java::lang::Object > &, jint, jint);
      static JArray< jboolean > copyOfRange(const JArray< jboolean > &, jint, jint);
      static JArray< jdouble > copyOfRange(const JArray< jdouble > &, jint, jint);
      static JArray< jfloat > copyOfRange(const JArray< jfloat > &, jint, jint);
      static JArray< jint > copyOfRange(const JArray< jint > &, jint, jint);
      static JArray< jlong > copyOfRange(const JArray< jlong > &, jint, jint);
      static JArray< jchar > copyOfRange(const JArray< jchar > &, jint, jint);
      static JArray< ::java::lang::Object > copyOfRange(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Class &);
      static jboolean deepEquals(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &);
      static jint deepHashCode(const JArray< ::java::lang::Object > &);
      static ::java::lang::String deepToString(const JArray< ::java::lang::Object > &);
      static jboolean equals(const JArray< jbyte > &, const JArray< jbyte > &);
      static jboolean equals(const JArray< jboolean > &, const JArray< jboolean > &);
      static jboolean equals(const JArray< jdouble > &, const JArray< jdouble > &);
      static jboolean equals(const JArray< jfloat > &, const JArray< jfloat > &);
      static jboolean equals(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &);
      static jboolean equals(const JArray< jshort > &, const JArray< jshort > &);
      static jboolean equals(const JArray< jint > &, const JArray< jint > &);
      static jboolean equals(const JArray< jlong > &, const JArray< jlong > &);
      static jboolean equals(const JArray< jchar > &, const JArray< jchar > &);
      static void fill(const JArray< jfloat > &, jfloat);
      static void fill(const JArray< jdouble > &, jdouble);
      static void fill(const JArray< jlong > &, jlong);
      static void fill(const JArray< ::java::lang::Object > &, const ::java::lang::Object &);
      static void fill(const JArray< jchar > &, jchar);
      static void fill(const JArray< jbyte > &, jbyte);
      static void fill(const JArray< jboolean > &, jboolean);
      static void fill(const JArray< jshort > &, jshort);
      static void fill(const JArray< jint > &, jint);
      static void fill(const JArray< jdouble > &, jint, jint, jdouble);
      static void fill(const JArray< jboolean > &, jint, jint, jboolean);
      static void fill(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Object &);
      static void fill(const JArray< jfloat > &, jint, jint, jfloat);
      static void fill(const JArray< jchar > &, jint, jint, jchar);
      static void fill(const JArray< jbyte > &, jint, jint, jbyte);
      static void fill(const JArray< jlong > &, jint, jint, jlong);
      static void fill(const JArray< jint > &, jint, jint, jint);
      static void fill(const JArray< jshort > &, jint, jint, jshort);
      static jint hashCode(const JArray< jbyte > &);
      static jint hashCode(const JArray< jboolean > &);
      static jint hashCode(const JArray< jfloat > &);
      static jint hashCode(const JArray< jdouble > &);
      static jint hashCode(const JArray< jlong > &);
      static jint hashCode(const JArray< jint > &);
      static jint hashCode(const JArray< jshort > &);
      static jint hashCode(const JArray< jchar > &);
      static jint hashCode(const JArray< ::java::lang::Object > &);
      static void parallelSort(const JArray< jfloat > &);
      static void parallelSort(const JArray< jlong > &);
      static void parallelSort(const JArray< ::java::lang::Comparable > &);
      static void parallelSort(const JArray< jdouble > &);
      static void parallelSort(const JArray< jchar > &);
      static void parallelSort(const JArray< jint > &);
      static void parallelSort(const JArray< jbyte > &);
      static void parallelSort(const JArray< jshort > &);
      static void parallelSort(const JArray< ::java::lang::Object > &, const ::java::util::Comparator &);
      static void parallelSort(const JArray< jlong > &, jint, jint);
      static void parallelSort(const JArray< jfloat > &, jint, jint);
      static void parallelSort(const JArray< jint > &, jint, jint);
      static void parallelSort(const JArray< ::java::lang::Comparable > &, jint, jint);
      static void parallelSort(const JArray< jdouble > &, jint, jint);
      static void parallelSort(const JArray< jbyte > &, jint, jint);
      static void parallelSort(const JArray< jshort > &, jint, jint);
      static void parallelSort(const JArray< jchar > &, jint, jint);
      static void parallelSort(const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::Comparator &);
      static void sort(const JArray< jlong > &);
      static void sort(const JArray< jbyte > &);
      static void sort(const JArray< jfloat > &);
      static void sort(const JArray< jchar > &);
      static void sort(const JArray< jshort > &);
      static void sort(const JArray< ::java::lang::Object > &);
      static void sort(const JArray< jint > &);
      static void sort(const JArray< jdouble > &);
      static void sort(const JArray< ::java::lang::Object > &, const ::java::util::Comparator &);
      static void sort(const JArray< jlong > &, jint, jint);
      static void sort(const JArray< jbyte > &, jint, jint);
      static void sort(const JArray< jshort > &, jint, jint);
      static void sort(const JArray< jchar > &, jint, jint);
      static void sort(const JArray< ::java::lang::Object > &, jint, jint);
      static void sort(const JArray< jfloat > &, jint, jint);
      static void sort(const JArray< jdouble > &, jint, jint);
      static void sort(const JArray< jint > &, jint, jint);
      static void sort(const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::Comparator &);
      static ::java::util::Spliterator$OfLong spliterator(const JArray< jlong > &);
      static ::java::util::Spliterator$OfDouble spliterator(const JArray< jdouble > &);
      static ::java::util::Spliterator spliterator(const JArray< ::java::lang::Object > &);
      static ::java::util::Spliterator$OfInt spliterator(const JArray< jint > &);
      static ::java::util::Spliterator$OfLong spliterator(const JArray< jlong > &, jint, jint);
      static ::java::util::Spliterator$OfInt spliterator(const JArray< jint > &, jint, jint);
      static ::java::util::Spliterator$OfDouble spliterator(const JArray< jdouble > &, jint, jint);
      static ::java::util::Spliterator spliterator(const JArray< ::java::lang::Object > &, jint, jint);
      static ::java::lang::String toString(const JArray< jboolean > &);
      static ::java::lang::String toString(const JArray< jbyte > &);
      static ::java::lang::String toString(const JArray< jfloat > &);
      static ::java::lang::String toString(const JArray< jdouble > &);
      static ::java::lang::String toString(const JArray< jlong > &);
      static ::java::lang::String toString(const JArray< jint > &);
      static ::java::lang::String toString(const JArray< jshort > &);
      static ::java::lang::String toString(const JArray< jchar > &);
      static ::java::lang::String toString(const JArray< ::java::lang::Object > &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Arrays);
    _dll_lucene extern PyTypeObject *PY_TYPE(Arrays);

    class _dll_lucene t_Arrays {
    public:
      PyObject_HEAD
      Arrays object;
      static PyObject *wrap_Object(const Arrays&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
