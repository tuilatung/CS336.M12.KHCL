#ifndef java_util_HashMap_H
#define java_util_HashMap_H

#include "java/util/AbstractMap.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class Cloneable;
  }
  namespace util {
    class Map;
    class Collection;
    class Map$Entry;
    class Set;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene HashMap : public ::java::util::AbstractMap {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffa0b31ff5,
        mid_init$_ffffffffd3ad6b94,
        mid_init$_ffffffffcf84b542,
        mid_clear_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        mid_containsKey_000000007b2e38e9,
        mid_containsValue_000000007b2e38e9,
        mid_entrySet_000000007600271d,
        mid_get_ffffffff8bf08471,
        mid_getOrDefault_ffffffffd29d9423,
        mid_isEmpty_0000000000c0c182,
        mid_keySet_000000007600271d,
        mid_put_ffffffffd29d9423,
        mid_putAll_ffffffffd3ad6b94,
        mid_putIfAbsent_ffffffffd29d9423,
        mid_remove_ffffffff8bf08471,
        mid_remove_000000000ebdd636,
        mid_replace_ffffffffd29d9423,
        mid_replace_ffffffffa4870c1b,
        mid_size_000000002043cb81,
        mid_values_ffffffffd29dc48e,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit HashMap(jobject obj) : ::java::util::AbstractMap(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      HashMap(const HashMap& obj) : ::java::util::AbstractMap(obj) {}

      HashMap();
      HashMap(jint);
      HashMap(const ::java::util::Map &);
      HashMap(jint, jfloat);

      void clear() const;
      ::java::lang::Object clone() const;
      jboolean containsKey(const ::java::lang::Object &) const;
      jboolean containsValue(const ::java::lang::Object &) const;
      ::java::util::Set entrySet() const;
      ::java::lang::Object get(const ::java::lang::Object &) const;
      ::java::lang::Object getOrDefault(const ::java::lang::Object &, const ::java::lang::Object &) const;
      jboolean isEmpty() const;
      ::java::util::Set keySet() const;
      ::java::lang::Object put(const ::java::lang::Object &, const ::java::lang::Object &) const;
      void putAll(const ::java::util::Map &) const;
      ::java::lang::Object putIfAbsent(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object remove(const ::java::lang::Object &) const;
      jboolean remove(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object replace(const ::java::lang::Object &, const ::java::lang::Object &) const;
      jboolean replace(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &) const;
      jint size() const;
      ::java::util::Collection values() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(HashMap);
    _dll_lucene extern PyTypeObject *PY_TYPE(HashMap);

    class _dll_lucene t_HashMap {
    public:
      PyObject_HEAD
      HashMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_HashMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const HashMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const HashMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
