#ifndef java_util_concurrent_Executors_H
#define java_util_concurrent_Executors_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace concurrent {
      class Callable;
      class ScheduledExecutorService;
      class ExecutorService;
      class ThreadFactory;
    }
  }
  namespace lang {
    class Class;
    class Runnable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class _dll_lucene Executors : public ::java::lang::Object {
       public:
        enum {
          mid_callable_000000007f8f9a01,
          mid_callable_00000000304816d8,
          mid_defaultThreadFactory_ffffffffe4b0d0a9,
          mid_newCachedThreadPool_000000005219f8be,
          mid_newCachedThreadPool_ffffffff999c7577,
          mid_newFixedThreadPool_000000006b363633,
          mid_newFixedThreadPool_ffffffffe2b60027,
          mid_newScheduledThreadPool_0000000009ac9664,
          mid_newScheduledThreadPool_0000000064938d20,
          mid_newSingleThreadExecutor_000000005219f8be,
          mid_newSingleThreadExecutor_ffffffff999c7577,
          mid_newSingleThreadScheduledExecutor_ffffffff9877e583,
          mid_newSingleThreadScheduledExecutor_fffffffff99f61dd,
          mid_newWorkStealingPool_000000005219f8be,
          mid_newWorkStealingPool_000000006b363633,
          mid_privilegedCallable_00000000529cc96b,
          mid_privilegedCallableUsingCurrentClassLoader_00000000529cc96b,
          mid_privilegedThreadFactory_ffffffffe4b0d0a9,
          mid_unconfigurableExecutorService_ffffffffa40cf02c,
          mid_unconfigurableScheduledExecutorService_ffffffffa280e781,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Executors(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Executors(const Executors& obj) : ::java::lang::Object(obj) {}

        static ::java::util::concurrent::Callable callable(const ::java::lang::Runnable &);
        static ::java::util::concurrent::Callable callable(const ::java::lang::Runnable &, const ::java::lang::Object &);
        static ::java::util::concurrent::ThreadFactory defaultThreadFactory();
        static ::java::util::concurrent::ExecutorService newCachedThreadPool();
        static ::java::util::concurrent::ExecutorService newCachedThreadPool(const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ExecutorService newFixedThreadPool(jint);
        static ::java::util::concurrent::ExecutorService newFixedThreadPool(jint, const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ScheduledExecutorService newScheduledThreadPool(jint);
        static ::java::util::concurrent::ScheduledExecutorService newScheduledThreadPool(jint, const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ExecutorService newSingleThreadExecutor();
        static ::java::util::concurrent::ExecutorService newSingleThreadExecutor(const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ScheduledExecutorService newSingleThreadScheduledExecutor();
        static ::java::util::concurrent::ScheduledExecutorService newSingleThreadScheduledExecutor(const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ExecutorService newWorkStealingPool();
        static ::java::util::concurrent::ExecutorService newWorkStealingPool(jint);
        static ::java::util::concurrent::Callable privilegedCallable(const ::java::util::concurrent::Callable &);
        static ::java::util::concurrent::Callable privilegedCallableUsingCurrentClassLoader(const ::java::util::concurrent::Callable &);
        static ::java::util::concurrent::ThreadFactory privilegedThreadFactory();
        static ::java::util::concurrent::ExecutorService unconfigurableExecutorService(const ::java::util::concurrent::ExecutorService &);
        static ::java::util::concurrent::ScheduledExecutorService unconfigurableScheduledExecutorService(const ::java::util::concurrent::ScheduledExecutorService &);
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(Executors);
      _dll_lucene extern PyTypeObject *PY_TYPE(Executors);

      class _dll_lucene t_Executors {
      public:
        PyObject_HEAD
        Executors object;
        static PyObject *wrap_Object(const Executors&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
