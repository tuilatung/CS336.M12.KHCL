#ifndef java_util_concurrent_ExecutorService_H
#define java_util_concurrent_ExecutorService_H

#include "java/util/concurrent/Executor.h"

namespace java {
  namespace util {
    namespace concurrent {
      class Callable;
      class Future;
      class TimeoutException;
      class TimeUnit;
      class ExecutionException;
    }
    class List;
    class Collection;
  }
  namespace lang {
    class InterruptedException;
    class Class;
    class Object;
    class Runnable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class _dll_lucene ExecutorService : public ::java::util::concurrent::Executor {
       public:
        enum {
          mid_awaitTermination_000000000ed34bf7,
          mid_invokeAll_0000000058a61207,
          mid_invokeAll_0000000038fe0f96,
          mid_invokeAny_000000000a74c746,
          mid_invokeAny_000000001a78a13a,
          mid_isShutdown_0000000000c0c182,
          mid_isTerminated_0000000000c0c182,
          mid_shutdown_ffffffffde902c42,
          mid_shutdownNow_ffffffffbf1ee3ce,
          mid_submit_0000000018454fdc,
          mid_submit_ffffffffe756ca3d,
          mid_submit_ffffffffa5b60a97,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit ExecutorService(jobject obj) : ::java::util::concurrent::Executor(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        ExecutorService(const ExecutorService& obj) : ::java::util::concurrent::Executor(obj) {}

        jboolean awaitTermination(jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::util::List invokeAll(const ::java::util::Collection &) const;
        ::java::util::List invokeAll(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        jboolean isShutdown() const;
        jboolean isTerminated() const;
        void shutdown() const;
        ::java::util::List shutdownNow() const;
        ::java::util::concurrent::Future submit(const ::java::util::concurrent::Callable &) const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &) const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &, const ::java::lang::Object &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(ExecutorService);
      _dll_lucene extern PyTypeObject *PY_TYPE(ExecutorService);

      class _dll_lucene t_ExecutorService {
      public:
        PyObject_HEAD
        ExecutorService object;
        static PyObject *wrap_Object(const ExecutorService&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
