#ifndef java_util_concurrent_ThreadFactory_H
#define java_util_concurrent_ThreadFactory_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Thread;
    class Runnable;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class _dll_lucene ThreadFactory : public ::java::lang::Object {
       public:
        enum {
          mid_newThread_ffffffffc0810c38,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit ThreadFactory(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        ThreadFactory(const ThreadFactory& obj) : ::java::lang::Object(obj) {}

        ::java::lang::Thread newThread(const ::java::lang::Runnable &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(ThreadFactory);
      _dll_lucene extern PyTypeObject *PY_TYPE(ThreadFactory);

      class _dll_lucene t_ThreadFactory {
      public:
        PyObject_HEAD
        ThreadFactory object;
        static PyObject *wrap_Object(const ThreadFactory&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
