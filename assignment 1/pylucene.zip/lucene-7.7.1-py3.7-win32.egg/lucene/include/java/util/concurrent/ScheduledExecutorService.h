#ifndef java_util_concurrent_ScheduledExecutorService_H
#define java_util_concurrent_ScheduledExecutorService_H

#include "java/util/concurrent/ExecutorService.h"

namespace java {
  namespace util {
    namespace concurrent {
      class Callable;
      class TimeUnit;
      class ScheduledFuture;
    }
  }
  namespace lang {
    class Class;
    class Object;
    class Runnable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class _dll_lucene ScheduledExecutorService : public ::java::util::concurrent::ExecutorService {
       public:
        enum {
          mid_schedule_0000000014d183d6,
          mid_schedule_ffffffffbf725586,
          mid_scheduleAtFixedRate_ffffffffa043a5d3,
          mid_scheduleWithFixedDelay_ffffffffa043a5d3,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit ScheduledExecutorService(jobject obj) : ::java::util::concurrent::ExecutorService(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        ScheduledExecutorService(const ScheduledExecutorService& obj) : ::java::util::concurrent::ExecutorService(obj) {}

        ::java::util::concurrent::ScheduledFuture schedule(const ::java::util::concurrent::Callable &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::util::concurrent::ScheduledFuture schedule(const ::java::lang::Runnable &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::util::concurrent::ScheduledFuture scheduleAtFixedRate(const ::java::lang::Runnable &, jlong, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::util::concurrent::ScheduledFuture scheduleWithFixedDelay(const ::java::lang::Runnable &, jlong, jlong, const ::java::util::concurrent::TimeUnit &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(ScheduledExecutorService);
      _dll_lucene extern PyTypeObject *PY_TYPE(ScheduledExecutorService);

      class _dll_lucene t_ScheduledExecutorService {
      public:
        PyObject_HEAD
        ScheduledExecutorService object;
        static PyObject *wrap_Object(const ScheduledExecutorService&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
