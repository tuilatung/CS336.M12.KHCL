#ifndef java_util_concurrent_AbstractExecutorService_H
#define java_util_concurrent_AbstractExecutorService_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace concurrent {
      class Callable;
      class Future;
      class TimeoutException;
      class ExecutorService;
      class TimeUnit;
      class ExecutionException;
    }
    class List;
    class Collection;
  }
  namespace lang {
    class InterruptedException;
    class Class;
    class Runnable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class _dll_lucene AbstractExecutorService : public ::java::lang::Object {
       public:
        enum {
          mid_init$_ffffffffde902c42,
          mid_invokeAll_0000000058a61207,
          mid_invokeAll_0000000038fe0f96,
          mid_invokeAny_000000000a74c746,
          mid_invokeAny_000000001a78a13a,
          mid_submit_0000000018454fdc,
          mid_submit_ffffffffe756ca3d,
          mid_submit_ffffffffa5b60a97,
          mid_newTaskFor_ffffffffea859c77,
          mid_newTaskFor_ffffffffcbb0118a,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit AbstractExecutorService(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        AbstractExecutorService(const AbstractExecutorService& obj) : ::java::lang::Object(obj) {}

        AbstractExecutorService();

        ::java::util::List invokeAll(const ::java::util::Collection &) const;
        ::java::util::List invokeAll(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::util::concurrent::Future submit(const ::java::util::concurrent::Callable &) const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &) const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &, const ::java::lang::Object &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(AbstractExecutorService);
      _dll_lucene extern PyTypeObject *PY_TYPE(AbstractExecutorService);

      class _dll_lucene t_AbstractExecutorService {
      public:
        PyObject_HEAD
        AbstractExecutorService object;
        static PyObject *wrap_Object(const AbstractExecutorService&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
