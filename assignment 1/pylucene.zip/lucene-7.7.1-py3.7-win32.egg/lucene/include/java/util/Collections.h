#ifndef java_util_Collections_H
#define java_util_Collections_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Queue;
    class ListIterator;
    class Enumeration;
    class Map;
    class Iterator;
    class List;
    class ArrayList;
    class Collection;
    class Set;
    class Random;
    class Comparator;
    class SortedSet;
    class SortedMap;
    class NavigableMap;
    class Deque;
    class NavigableSet;
  }
  namespace lang {
    class Boolean;
    class Class;
    class Comparable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Collections : public ::java::lang::Object {
     public:
      enum {
        mid_addAll_ffffffffe39e556c,
        mid_asLifoQueue_ffffffffaac0f86c,
        mid_binarySearch_ffffffff9b1b2598,
        mid_binarySearch_ffffffff9c323353,
        mid_checkedCollection_ffffffffa0cb1708,
        mid_checkedList_ffffffffbe686c58,
        mid_checkedMap_fffffffff0f9364e,
        mid_checkedNavigableMap_000000007dd76de0,
        mid_checkedNavigableSet_ffffffffc1d0f487,
        mid_checkedQueue_000000002916eaee,
        mid_checkedSet_000000007dd4fb20,
        mid_checkedSortedMap_0000000043fdb054,
        mid_checkedSortedSet_000000002cca0ef8,
        mid_copy_0000000010345fc0,
        mid_disjoint_fffffffff8578251,
        mid_emptyEnumeration_000000003fb08ac2,
        mid_emptyIterator_ffffffffafc8ac37,
        mid_emptyList_ffffffffbf1ee3ce,
        mid_emptyListIterator_ffffffffe601cdd2,
        mid_emptyMap_000000007d6a46b0,
        mid_emptyNavigableMap_ffffffff8a3485b5,
        mid_emptyNavigableSet_ffffffffaa354270,
        mid_emptySet_000000007600271d,
        mid_emptySortedMap_00000000439448b0,
        mid_emptySortedSet_ffffffff913f1b50,
        mid_enumeration_000000005d5e0e20,
        mid_fill_000000001c86c7f6,
        mid_frequency_0000000024e4ebad,
        mid_indexOfSubList_fffffffffaec69a7,
        mid_lastIndexOfSubList_fffffffffaec69a7,
        mid_list_ffffffffc4377155,
        mid_max_000000000a74c746,
        mid_max_0000000042ec63be,
        mid_min_000000000a74c746,
        mid_min_0000000042ec63be,
        mid_nCopies_00000000026f55b5,
        mid_newSetFromMap_ffffffff990f720e,
        mid_replaceAll_ffffffffea7b5942,
        mid_reverse_ffffffffe19bf3ee,
        mid_reverseOrder_ffffffff83924d7b,
        mid_reverseOrder_ffffffffd6a62cb5,
        mid_rotate_000000007d92c7fd,
        mid_shuffle_ffffffffe19bf3ee,
        mid_shuffle_ffffffffbaa77589,
        mid_singleton_ffffffff9c93547f,
        mid_singletonList_ffffffffc4397ccc,
        mid_singletonMap_ffffffffbfdb6875,
        mid_sort_ffffffffe19bf3ee,
        mid_sort_000000000c82e183,
        mid_swap_ffffffffb8e228c8,
        mid_synchronizedCollection_00000000700df99c,
        mid_synchronizedList_ffffffff8bc0ce53,
        mid_synchronizedMap_fffffffff03be113,
        mid_synchronizedNavigableMap_ffffffffe0fdffa3,
        mid_synchronizedNavigableSet_ffffffff9fc93df3,
        mid_synchronizedSet_ffffffffc79b458b,
        mid_synchronizedSortedMap_ffffffffe09af7f9,
        mid_synchronizedSortedSet_ffffffffa4648598,
        mid_unmodifiableCollection_00000000700df99c,
        mid_unmodifiableList_ffffffff8bc0ce53,
        mid_unmodifiableMap_fffffffff03be113,
        mid_unmodifiableNavigableMap_ffffffffe0fdffa3,
        mid_unmodifiableNavigableSet_ffffffff9fc93df3,
        mid_unmodifiableSet_ffffffffc79b458b,
        mid_unmodifiableSortedMap_ffffffffe09af7f9,
        mid_unmodifiableSortedSet_ffffffffa4648598,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Collections(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Collections(const Collections& obj) : ::java::lang::Object(obj) {}

      static ::java::util::List *EMPTY_LIST;
      static ::java::util::Map *EMPTY_MAP;
      static ::java::util::Set *EMPTY_SET;

      static jboolean addAll(const ::java::util::Collection &, const JArray< ::java::lang::Object > &);
      static ::java::util::Queue asLifoQueue(const ::java::util::Deque &);
      static jint binarySearch(const ::java::util::List &, const ::java::lang::Object &);
      static jint binarySearch(const ::java::util::List &, const ::java::lang::Object &, const ::java::util::Comparator &);
      static ::java::util::Collection checkedCollection(const ::java::util::Collection &, const ::java::lang::Class &);
      static ::java::util::List checkedList(const ::java::util::List &, const ::java::lang::Class &);
      static ::java::util::Map checkedMap(const ::java::util::Map &, const ::java::lang::Class &, const ::java::lang::Class &);
      static ::java::util::NavigableMap checkedNavigableMap(const ::java::util::NavigableMap &, const ::java::lang::Class &, const ::java::lang::Class &);
      static ::java::util::NavigableSet checkedNavigableSet(const ::java::util::NavigableSet &, const ::java::lang::Class &);
      static ::java::util::Queue checkedQueue(const ::java::util::Queue &, const ::java::lang::Class &);
      static ::java::util::Set checkedSet(const ::java::util::Set &, const ::java::lang::Class &);
      static ::java::util::SortedMap checkedSortedMap(const ::java::util::SortedMap &, const ::java::lang::Class &, const ::java::lang::Class &);
      static ::java::util::SortedSet checkedSortedSet(const ::java::util::SortedSet &, const ::java::lang::Class &);
      static void copy(const ::java::util::List &, const ::java::util::List &);
      static jboolean disjoint(const ::java::util::Collection &, const ::java::util::Collection &);
      static ::java::util::Enumeration emptyEnumeration();
      static ::java::util::Iterator emptyIterator();
      static ::java::util::List emptyList();
      static ::java::util::ListIterator emptyListIterator();
      static ::java::util::Map emptyMap();
      static ::java::util::NavigableMap emptyNavigableMap();
      static ::java::util::NavigableSet emptyNavigableSet();
      static ::java::util::Set emptySet();
      static ::java::util::SortedMap emptySortedMap();
      static ::java::util::SortedSet emptySortedSet();
      static ::java::util::Enumeration enumeration(const ::java::util::Collection &);
      static void fill(const ::java::util::List &, const ::java::lang::Object &);
      static jint frequency(const ::java::util::Collection &, const ::java::lang::Object &);
      static jint indexOfSubList(const ::java::util::List &, const ::java::util::List &);
      static jint lastIndexOfSubList(const ::java::util::List &, const ::java::util::List &);
      static ::java::util::ArrayList list(const ::java::util::Enumeration &);
      static ::java::lang::Object max$(const ::java::util::Collection &);
      static ::java::lang::Object max$(const ::java::util::Collection &, const ::java::util::Comparator &);
      static ::java::lang::Object min$(const ::java::util::Collection &);
      static ::java::lang::Object min$(const ::java::util::Collection &, const ::java::util::Comparator &);
      static ::java::util::List nCopies(jint, const ::java::lang::Object &);
      static ::java::util::Set newSetFromMap(const ::java::util::Map &);
      static jboolean replaceAll(const ::java::util::List &, const ::java::lang::Object &, const ::java::lang::Object &);
      static void reverse(const ::java::util::List &);
      static ::java::util::Comparator reverseOrder();
      static ::java::util::Comparator reverseOrder(const ::java::util::Comparator &);
      static void rotate(const ::java::util::List &, jint);
      static void shuffle(const ::java::util::List &);
      static void shuffle(const ::java::util::List &, const ::java::util::Random &);
      static ::java::util::Set singleton(const ::java::lang::Object &);
      static ::java::util::List singletonList(const ::java::lang::Object &);
      static ::java::util::Map singletonMap(const ::java::lang::Object &, const ::java::lang::Object &);
      static void sort(const ::java::util::List &);
      static void sort(const ::java::util::List &, const ::java::util::Comparator &);
      static void swap(const ::java::util::List &, jint, jint);
      static ::java::util::Collection synchronizedCollection(const ::java::util::Collection &);
      static ::java::util::List synchronizedList(const ::java::util::List &);
      static ::java::util::Map synchronizedMap(const ::java::util::Map &);
      static ::java::util::NavigableMap synchronizedNavigableMap(const ::java::util::NavigableMap &);
      static ::java::util::NavigableSet synchronizedNavigableSet(const ::java::util::NavigableSet &);
      static ::java::util::Set synchronizedSet(const ::java::util::Set &);
      static ::java::util::SortedMap synchronizedSortedMap(const ::java::util::SortedMap &);
      static ::java::util::SortedSet synchronizedSortedSet(const ::java::util::SortedSet &);
      static ::java::util::Collection unmodifiableCollection(const ::java::util::Collection &);
      static ::java::util::List unmodifiableList(const ::java::util::List &);
      static ::java::util::Map unmodifiableMap(const ::java::util::Map &);
      static ::java::util::NavigableMap unmodifiableNavigableMap(const ::java::util::NavigableMap &);
      static ::java::util::NavigableSet unmodifiableNavigableSet(const ::java::util::NavigableSet &);
      static ::java::util::Set unmodifiableSet(const ::java::util::Set &);
      static ::java::util::SortedMap unmodifiableSortedMap(const ::java::util::SortedMap &);
      static ::java::util::SortedSet unmodifiableSortedSet(const ::java::util::SortedSet &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Collections);
    _dll_lucene extern PyTypeObject *PY_TYPE(Collections);

    class _dll_lucene t_Collections {
    public:
      PyObject_HEAD
      Collections object;
      static PyObject *wrap_Object(const Collections&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
