#ifndef java_util_AbstractSequentialList_H
#define java_util_AbstractSequentialList_H

#include "java/util/AbstractList.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
  }
  namespace util {
    class ListIterator;
    class Iterator;
    class Collection;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene AbstractSequentialList : public ::java::util::AbstractList {
     public:
      enum {
        mid_add_0000000031a8cc28,
        mid_addAll_ffffffff9a0bb60f,
        mid_get_ffffffff9d560ea6,
        mid_iterator_ffffffffafc8ac37,
        mid_listIterator_ffffffff942d51ab,
        mid_remove_ffffffff9d560ea6,
        mid_set_ffffffff8855d074,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit AbstractSequentialList(jobject obj) : ::java::util::AbstractList(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      AbstractSequentialList(const AbstractSequentialList& obj) : ::java::util::AbstractList(obj) {}

      void add(jint, const ::java::lang::Object &) const;
      jboolean addAll(jint, const ::java::util::Collection &) const;
      ::java::lang::Object get(jint) const;
      ::java::util::Iterator iterator() const;
      ::java::util::ListIterator listIterator(jint) const;
      ::java::lang::Object remove(jint) const;
      ::java::lang::Object set(jint, const ::java::lang::Object &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(AbstractSequentialList);
    _dll_lucene extern PyTypeObject *PY_TYPE(AbstractSequentialList);

    class _dll_lucene t_AbstractSequentialList {
    public:
      PyObject_HEAD
      AbstractSequentialList object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_AbstractSequentialList *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const AbstractSequentialList&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const AbstractSequentialList&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
