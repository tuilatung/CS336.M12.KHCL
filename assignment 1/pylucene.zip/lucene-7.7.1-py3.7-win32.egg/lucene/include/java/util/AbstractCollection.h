#ifndef java_util_AbstractCollection_H
#define java_util_AbstractCollection_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace util {
    class Iterator;
    class Collection;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene AbstractCollection : public ::java::lang::Object {
     public:
      enum {
        mid_add_000000007b2e38e9,
        mid_addAll_00000000178b4ca7,
        mid_clear_ffffffffde902c42,
        mid_contains_000000007b2e38e9,
        mid_containsAll_00000000178b4ca7,
        mid_isEmpty_0000000000c0c182,
        mid_iterator_ffffffffafc8ac37,
        mid_remove_000000007b2e38e9,
        mid_removeAll_00000000178b4ca7,
        mid_retainAll_00000000178b4ca7,
        mid_size_000000002043cb81,
        mid_toArray_000000000a31633c,
        mid_toArray_ffffffff8c6e9dd5,
        mid_toString_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit AbstractCollection(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      AbstractCollection(const AbstractCollection& obj) : ::java::lang::Object(obj) {}

      jboolean add(const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      void clear() const;
      jboolean contains(const ::java::lang::Object &) const;
      jboolean containsAll(const ::java::util::Collection &) const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      jboolean remove(const ::java::lang::Object &) const;
      jboolean removeAll(const ::java::util::Collection &) const;
      jboolean retainAll(const ::java::util::Collection &) const;
      jint size() const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(AbstractCollection);
    _dll_lucene extern PyTypeObject *PY_TYPE(AbstractCollection);

    class _dll_lucene t_AbstractCollection {
    public:
      PyObject_HEAD
      AbstractCollection object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_AbstractCollection *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const AbstractCollection&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const AbstractCollection&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
