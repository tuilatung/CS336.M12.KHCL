#ifndef java_util_ArrayList_H
#define java_util_ArrayList_H

#include "java/util/AbstractList.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class Cloneable;
  }
  namespace util {
    class Spliterator;
    class ListIterator;
    class List;
    class Iterator;
    class Collection;
    class RandomAccess;
    class Comparator;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene ArrayList : public ::java::util::AbstractList {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_000000000f1531cc,
        mid_init$_ffffffffa0b31ff5,
        mid_add_000000007b2e38e9,
        mid_add_0000000031a8cc28,
        mid_addAll_00000000178b4ca7,
        mid_addAll_ffffffff9a0bb60f,
        mid_clear_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        mid_contains_000000007b2e38e9,
        mid_ensureCapacity_ffffffffa0b31ff5,
        mid_get_ffffffff9d560ea6,
        mid_indexOf_fffffffffdd5cef1,
        mid_isEmpty_0000000000c0c182,
        mid_iterator_ffffffffafc8ac37,
        mid_lastIndexOf_fffffffffdd5cef1,
        mid_listIterator_ffffffffe601cdd2,
        mid_listIterator_ffffffff942d51ab,
        mid_remove_000000007b2e38e9,
        mid_remove_ffffffff9d560ea6,
        mid_removeAll_00000000178b4ca7,
        mid_retainAll_00000000178b4ca7,
        mid_set_ffffffff8855d074,
        mid_size_000000002043cb81,
        mid_sort_0000000071bbcb63,
        mid_spliterator_ffffffffd8ac147a,
        mid_subList_ffffffff98332b9b,
        mid_toArray_000000000a31633c,
        mid_toArray_ffffffff8c6e9dd5,
        mid_trimToSize_ffffffffde902c42,
        mid_removeRange_fffffffffa24a7fc,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ArrayList(jobject obj) : ::java::util::AbstractList(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ArrayList(const ArrayList& obj) : ::java::util::AbstractList(obj) {}

      ArrayList();
      ArrayList(const ::java::util::Collection &);
      ArrayList(jint);

      jboolean add(const ::java::lang::Object &) const;
      void add(jint, const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      jboolean addAll(jint, const ::java::util::Collection &) const;
      void clear() const;
      ::java::lang::Object clone() const;
      jboolean contains(const ::java::lang::Object &) const;
      void ensureCapacity(jint) const;
      ::java::lang::Object get(jint) const;
      jint indexOf(const ::java::lang::Object &) const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      jint lastIndexOf(const ::java::lang::Object &) const;
      ::java::util::ListIterator listIterator() const;
      ::java::util::ListIterator listIterator(jint) const;
      jboolean remove(const ::java::lang::Object &) const;
      ::java::lang::Object remove(jint) const;
      jboolean removeAll(const ::java::util::Collection &) const;
      jboolean retainAll(const ::java::util::Collection &) const;
      ::java::lang::Object set(jint, const ::java::lang::Object &) const;
      jint size() const;
      void sort(const ::java::util::Comparator &) const;
      ::java::util::Spliterator spliterator() const;
      ::java::util::List subList(jint, jint) const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
      void trimToSize() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(ArrayList);
    _dll_lucene extern PyTypeObject *PY_TYPE(ArrayList);

    class _dll_lucene t_ArrayList {
    public:
      PyObject_HEAD
      ArrayList object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_ArrayList *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const ArrayList&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const ArrayList&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
