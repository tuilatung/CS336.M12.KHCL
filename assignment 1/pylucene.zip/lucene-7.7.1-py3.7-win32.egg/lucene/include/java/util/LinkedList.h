#ifndef java_util_LinkedList_H
#define java_util_LinkedList_H

#include "java/util/AbstractSequentialList.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class Cloneable;
  }
  namespace util {
    class Deque;
    class Spliterator;
    class ListIterator;
    class Iterator;
    class Collection;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene LinkedList : public ::java::util::AbstractSequentialList {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_000000000f1531cc,
        mid_add_000000007b2e38e9,
        mid_add_0000000031a8cc28,
        mid_addAll_00000000178b4ca7,
        mid_addAll_ffffffff9a0bb60f,
        mid_addFirst_ffffffff9530faa9,
        mid_addLast_ffffffff9530faa9,
        mid_clear_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        mid_contains_000000007b2e38e9,
        mid_descendingIterator_ffffffffafc8ac37,
        mid_element_ffffffffdcc2e1cc,
        mid_get_ffffffff9d560ea6,
        mid_getFirst_ffffffffdcc2e1cc,
        mid_getLast_ffffffffdcc2e1cc,
        mid_indexOf_fffffffffdd5cef1,
        mid_lastIndexOf_fffffffffdd5cef1,
        mid_listIterator_ffffffff942d51ab,
        mid_offer_000000007b2e38e9,
        mid_offerFirst_000000007b2e38e9,
        mid_offerLast_000000007b2e38e9,
        mid_peek_ffffffffdcc2e1cc,
        mid_peekFirst_ffffffffdcc2e1cc,
        mid_peekLast_ffffffffdcc2e1cc,
        mid_poll_ffffffffdcc2e1cc,
        mid_pollFirst_ffffffffdcc2e1cc,
        mid_pollLast_ffffffffdcc2e1cc,
        mid_pop_ffffffffdcc2e1cc,
        mid_push_ffffffff9530faa9,
        mid_remove_ffffffffdcc2e1cc,
        mid_remove_000000007b2e38e9,
        mid_remove_ffffffff9d560ea6,
        mid_removeFirst_ffffffffdcc2e1cc,
        mid_removeFirstOccurrence_000000007b2e38e9,
        mid_removeLast_ffffffffdcc2e1cc,
        mid_removeLastOccurrence_000000007b2e38e9,
        mid_set_ffffffff8855d074,
        mid_size_000000002043cb81,
        mid_spliterator_ffffffffd8ac147a,
        mid_toArray_000000000a31633c,
        mid_toArray_ffffffff8c6e9dd5,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit LinkedList(jobject obj) : ::java::util::AbstractSequentialList(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      LinkedList(const LinkedList& obj) : ::java::util::AbstractSequentialList(obj) {}

      LinkedList();
      LinkedList(const ::java::util::Collection &);

      jboolean add(const ::java::lang::Object &) const;
      void add(jint, const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      jboolean addAll(jint, const ::java::util::Collection &) const;
      void addFirst(const ::java::lang::Object &) const;
      void addLast(const ::java::lang::Object &) const;
      void clear() const;
      ::java::lang::Object clone() const;
      jboolean contains(const ::java::lang::Object &) const;
      ::java::util::Iterator descendingIterator() const;
      ::java::lang::Object element() const;
      ::java::lang::Object get(jint) const;
      ::java::lang::Object getFirst() const;
      ::java::lang::Object getLast() const;
      jint indexOf(const ::java::lang::Object &) const;
      jint lastIndexOf(const ::java::lang::Object &) const;
      ::java::util::ListIterator listIterator(jint) const;
      jboolean offer(const ::java::lang::Object &) const;
      jboolean offerFirst(const ::java::lang::Object &) const;
      jboolean offerLast(const ::java::lang::Object &) const;
      ::java::lang::Object peek() const;
      ::java::lang::Object peekFirst() const;
      ::java::lang::Object peekLast() const;
      ::java::lang::Object poll() const;
      ::java::lang::Object pollFirst() const;
      ::java::lang::Object pollLast() const;
      ::java::lang::Object pop() const;
      void push(const ::java::lang::Object &) const;
      ::java::lang::Object remove() const;
      jboolean remove(const ::java::lang::Object &) const;
      ::java::lang::Object remove(jint) const;
      ::java::lang::Object removeFirst() const;
      jboolean removeFirstOccurrence(const ::java::lang::Object &) const;
      ::java::lang::Object removeLast() const;
      jboolean removeLastOccurrence(const ::java::lang::Object &) const;
      ::java::lang::Object set(jint, const ::java::lang::Object &) const;
      jint size() const;
      ::java::util::Spliterator spliterator() const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(LinkedList);
    _dll_lucene extern PyTypeObject *PY_TYPE(LinkedList);

    class _dll_lucene t_LinkedList {
    public:
      PyObject_HEAD
      LinkedList object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_LinkedList *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const LinkedList&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const LinkedList&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
