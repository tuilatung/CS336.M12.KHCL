#ifndef java_util_Calendar_H
#define java_util_Calendar_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Date;
    class Calendar;
    class Locale;
    class Map;
    class TimeZone;
    class Set;
  }
  namespace lang {
    class Class;
    class Cloneable;
    class Comparable;
    class Integer;
    class String;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Calendar : public ::java::lang::Object {
     public:
      enum {
        mid_add_fffffffffa24a7fc,
        mid_after_000000007b2e38e9,
        mid_before_000000007b2e38e9,
        mid_clear_ffffffffde902c42,
        mid_clear_ffffffffa0b31ff5,
        mid_clone_ffffffffdcc2e1cc,
        mid_compareTo_000000006efe9c09,
        mid_equals_000000007b2e38e9,
        mid_get_000000007930bd1c,
        mid_getActualMaximum_000000007930bd1c,
        mid_getActualMinimum_000000007930bd1c,
        mid_getAvailableCalendarTypes_000000007600271d,
        mid_getAvailableLocales_0000000003b4de94,
        mid_getCalendarType_000000001d4fc793,
        mid_getDisplayName_ffffffffa87ce22d,
        mid_getDisplayNames_ffffffffe789356d,
        mid_getFirstDayOfWeek_000000002043cb81,
        mid_getGreatestMinimum_000000007930bd1c,
        mid_getInstance_ffffffff9d06bdb3,
        mid_getInstance_ffffffff9ef543cd,
        mid_getInstance_000000003e65a1a9,
        mid_getInstance_fffffffff3957ab4,
        mid_getLeastMaximum_000000007930bd1c,
        mid_getMaximum_000000007930bd1c,
        mid_getMinimalDaysInFirstWeek_000000002043cb81,
        mid_getMinimum_000000007930bd1c,
        mid_getTime_000000007d22f21a,
        mid_getTimeInMillis_ffffffffb4c92ea6,
        mid_getTimeZone_ffffffffe7c9416c,
        mid_getWeekYear_000000002043cb81,
        mid_getWeeksInWeekYear_000000002043cb81,
        mid_hashCode_000000002043cb81,
        mid_isLenient_0000000000c0c182,
        mid_isSet_0000000052d4339a,
        mid_isWeekDateSupported_0000000000c0c182,
        mid_roll_fffffffffa24a7fc,
        mid_roll_ffffffffa5f48b8f,
        mid_set_fffffffffa24a7fc,
        mid_set_ffffffffbe01904f,
        mid_set_00000000322432d9,
        mid_set_ffffffffd0770f0a,
        mid_setFirstDayOfWeek_ffffffffa0b31ff5,
        mid_setLenient_ffffffffd7cfea8c,
        mid_setMinimalDaysInFirstWeek_ffffffffa0b31ff5,
        mid_setTime_ffffffff97836a5b,
        mid_setTimeInMillis_ffffffff985e9c5c,
        mid_setTimeZone_ffffffffb7edc0e7,
        mid_setWeekDate_ffffffffbe01904f,
        mid_toString_000000001d4fc793,
        mid_computeFields_ffffffffde902c42,
        mid_computeTime_ffffffffde902c42,
        mid_internalGet_000000007930bd1c,
        mid_complete_ffffffffde902c42,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Calendar(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Calendar(const Calendar& obj) : ::java::lang::Object(obj) {}

      static jint ALL_STYLES;
      static jint AM;
      static jint AM_PM;
      static jint APRIL;
      static jint AUGUST;
      static jint DATE;
      static jint DAY_OF_MONTH;
      static jint DAY_OF_WEEK;
      static jint DAY_OF_WEEK_IN_MONTH;
      static jint DAY_OF_YEAR;
      static jint DECEMBER;
      static jint DST_OFFSET;
      static jint ERA;
      static jint FEBRUARY;
      static jint FIELD_COUNT;
      static jint FRIDAY;
      static jint HOUR;
      static jint HOUR_OF_DAY;
      static jint JANUARY;
      static jint JULY;
      static jint JUNE;
      static jint LONG;
      static jint LONG_FORMAT;
      static jint LONG_STANDALONE;
      static jint MARCH;
      static jint MAY;
      static jint MILLISECOND;
      static jint MINUTE;
      static jint MONDAY;
      static jint MONTH;
      static jint NARROW_FORMAT;
      static jint NARROW_STANDALONE;
      static jint NOVEMBER;
      static jint OCTOBER;
      static jint PM;
      static jint SATURDAY;
      static jint SECOND;
      static jint SEPTEMBER;
      static jint SHORT;
      static jint SHORT_FORMAT;
      static jint SHORT_STANDALONE;
      static jint SUNDAY;
      static jint THURSDAY;
      static jint TUESDAY;
      static jint UNDECIMBER;
      static jint WEDNESDAY;
      static jint WEEK_OF_MONTH;
      static jint WEEK_OF_YEAR;
      static jint YEAR;
      static jint ZONE_OFFSET;

      void add(jint, jint) const;
      jboolean after(const ::java::lang::Object &) const;
      jboolean before(const ::java::lang::Object &) const;
      void clear() const;
      void clear(jint) const;
      ::java::lang::Object clone() const;
      jint compareTo(const Calendar &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jint get(jint) const;
      jint getActualMaximum(jint) const;
      jint getActualMinimum(jint) const;
      static ::java::util::Set getAvailableCalendarTypes();
      static JArray< ::java::util::Locale > getAvailableLocales();
      ::java::lang::String getCalendarType() const;
      ::java::lang::String getDisplayName(jint, jint, const ::java::util::Locale &) const;
      ::java::util::Map getDisplayNames(jint, jint, const ::java::util::Locale &) const;
      jint getFirstDayOfWeek() const;
      jint getGreatestMinimum(jint) const;
      static Calendar getInstance();
      static Calendar getInstance(const ::java::util::TimeZone &);
      static Calendar getInstance(const ::java::util::Locale &);
      static Calendar getInstance(const ::java::util::TimeZone &, const ::java::util::Locale &);
      jint getLeastMaximum(jint) const;
      jint getMaximum(jint) const;
      jint getMinimalDaysInFirstWeek() const;
      jint getMinimum(jint) const;
      ::java::util::Date getTime() const;
      jlong getTimeInMillis() const;
      ::java::util::TimeZone getTimeZone() const;
      jint getWeekYear() const;
      jint getWeeksInWeekYear() const;
      jint hashCode() const;
      jboolean isLenient() const;
      jboolean isSet(jint) const;
      jboolean isWeekDateSupported() const;
      void roll(jint, jint) const;
      void roll(jint, jboolean) const;
      void set(jint, jint) const;
      void set(jint, jint, jint) const;
      void set(jint, jint, jint, jint, jint) const;
      void set(jint, jint, jint, jint, jint, jint) const;
      void setFirstDayOfWeek(jint) const;
      void setLenient(jboolean) const;
      void setMinimalDaysInFirstWeek(jint) const;
      void setTime(const ::java::util::Date &) const;
      void setTimeInMillis(jlong) const;
      void setTimeZone(const ::java::util::TimeZone &) const;
      void setWeekDate(jint, jint, jint) const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Calendar);
    _dll_lucene extern PyTypeObject *PY_TYPE(Calendar);

    class _dll_lucene t_Calendar {
    public:
      PyObject_HEAD
      Calendar object;
      static PyObject *wrap_Object(const Calendar&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
