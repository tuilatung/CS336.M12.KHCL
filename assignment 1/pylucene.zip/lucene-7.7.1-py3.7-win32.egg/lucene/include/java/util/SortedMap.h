#ifndef java_util_SortedMap_H
#define java_util_SortedMap_H

#include "java/util/Map.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
  }
  namespace util {
    class SortedMap;
    class Collection;
    class Map$Entry;
    class Set;
    class Comparator;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene SortedMap : public ::java::util::Map {
     public:
      enum {
        mid_comparator_ffffffff83924d7b,
        mid_entrySet_000000007600271d,
        mid_firstKey_ffffffffdcc2e1cc,
        mid_headMap_ffffffffaa7aa2b8,
        mid_keySet_000000007600271d,
        mid_lastKey_ffffffffdcc2e1cc,
        mid_subMap_ffffffffb0367bf9,
        mid_tailMap_ffffffffaa7aa2b8,
        mid_values_ffffffffd29dc48e,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SortedMap(jobject obj) : ::java::util::Map(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SortedMap(const SortedMap& obj) : ::java::util::Map(obj) {}

      ::java::util::Comparator comparator() const;
      ::java::util::Set entrySet() const;
      ::java::lang::Object firstKey() const;
      SortedMap headMap(const ::java::lang::Object &) const;
      ::java::util::Set keySet() const;
      ::java::lang::Object lastKey() const;
      SortedMap subMap(const ::java::lang::Object &, const ::java::lang::Object &) const;
      SortedMap tailMap(const ::java::lang::Object &) const;
      ::java::util::Collection values() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(SortedMap);
    _dll_lucene extern PyTypeObject *PY_TYPE(SortedMap);

    class _dll_lucene t_SortedMap {
    public:
      PyObject_HEAD
      SortedMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_SortedMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const SortedMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const SortedMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
