#ifndef java_util_Deque_H
#define java_util_Deque_H

#include "java/util/Queue.h"

namespace java {
  namespace util {
    class Iterator;
  }
  namespace lang {
    class Object;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Deque : public ::java::util::Queue {
     public:
      enum {
        mid_add_000000007b2e38e9,
        mid_addFirst_ffffffff9530faa9,
        mid_addLast_ffffffff9530faa9,
        mid_contains_000000007b2e38e9,
        mid_descendingIterator_ffffffffafc8ac37,
        mid_element_ffffffffdcc2e1cc,
        mid_getFirst_ffffffffdcc2e1cc,
        mid_getLast_ffffffffdcc2e1cc,
        mid_iterator_ffffffffafc8ac37,
        mid_offer_000000007b2e38e9,
        mid_offerFirst_000000007b2e38e9,
        mid_offerLast_000000007b2e38e9,
        mid_peek_ffffffffdcc2e1cc,
        mid_peekFirst_ffffffffdcc2e1cc,
        mid_peekLast_ffffffffdcc2e1cc,
        mid_poll_ffffffffdcc2e1cc,
        mid_pollFirst_ffffffffdcc2e1cc,
        mid_pollLast_ffffffffdcc2e1cc,
        mid_pop_ffffffffdcc2e1cc,
        mid_push_ffffffff9530faa9,
        mid_remove_ffffffffdcc2e1cc,
        mid_remove_000000007b2e38e9,
        mid_removeFirst_ffffffffdcc2e1cc,
        mid_removeFirstOccurrence_000000007b2e38e9,
        mid_removeLast_ffffffffdcc2e1cc,
        mid_removeLastOccurrence_000000007b2e38e9,
        mid_size_000000002043cb81,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Deque(jobject obj) : ::java::util::Queue(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Deque(const Deque& obj) : ::java::util::Queue(obj) {}

      jboolean add(const ::java::lang::Object &) const;
      void addFirst(const ::java::lang::Object &) const;
      void addLast(const ::java::lang::Object &) const;
      jboolean contains(const ::java::lang::Object &) const;
      ::java::util::Iterator descendingIterator() const;
      ::java::lang::Object element() const;
      ::java::lang::Object getFirst() const;
      ::java::lang::Object getLast() const;
      ::java::util::Iterator iterator() const;
      jboolean offer(const ::java::lang::Object &) const;
      jboolean offerFirst(const ::java::lang::Object &) const;
      jboolean offerLast(const ::java::lang::Object &) const;
      ::java::lang::Object peek() const;
      ::java::lang::Object peekFirst() const;
      ::java::lang::Object peekLast() const;
      ::java::lang::Object poll() const;
      ::java::lang::Object pollFirst() const;
      ::java::lang::Object pollLast() const;
      ::java::lang::Object pop() const;
      void push(const ::java::lang::Object &) const;
      ::java::lang::Object remove() const;
      jboolean remove(const ::java::lang::Object &) const;
      ::java::lang::Object removeFirst() const;
      jboolean removeFirstOccurrence(const ::java::lang::Object &) const;
      ::java::lang::Object removeLast() const;
      jboolean removeLastOccurrence(const ::java::lang::Object &) const;
      jint size() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Deque);
    _dll_lucene extern PyTypeObject *PY_TYPE(Deque);

    class _dll_lucene t_Deque {
    public:
      PyObject_HEAD
      Deque object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_Deque *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Deque&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Deque&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
