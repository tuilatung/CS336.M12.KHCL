#ifndef java_util_regex_Matcher_H
#define java_util_regex_Matcher_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class CharSequence;
    class String;
  }
  namespace util {
    namespace regex {
      class MatchResult;
      class Pattern;
      class Matcher;
    }
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace regex {

      class _dll_lucene Matcher : public ::java::lang::Object {
       public:
        enum {
          mid_appendReplacement_000000002411628d,
          mid_appendTail_ffffffffee56684d,
          mid_end_000000002043cb81,
          mid_end_000000007930bd1c,
          mid_end_0000000026f4dfbe,
          mid_find_0000000000c0c182,
          mid_find_0000000052d4339a,
          mid_group_000000001d4fc793,
          mid_group_ffffffffbf6eae52,
          mid_group_0000000026c48400,
          mid_groupCount_000000002043cb81,
          mid_hasAnchoringBounds_0000000000c0c182,
          mid_hasTransparentBounds_0000000000c0c182,
          mid_hitEnd_0000000000c0c182,
          mid_lookingAt_0000000000c0c182,
          mid_matches_0000000000c0c182,
          mid_pattern_000000006c4d54d0,
          mid_quoteReplacement_ffffffffbf6eae52,
          mid_region_000000006d9f4032,
          mid_regionEnd_000000002043cb81,
          mid_regionStart_000000002043cb81,
          mid_replaceAll_ffffffffbf6eae52,
          mid_replaceFirst_ffffffffbf6eae52,
          mid_requireEnd_0000000000c0c182,
          mid_reset_ffffffffe0019f59,
          mid_reset_ffffffffd9e761b8,
          mid_start_000000002043cb81,
          mid_start_0000000026f4dfbe,
          mid_start_000000007930bd1c,
          mid_toMatchResult_000000003d7d607c,
          mid_toString_000000001d4fc793,
          mid_useAnchoringBounds_ffffffffa003eb20,
          mid_usePattern_0000000034e17b0f,
          mid_useTransparentBounds_ffffffffa003eb20,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Matcher(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Matcher(const Matcher& obj) : ::java::lang::Object(obj) {}

        Matcher appendReplacement(const ::java::lang::StringBuffer &, const ::java::lang::String &) const;
        ::java::lang::StringBuffer appendTail(const ::java::lang::StringBuffer &) const;
        jint end() const;
        jint end(jint) const;
        jint end(const ::java::lang::String &) const;
        jboolean find() const;
        jboolean find(jint) const;
        ::java::lang::String group() const;
        ::java::lang::String group(const ::java::lang::String &) const;
        ::java::lang::String group(jint) const;
        jint groupCount() const;
        jboolean hasAnchoringBounds() const;
        jboolean hasTransparentBounds() const;
        jboolean hitEnd() const;
        jboolean lookingAt() const;
        jboolean matches() const;
        ::java::util::regex::Pattern pattern() const;
        static ::java::lang::String quoteReplacement(const ::java::lang::String &);
        Matcher region(jint, jint) const;
        jint regionEnd() const;
        jint regionStart() const;
        ::java::lang::String replaceAll(const ::java::lang::String &) const;
        ::java::lang::String replaceFirst(const ::java::lang::String &) const;
        jboolean requireEnd() const;
        Matcher reset() const;
        Matcher reset(const ::java::lang::CharSequence &) const;
        jint start() const;
        jint start(const ::java::lang::String &) const;
        jint start(jint) const;
        ::java::util::regex::MatchResult toMatchResult() const;
        ::java::lang::String toString() const;
        Matcher useAnchoringBounds(jboolean) const;
        Matcher usePattern(const ::java::util::regex::Pattern &) const;
        Matcher useTransparentBounds(jboolean) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace regex {
      _dll_lucene extern PyType_Def PY_TYPE_DEF(Matcher);
      _dll_lucene extern PyTypeObject *PY_TYPE(Matcher);

      class _dll_lucene t_Matcher {
      public:
        PyObject_HEAD
        Matcher object;
        static PyObject *wrap_Object(const Matcher&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
