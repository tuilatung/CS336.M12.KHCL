#ifndef java_util_HashSet_H
#define java_util_HashSet_H

#include "java/util/AbstractSet.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class Cloneable;
  }
  namespace util {
    class Spliterator;
    class Iterator;
    class Collection;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene HashSet : public ::java::util::AbstractSet {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffa0b31ff5,
        mid_init$_000000000f1531cc,
        mid_init$_ffffffffcf84b542,
        mid_add_000000007b2e38e9,
        mid_clear_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        mid_contains_000000007b2e38e9,
        mid_isEmpty_0000000000c0c182,
        mid_iterator_ffffffffafc8ac37,
        mid_remove_000000007b2e38e9,
        mid_size_000000002043cb81,
        mid_spliterator_ffffffffd8ac147a,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit HashSet(jobject obj) : ::java::util::AbstractSet(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      HashSet(const HashSet& obj) : ::java::util::AbstractSet(obj) {}

      HashSet();
      HashSet(jint);
      HashSet(const ::java::util::Collection &);
      HashSet(jint, jfloat);

      jboolean add(const ::java::lang::Object &) const;
      void clear() const;
      ::java::lang::Object clone() const;
      jboolean contains(const ::java::lang::Object &) const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      jboolean remove(const ::java::lang::Object &) const;
      jint size() const;
      ::java::util::Spliterator spliterator() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(HashSet);
    _dll_lucene extern PyTypeObject *PY_TYPE(HashSet);

    class _dll_lucene t_HashSet {
    public:
      PyObject_HEAD
      HashSet object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_HashSet *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const HashSet&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const HashSet&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
