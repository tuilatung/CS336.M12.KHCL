#ifndef java_util_Random_H
#define java_util_Random_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class Serializable;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Random : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffff985e9c5c,
        mid_nextBoolean_0000000000c0c182,
        mid_nextBytes_0000000038c78f53,
        mid_nextDouble_0000000046402c15,
        mid_nextFloat_ffffffffee5e3be1,
        mid_nextGaussian_0000000046402c15,
        mid_nextInt_000000002043cb81,
        mid_nextInt_000000007930bd1c,
        mid_nextLong_ffffffffb4c92ea6,
        mid_setSeed_ffffffff985e9c5c,
        mid_next_000000007930bd1c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Random(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Random(const Random& obj) : ::java::lang::Object(obj) {}

      Random();
      Random(jlong);

      jboolean nextBoolean() const;
      void nextBytes(const JArray< jbyte > &) const;
      jdouble nextDouble() const;
      jfloat nextFloat() const;
      jdouble nextGaussian() const;
      jint nextInt() const;
      jint nextInt(jint) const;
      jlong nextLong() const;
      void setSeed(jlong) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Random);
    _dll_lucene extern PyTypeObject *PY_TYPE(Random);

    class _dll_lucene t_Random {
    public:
      PyObject_HEAD
      Random object;
      static PyObject *wrap_Object(const Random&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
