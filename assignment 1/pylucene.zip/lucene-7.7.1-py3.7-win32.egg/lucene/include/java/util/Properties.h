#ifndef java_util_Properties_H
#define java_util_Properties_H

#include "java/util/Hashtable.h"

namespace java {
  namespace io {
    class PrintWriter;
    class OutputStream;
    class Reader;
    class InputStream;
    class Writer;
    class PrintStream;
    class IOException;
  }
  namespace lang {
    class Class;
    class Object;
    class String;
  }
  namespace util {
    class InvalidPropertiesFormatException;
    class Enumeration;
    class Set;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Properties : public ::java::util::Hashtable {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_getProperty_ffffffffbf6eae52,
        mid_getProperty_ffffffffe73080ee,
        mid_list_0000000065dd8cbc,
        mid_list_000000005702bab7,
        mid_load_ffffffffac14d142,
        mid_load_ffffffffbb1e543a,
        mid_loadFromXML_ffffffffbb1e543a,
        mid_propertyNames_000000003fb08ac2,
        mid_save_0000000065836ccd,
        mid_setProperty_0000000012aeed73,
        mid_store_ffffffffdd7e2c95,
        mid_store_0000000065836ccd,
        mid_storeToXML_0000000065836ccd,
        mid_storeToXML_000000002b23d1d1,
        mid_stringPropertyNames_000000007600271d,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Properties(jobject obj) : ::java::util::Hashtable(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Properties(const Properties& obj) : ::java::util::Hashtable(obj) {}

      Properties();

      ::java::lang::String getProperty(const ::java::lang::String &) const;
      ::java::lang::String getProperty(const ::java::lang::String &, const ::java::lang::String &) const;
      void list(const ::java::io::PrintStream &) const;
      void list(const ::java::io::PrintWriter &) const;
      void load(const ::java::io::Reader &) const;
      void load(const ::java::io::InputStream &) const;
      void loadFromXML(const ::java::io::InputStream &) const;
      ::java::util::Enumeration propertyNames() const;
      void save(const ::java::io::OutputStream &, const ::java::lang::String &) const;
      ::java::lang::Object setProperty(const ::java::lang::String &, const ::java::lang::String &) const;
      void store(const ::java::io::Writer &, const ::java::lang::String &) const;
      void store(const ::java::io::OutputStream &, const ::java::lang::String &) const;
      void storeToXML(const ::java::io::OutputStream &, const ::java::lang::String &) const;
      void storeToXML(const ::java::io::OutputStream &, const ::java::lang::String &, const ::java::lang::String &) const;
      ::java::util::Set stringPropertyNames() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Properties);
    _dll_lucene extern PyTypeObject *PY_TYPE(Properties);

    class _dll_lucene t_Properties {
    public:
      PyObject_HEAD
      Properties object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_Properties *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Properties&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Properties&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
