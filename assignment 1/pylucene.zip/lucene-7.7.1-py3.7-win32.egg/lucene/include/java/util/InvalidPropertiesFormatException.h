#ifndef java_util_InvalidPropertiesFormatException_H
#define java_util_InvalidPropertiesFormatException_H

#include "java/io/IOException.h"

namespace java {
  namespace lang {
    class String;
    class Throwable;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene InvalidPropertiesFormatException : public ::java::io::IOException {
     public:
      enum {
        mid_init$_0000000011312d29,
        mid_init$_0000000048822f5e,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit InvalidPropertiesFormatException(jobject obj) : ::java::io::IOException(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      InvalidPropertiesFormatException(const InvalidPropertiesFormatException& obj) : ::java::io::IOException(obj) {}

      InvalidPropertiesFormatException(const ::java::lang::Throwable &);
      InvalidPropertiesFormatException(const ::java::lang::String &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(InvalidPropertiesFormatException);
    _dll_lucene extern PyTypeObject *PY_TYPE(InvalidPropertiesFormatException);

    class _dll_lucene t_InvalidPropertiesFormatException {
    public:
      PyObject_HEAD
      InvalidPropertiesFormatException object;
      static PyObject *wrap_Object(const InvalidPropertiesFormatException&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
