#ifndef java_util_LinkedHashMap_H
#define java_util_LinkedHashMap_H

#include "java/util/HashMap.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
  }
  namespace util {
    class Map;
    class Collection;
    class Map$Entry;
    class Set;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene LinkedHashMap : public ::java::util::HashMap {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffd3ad6b94,
        mid_init$_ffffffffa0b31ff5,
        mid_init$_ffffffffcf84b542,
        mid_init$_ffffffffed41a794,
        mid_clear_ffffffffde902c42,
        mid_containsValue_000000007b2e38e9,
        mid_entrySet_000000007600271d,
        mid_get_ffffffff8bf08471,
        mid_getOrDefault_ffffffffd29d9423,
        mid_keySet_000000007600271d,
        mid_values_ffffffffd29dc48e,
        mid_removeEldestEntry_000000007bf7eee7,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit LinkedHashMap(jobject obj) : ::java::util::HashMap(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      LinkedHashMap(const LinkedHashMap& obj) : ::java::util::HashMap(obj) {}

      LinkedHashMap();
      LinkedHashMap(const ::java::util::Map &);
      LinkedHashMap(jint);
      LinkedHashMap(jint, jfloat);
      LinkedHashMap(jint, jfloat, jboolean);

      void clear() const;
      jboolean containsValue(const ::java::lang::Object &) const;
      ::java::util::Set entrySet() const;
      ::java::lang::Object get(const ::java::lang::Object &) const;
      ::java::lang::Object getOrDefault(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::util::Set keySet() const;
      ::java::util::Collection values() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(LinkedHashMap);
    _dll_lucene extern PyTypeObject *PY_TYPE(LinkedHashMap);

    class _dll_lucene t_LinkedHashMap {
    public:
      PyObject_HEAD
      LinkedHashMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_LinkedHashMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const LinkedHashMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const LinkedHashMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
