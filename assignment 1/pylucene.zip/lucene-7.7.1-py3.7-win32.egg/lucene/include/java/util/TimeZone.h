#ifndef java_util_TimeZone_H
#define java_util_TimeZone_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Date;
    class Locale;
    class TimeZone;
  }
  namespace lang {
    class Class;
    class Cloneable;
    class String;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene TimeZone : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        mid_getAvailableIDs_ffffffffbcb33d67,
        mid_getAvailableIDs_ffffffffd194e7b8,
        mid_getDSTSavings_000000002043cb81,
        mid_getDefault_ffffffffe7c9416c,
        mid_getDisplayName_000000001d4fc793,
        mid_getDisplayName_000000003408a0c5,
        mid_getDisplayName_ffffffff9c2dfb25,
        mid_getDisplayName_ffffffffb4758f91,
        mid_getID_000000001d4fc793,
        mid_getOffset_0000000051dc7901,
        mid_getOffset_ffffffff8f83a7fa,
        mid_getRawOffset_000000002043cb81,
        mid_getTimeZone_000000007da3cb28,
        mid_hasSameRules_ffffffffaae90214,
        mid_inDaylightTime_ffffffffc01205ab,
        mid_observesDaylightTime_0000000000c0c182,
        mid_setDefault_ffffffffb7edc0e7,
        mid_setID_0000000048822f5e,
        mid_setRawOffset_ffffffffa0b31ff5,
        mid_useDaylightTime_0000000000c0c182,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit TimeZone(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      TimeZone(const TimeZone& obj) : ::java::lang::Object(obj) {}

      static jint LONG;
      static jint SHORT;

      TimeZone();

      ::java::lang::Object clone() const;
      static JArray< ::java::lang::String > getAvailableIDs();
      static JArray< ::java::lang::String > getAvailableIDs(jint);
      jint getDSTSavings() const;
      static TimeZone getDefault();
      ::java::lang::String getDisplayName() const;
      ::java::lang::String getDisplayName(const ::java::util::Locale &) const;
      ::java::lang::String getDisplayName(jboolean, jint) const;
      ::java::lang::String getDisplayName(jboolean, jint, const ::java::util::Locale &) const;
      ::java::lang::String getID() const;
      jint getOffset(jlong) const;
      jint getOffset(jint, jint, jint, jint, jint, jint) const;
      jint getRawOffset() const;
      static TimeZone getTimeZone(const ::java::lang::String &);
      jboolean hasSameRules(const TimeZone &) const;
      jboolean inDaylightTime(const ::java::util::Date &) const;
      jboolean observesDaylightTime() const;
      static void setDefault(const TimeZone &);
      void setID(const ::java::lang::String &) const;
      void setRawOffset(jint) const;
      jboolean useDaylightTime() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(TimeZone);
    _dll_lucene extern PyTypeObject *PY_TYPE(TimeZone);

    class _dll_lucene t_TimeZone {
    public:
      PyObject_HEAD
      TimeZone object;
      static PyObject *wrap_Object(const TimeZone&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
