#ifndef java_util_Hashtable_H
#define java_util_Hashtable_H

#include "java/util/Dictionary.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
    class Cloneable;
    class String;
  }
  namespace util {
    class Enumeration;
    class Map;
    class Collection;
    class Map$Entry;
    class Set;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Hashtable : public ::java::util::Dictionary {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffd3ad6b94,
        mid_init$_ffffffffa0b31ff5,
        mid_init$_ffffffffcf84b542,
        mid_clear_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        mid_contains_000000007b2e38e9,
        mid_containsKey_000000007b2e38e9,
        mid_containsValue_000000007b2e38e9,
        mid_elements_000000003fb08ac2,
        mid_entrySet_000000007600271d,
        mid_equals_000000007b2e38e9,
        mid_get_ffffffff8bf08471,
        mid_getOrDefault_ffffffffd29d9423,
        mid_hashCode_000000002043cb81,
        mid_isEmpty_0000000000c0c182,
        mid_keySet_000000007600271d,
        mid_keys_000000003fb08ac2,
        mid_put_ffffffffd29d9423,
        mid_putAll_ffffffffd3ad6b94,
        mid_putIfAbsent_ffffffffd29d9423,
        mid_remove_ffffffff8bf08471,
        mid_remove_000000000ebdd636,
        mid_replace_ffffffffd29d9423,
        mid_replace_ffffffffa4870c1b,
        mid_size_000000002043cb81,
        mid_toString_000000001d4fc793,
        mid_values_ffffffffd29dc48e,
        mid_rehash_ffffffffde902c42,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Hashtable(jobject obj) : ::java::util::Dictionary(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Hashtable(const Hashtable& obj) : ::java::util::Dictionary(obj) {}

      Hashtable();
      Hashtable(const ::java::util::Map &);
      Hashtable(jint);
      Hashtable(jint, jfloat);

      void clear() const;
      ::java::lang::Object clone() const;
      jboolean contains(const ::java::lang::Object &) const;
      jboolean containsKey(const ::java::lang::Object &) const;
      jboolean containsValue(const ::java::lang::Object &) const;
      ::java::util::Enumeration elements() const;
      ::java::util::Set entrySet() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::lang::Object get(const ::java::lang::Object &) const;
      ::java::lang::Object getOrDefault(const ::java::lang::Object &, const ::java::lang::Object &) const;
      jint hashCode() const;
      jboolean isEmpty() const;
      ::java::util::Set keySet() const;
      ::java::util::Enumeration keys() const;
      ::java::lang::Object put(const ::java::lang::Object &, const ::java::lang::Object &) const;
      void putAll(const ::java::util::Map &) const;
      ::java::lang::Object putIfAbsent(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object remove(const ::java::lang::Object &) const;
      jboolean remove(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object replace(const ::java::lang::Object &, const ::java::lang::Object &) const;
      jboolean replace(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &) const;
      jint size() const;
      ::java::lang::String toString() const;
      ::java::util::Collection values() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Hashtable);
    _dll_lucene extern PyTypeObject *PY_TYPE(Hashtable);

    class _dll_lucene t_Hashtable {
    public:
      PyObject_HEAD
      Hashtable object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_Hashtable *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Hashtable&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Hashtable&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
