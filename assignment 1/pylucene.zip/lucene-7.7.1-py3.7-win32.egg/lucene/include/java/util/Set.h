#ifndef java_util_Set_H
#define java_util_Set_H

#include "java/util/Collection.h"

namespace java {
  namespace lang {
    class Class;
    class Object;
  }
  namespace util {
    class Spliterator;
    class Iterator;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Set : public ::java::util::Collection {
     public:
      enum {
        mid_add_000000007b2e38e9,
        mid_addAll_00000000178b4ca7,
        mid_clear_ffffffffde902c42,
        mid_contains_000000007b2e38e9,
        mid_containsAll_00000000178b4ca7,
        mid_equals_000000007b2e38e9,
        mid_hashCode_000000002043cb81,
        mid_isEmpty_0000000000c0c182,
        mid_iterator_ffffffffafc8ac37,
        mid_remove_000000007b2e38e9,
        mid_removeAll_00000000178b4ca7,
        mid_retainAll_00000000178b4ca7,
        mid_size_000000002043cb81,
        mid_spliterator_ffffffffd8ac147a,
        mid_toArray_000000000a31633c,
        mid_toArray_ffffffff8c6e9dd5,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Set(jobject obj) : ::java::util::Collection(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Set(const Set& obj) : ::java::util::Collection(obj) {}

      jboolean add(const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      void clear() const;
      jboolean contains(const ::java::lang::Object &) const;
      jboolean containsAll(const ::java::util::Collection &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jint hashCode() const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      jboolean remove(const ::java::lang::Object &) const;
      jboolean removeAll(const ::java::util::Collection &) const;
      jboolean retainAll(const ::java::util::Collection &) const;
      jint size() const;
      ::java::util::Spliterator spliterator() const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Set);
    _dll_lucene extern PyTypeObject *PY_TYPE(Set);

    class _dll_lucene t_Set {
    public:
      PyObject_HEAD
      Set object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_Set *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Set&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Set&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
