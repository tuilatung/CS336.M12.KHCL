#ifndef java_util_Date_H
#define java_util_Date_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Date;
  }
  namespace lang {
    class Class;
    class Cloneable;
    class Comparable;
    class String;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene Date : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_0000000048822f5e,
        mid_init$_ffffffff985e9c5c,
        mid_init$_ffffffffbe01904f,
        mid_init$_00000000322432d9,
        mid_init$_ffffffffd0770f0a,
        mid_UTC_ffffffffcbc819b3,
        mid_after_ffffffffc01205ab,
        mid_before_ffffffffc01205ab,
        mid_clone_ffffffffdcc2e1cc,
        mid_compareTo_ffffffffbd544771,
        mid_equals_000000007b2e38e9,
        mid_getDate_000000002043cb81,
        mid_getDay_000000002043cb81,
        mid_getHours_000000002043cb81,
        mid_getMinutes_000000002043cb81,
        mid_getMonth_000000002043cb81,
        mid_getSeconds_000000002043cb81,
        mid_getTime_ffffffffb4c92ea6,
        mid_getTimezoneOffset_000000002043cb81,
        mid_getYear_000000002043cb81,
        mid_hashCode_000000002043cb81,
        mid_parse_ffffffff8bdd7b1d,
        mid_setDate_ffffffffa0b31ff5,
        mid_setHours_ffffffffa0b31ff5,
        mid_setMinutes_ffffffffa0b31ff5,
        mid_setMonth_ffffffffa0b31ff5,
        mid_setSeconds_ffffffffa0b31ff5,
        mid_setTime_ffffffff985e9c5c,
        mid_setYear_ffffffffa0b31ff5,
        mid_toGMTString_000000001d4fc793,
        mid_toLocaleString_000000001d4fc793,
        mid_toString_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Date(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Date(const Date& obj) : ::java::lang::Object(obj) {}

      Date();
      Date(const ::java::lang::String &);
      Date(jlong);
      Date(jint, jint, jint);
      Date(jint, jint, jint, jint, jint);
      Date(jint, jint, jint, jint, jint, jint);

      static jlong UTC(jint, jint, jint, jint, jint, jint);
      jboolean after(const Date &) const;
      jboolean before(const Date &) const;
      ::java::lang::Object clone() const;
      jint compareTo(const Date &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jint getDate() const;
      jint getDay() const;
      jint getHours() const;
      jint getMinutes() const;
      jint getMonth() const;
      jint getSeconds() const;
      jlong getTime() const;
      jint getTimezoneOffset() const;
      jint getYear() const;
      jint hashCode() const;
      static jlong parse(const ::java::lang::String &);
      void setDate(jint) const;
      void setHours(jint) const;
      void setMinutes(jint) const;
      void setMonth(jint) const;
      void setSeconds(jint) const;
      void setTime(jlong) const;
      void setYear(jint) const;
      ::java::lang::String toGMTString() const;
      ::java::lang::String toLocaleString() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Date);
    _dll_lucene extern PyTypeObject *PY_TYPE(Date);

    class _dll_lucene t_Date {
    public:
      PyObject_HEAD
      Date object;
      static PyObject *wrap_Object(const Date&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
