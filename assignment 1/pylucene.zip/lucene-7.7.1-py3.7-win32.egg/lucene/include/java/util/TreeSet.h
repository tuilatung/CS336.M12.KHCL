#ifndef java_util_TreeSet_H
#define java_util_TreeSet_H

#include "java/util/AbstractSet.h"

namespace java {
  namespace util {
    class SortedSet;
    class Spliterator;
    class NavigableSet;
    class Iterator;
    class Collection;
    class Comparator;
  }
  namespace lang {
    class Class;
    class Object;
    class Cloneable;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class _dll_lucene TreeSet : public ::java::util::AbstractSet {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_000000005704064b,
        mid_init$_000000000f1531cc,
        mid_init$_0000000071bbcb63,
        mid_add_000000007b2e38e9,
        mid_addAll_00000000178b4ca7,
        mid_ceiling_ffffffff8bf08471,
        mid_clear_ffffffffde902c42,
        mid_clone_ffffffffdcc2e1cc,
        mid_comparator_ffffffff83924d7b,
        mid_contains_000000007b2e38e9,
        mid_descendingIterator_ffffffffafc8ac37,
        mid_descendingSet_ffffffffaa354270,
        mid_first_ffffffffdcc2e1cc,
        mid_floor_ffffffff8bf08471,
        mid_headSet_ffffffffd2b693ed,
        mid_headSet_ffffffffd4e06d2b,
        mid_higher_ffffffff8bf08471,
        mid_isEmpty_0000000000c0c182,
        mid_iterator_ffffffffafc8ac37,
        mid_last_ffffffffdcc2e1cc,
        mid_lower_ffffffff8bf08471,
        mid_pollFirst_ffffffffdcc2e1cc,
        mid_pollLast_ffffffffdcc2e1cc,
        mid_remove_000000007b2e38e9,
        mid_size_000000002043cb81,
        mid_spliterator_ffffffffd8ac147a,
        mid_subSet_000000005aa97597,
        mid_subSet_ffffffff9e58e8aa,
        mid_tailSet_ffffffffd2b693ed,
        mid_tailSet_ffffffffd4e06d2b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit TreeSet(jobject obj) : ::java::util::AbstractSet(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      TreeSet(const TreeSet& obj) : ::java::util::AbstractSet(obj) {}

      TreeSet();
      TreeSet(const ::java::util::SortedSet &);
      TreeSet(const ::java::util::Collection &);
      TreeSet(const ::java::util::Comparator &);

      jboolean add(const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      ::java::lang::Object ceiling(const ::java::lang::Object &) const;
      void clear() const;
      ::java::lang::Object clone() const;
      ::java::util::Comparator comparator() const;
      jboolean contains(const ::java::lang::Object &) const;
      ::java::util::Iterator descendingIterator() const;
      ::java::util::NavigableSet descendingSet() const;
      ::java::lang::Object first() const;
      ::java::lang::Object floor(const ::java::lang::Object &) const;
      ::java::util::SortedSet headSet(const ::java::lang::Object &) const;
      ::java::util::NavigableSet headSet(const ::java::lang::Object &, jboolean) const;
      ::java::lang::Object higher(const ::java::lang::Object &) const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      ::java::lang::Object last() const;
      ::java::lang::Object lower(const ::java::lang::Object &) const;
      ::java::lang::Object pollFirst() const;
      ::java::lang::Object pollLast() const;
      jboolean remove(const ::java::lang::Object &) const;
      jint size() const;
      ::java::util::Spliterator spliterator() const;
      ::java::util::SortedSet subSet(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::util::NavigableSet subSet(const ::java::lang::Object &, jboolean, const ::java::lang::Object &, jboolean) const;
      ::java::util::SortedSet tailSet(const ::java::lang::Object &) const;
      ::java::util::NavigableSet tailSet(const ::java::lang::Object &, jboolean) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(TreeSet);
    _dll_lucene extern PyTypeObject *PY_TYPE(TreeSet);

    class _dll_lucene t_TreeSet {
    public:
      PyObject_HEAD
      TreeSet object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_TreeSet *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const TreeSet&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const TreeSet&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
