#ifndef java_io_BufferedWriter_H
#define java_io_BufferedWriter_H

#include "java/io/Writer.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene BufferedWriter : public ::java::io::Writer {
     public:
      enum {
        mid_init$_ffffffffc4df164a,
        mid_init$_00000000451d69e1,
        mid_close_ffffffffde902c42,
        mid_flush_ffffffffde902c42,
        mid_newLine_ffffffffde902c42,
        mid_write_ffffffffa0b31ff5,
        mid_write_0000000052290416,
        mid_write_000000002c87a49f,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit BufferedWriter(jobject obj) : ::java::io::Writer(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      BufferedWriter(const BufferedWriter& obj) : ::java::io::Writer(obj) {}

      BufferedWriter(const ::java::io::Writer &);
      BufferedWriter(const ::java::io::Writer &, jint);

      void close() const;
      void flush() const;
      void newLine() const;
      void write(jint) const;
      void write(const JArray< jchar > &, jint, jint) const;
      void write(const ::java::lang::String &, jint, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(BufferedWriter);
    _dll_lucene extern PyTypeObject *PY_TYPE(BufferedWriter);

    class _dll_lucene t_BufferedWriter {
    public:
      PyObject_HEAD
      BufferedWriter object;
      static PyObject *wrap_Object(const BufferedWriter&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
