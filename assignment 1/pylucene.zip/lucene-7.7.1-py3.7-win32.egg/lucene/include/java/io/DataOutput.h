#ifndef java_io_DataOutput_H
#define java_io_DataOutput_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene DataOutput : public ::java::lang::Object {
     public:
      enum {
        mid_write_0000000038c78f53,
        mid_write_ffffffffa0b31ff5,
        mid_write_00000000311f6778,
        mid_writeBoolean_ffffffffd7cfea8c,
        mid_writeByte_ffffffffa0b31ff5,
        mid_writeBytes_0000000048822f5e,
        mid_writeChar_ffffffffa0b31ff5,
        mid_writeChars_0000000048822f5e,
        mid_writeDouble_000000003e46d501,
        mid_writeFloat_fffffffffc2a4e56,
        mid_writeInt_ffffffffa0b31ff5,
        mid_writeLong_ffffffff985e9c5c,
        mid_writeShort_ffffffffa0b31ff5,
        mid_writeUTF_0000000048822f5e,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit DataOutput(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      DataOutput(const DataOutput& obj) : ::java::lang::Object(obj) {}

      void write(const JArray< jbyte > &) const;
      void write(jint) const;
      void write(const JArray< jbyte > &, jint, jint) const;
      void writeBoolean(jboolean) const;
      void writeByte(jint) const;
      void writeBytes(const ::java::lang::String &) const;
      void writeChar(jint) const;
      void writeChars(const ::java::lang::String &) const;
      void writeDouble(jdouble) const;
      void writeFloat(jfloat) const;
      void writeInt(jint) const;
      void writeLong(jlong) const;
      void writeShort(jint) const;
      void writeUTF(const ::java::lang::String &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(DataOutput);
    _dll_lucene extern PyTypeObject *PY_TYPE(DataOutput);

    class _dll_lucene t_DataOutput {
    public:
      PyObject_HEAD
      DataOutput object;
      static PyObject *wrap_Object(const DataOutput&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
