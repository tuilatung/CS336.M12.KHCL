#ifndef java_io_PrintWriter_H
#define java_io_PrintWriter_H

#include "java/io/Writer.h"

namespace java {
  namespace io {
    class PrintWriter;
    class File;
    class OutputStream;
    class FileNotFoundException;
    class UnsupportedEncodingException;
  }
  namespace lang {
    class Class;
    class Object;
    class CharSequence;
    class String;
  }
  namespace util {
    class Locale;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene PrintWriter : public ::java::io::Writer {
     public:
      enum {
        mid_init$_0000000048822f5e,
        mid_init$_000000005456c19e,
        mid_init$_ffffffffc4df164a,
        mid_init$_ffffffffac5e0eab,
        mid_init$_0000000041bba0eb,
        mid_init$_000000001de5feb3,
        mid_init$_ffffffffea5c5690,
        mid_init$_0000000057be5b03,
        mid_append_ffffffffa24574b6,
        mid_append_000000007d044b94,
        mid_append_ffffffffab960d55,
        mid_checkError_0000000000c0c182,
        mid_close_ffffffffde902c42,
        mid_flush_ffffffffde902c42,
        mid_format_000000001884820f,
        mid_format_ffffffffc420f8c3,
        mid_print_fffffffffc2a4e56,
        mid_print_ffffffff985e9c5c,
        mid_print_ffffffffa0b31ff5,
        mid_print_000000005e56173b,
        mid_print_ffffffffd7cfea8c,
        mid_print_ffffffff9530faa9,
        mid_print_0000000048822f5e,
        mid_print_ffffffffa23b19d5,
        mid_print_000000003e46d501,
        mid_printf_000000001884820f,
        mid_printf_ffffffffc420f8c3,
        mid_println_ffffffffde902c42,
        mid_println_000000003e46d501,
        mid_println_ffffffffa23b19d5,
        mid_println_fffffffffc2a4e56,
        mid_println_0000000048822f5e,
        mid_println_ffffffff9530faa9,
        mid_println_ffffffffa0b31ff5,
        mid_println_000000005e56173b,
        mid_println_ffffffffd7cfea8c,
        mid_println_ffffffff985e9c5c,
        mid_write_ffffffffa23b19d5,
        mid_write_ffffffffa0b31ff5,
        mid_write_0000000048822f5e,
        mid_write_0000000052290416,
        mid_write_000000002c87a49f,
        mid_clearError_ffffffffde902c42,
        mid_setError_ffffffffde902c42,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit PrintWriter(jobject obj) : ::java::io::Writer(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      PrintWriter(const PrintWriter& obj) : ::java::io::Writer(obj) {}

      PrintWriter(const ::java::lang::String &);
      PrintWriter(const ::java::io::File &);
      PrintWriter(const ::java::io::Writer &);
      PrintWriter(const ::java::io::OutputStream &);
      PrintWriter(const ::java::io::OutputStream &, jboolean);
      PrintWriter(const ::java::io::File &, const ::java::lang::String &);
      PrintWriter(const ::java::lang::String &, const ::java::lang::String &);
      PrintWriter(const ::java::io::Writer &, jboolean);

      PrintWriter append(const ::java::lang::CharSequence &) const;
      PrintWriter append(jchar) const;
      PrintWriter append(const ::java::lang::CharSequence &, jint, jint) const;
      jboolean checkError() const;
      void close() const;
      void flush() const;
      PrintWriter format(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintWriter format(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void print(jfloat) const;
      void print(jlong) const;
      void print(jint) const;
      void print(jchar) const;
      void print(jboolean) const;
      void print(const ::java::lang::Object &) const;
      void print(const ::java::lang::String &) const;
      void print(const JArray< jchar > &) const;
      void print(jdouble) const;
      PrintWriter printf(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintWriter printf(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void println() const;
      void println(jdouble) const;
      void println(const JArray< jchar > &) const;
      void println(jfloat) const;
      void println(const ::java::lang::String &) const;
      void println(const ::java::lang::Object &) const;
      void println(jint) const;
      void println(jchar) const;
      void println(jboolean) const;
      void println(jlong) const;
      void write(const JArray< jchar > &) const;
      void write(jint) const;
      void write(const ::java::lang::String &) const;
      void write(const JArray< jchar > &, jint, jint) const;
      void write(const ::java::lang::String &, jint, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(PrintWriter);
    _dll_lucene extern PyTypeObject *PY_TYPE(PrintWriter);

    class _dll_lucene t_PrintWriter {
    public:
      PyObject_HEAD
      PrintWriter object;
      static PyObject *wrap_Object(const PrintWriter&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
