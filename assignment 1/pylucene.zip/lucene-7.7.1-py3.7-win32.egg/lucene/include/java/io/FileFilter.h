#ifndef java_io_FileFilter_H
#define java_io_FileFilter_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class File;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene FileFilter : public ::java::lang::Object {
     public:
      enum {
        mid_accept_0000000018dbd13b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit FileFilter(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      FileFilter(const FileFilter& obj) : ::java::lang::Object(obj) {}

      jboolean accept(const ::java::io::File &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(FileFilter);
    _dll_lucene extern PyTypeObject *PY_TYPE(FileFilter);

    class _dll_lucene t_FileFilter {
    public:
      PyObject_HEAD
      FileFilter object;
      static PyObject *wrap_Object(const FileFilter&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
