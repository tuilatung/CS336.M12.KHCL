#ifndef java_io_Reader_H
#define java_io_Reader_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class IOException;
    class Closeable;
  }
  namespace lang {
    class Readable;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene Reader : public ::java::lang::Object {
     public:
      enum {
        mid_close_ffffffffde902c42,
        mid_mark_ffffffffa0b31ff5,
        mid_markSupported_0000000000c0c182,
        mid_read_000000002043cb81,
        mid_read_0000000015233544,
        mid_read_ffffffffc9e60873,
        mid_ready_0000000000c0c182,
        mid_reset_ffffffffde902c42,
        mid_skip_0000000032d92391,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Reader(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Reader(const Reader& obj) : ::java::lang::Object(obj) {}

      void close() const;
      void mark(jint) const;
      jboolean markSupported() const;
      jint read() const;
      jint read(const JArray< jchar > &) const;
      jint read(const JArray< jchar > &, jint, jint) const;
      jboolean ready() const;
      void reset() const;
      jlong skip(jlong) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Reader);
    _dll_lucene extern PyTypeObject *PY_TYPE(Reader);

    class _dll_lucene t_Reader {
    public:
      PyObject_HEAD
      Reader object;
      static PyObject *wrap_Object(const Reader&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
