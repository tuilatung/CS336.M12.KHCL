#ifndef java_io_File_H
#define java_io_File_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class File;
    class FileFilter;
    class FilenameFilter;
    class Serializable;
    class IOException;
  }
  namespace lang {
    class Class;
    class Comparable;
    class String;
  }
  namespace nio {
    namespace file {
      class Path;
    }
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene File : public ::java::lang::Object {
     public:
      enum {
        mid_init$_0000000048822f5e,
        mid_init$_ffffffffea5c5690,
        mid_init$_000000001de5feb3,
        mid_canExecute_0000000000c0c182,
        mid_canRead_0000000000c0c182,
        mid_canWrite_0000000000c0c182,
        mid_compareTo_0000000037862cdd,
        mid_createNewFile_0000000000c0c182,
        mid_createTempFile_0000000001afb7d8,
        mid_createTempFile_ffffffffdba3d8e7,
        mid_delete_0000000000c0c182,
        mid_deleteOnExit_ffffffffde902c42,
        mid_equals_000000007b2e38e9,
        mid_exists_0000000000c0c182,
        mid_getAbsoluteFile_ffffffffc9f49bb5,
        mid_getAbsolutePath_000000001d4fc793,
        mid_getCanonicalFile_ffffffffc9f49bb5,
        mid_getCanonicalPath_000000001d4fc793,
        mid_getFreeSpace_ffffffffb4c92ea6,
        mid_getName_000000001d4fc793,
        mid_getParent_000000001d4fc793,
        mid_getParentFile_ffffffffc9f49bb5,
        mid_getPath_000000001d4fc793,
        mid_getTotalSpace_ffffffffb4c92ea6,
        mid_getUsableSpace_ffffffffb4c92ea6,
        mid_hashCode_000000002043cb81,
        mid_isAbsolute_0000000000c0c182,
        mid_isDirectory_0000000000c0c182,
        mid_isFile_0000000000c0c182,
        mid_isHidden_0000000000c0c182,
        mid_lastModified_ffffffffb4c92ea6,
        mid_length_ffffffffb4c92ea6,
        mid_list_ffffffffbcb33d67,
        mid_list_000000002801e520,
        mid_listFiles_00000000109eddc7,
        mid_listFiles_ffffffffaf02dffb,
        mid_listFiles_fffffffff353b743,
        mid_listRoots_00000000109eddc7,
        mid_mkdir_0000000000c0c182,
        mid_mkdirs_0000000000c0c182,
        mid_renameTo_0000000018dbd13b,
        mid_setExecutable_0000000038de4f94,
        mid_setExecutable_ffffffffad2ab262,
        mid_setLastModified_000000004e3615da,
        mid_setReadOnly_0000000000c0c182,
        mid_setReadable_0000000038de4f94,
        mid_setReadable_ffffffffad2ab262,
        mid_setWritable_0000000038de4f94,
        mid_setWritable_ffffffffad2ab262,
        mid_toPath_ffffffffe3b81ba8,
        mid_toString_000000001d4fc793,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit File(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      File(const File& obj) : ::java::lang::Object(obj) {}

      static ::java::lang::String *pathSeparator;
      static jchar pathSeparatorChar;
      static ::java::lang::String *separator;
      static jchar separatorChar;

      File(const ::java::lang::String &);
      File(const ::java::lang::String &, const ::java::lang::String &);
      File(const File &, const ::java::lang::String &);

      jboolean canExecute() const;
      jboolean canRead() const;
      jboolean canWrite() const;
      jint compareTo(const File &) const;
      jboolean createNewFile() const;
      static File createTempFile(const ::java::lang::String &, const ::java::lang::String &);
      static File createTempFile(const ::java::lang::String &, const ::java::lang::String &, const File &);
      jboolean delete$() const;
      void deleteOnExit() const;
      jboolean equals(const ::java::lang::Object &) const;
      jboolean exists() const;
      File getAbsoluteFile() const;
      ::java::lang::String getAbsolutePath() const;
      File getCanonicalFile() const;
      ::java::lang::String getCanonicalPath() const;
      jlong getFreeSpace() const;
      ::java::lang::String getName() const;
      ::java::lang::String getParent() const;
      File getParentFile() const;
      ::java::lang::String getPath() const;
      jlong getTotalSpace() const;
      jlong getUsableSpace() const;
      jint hashCode() const;
      jboolean isAbsolute() const;
      jboolean isDirectory() const;
      jboolean isFile() const;
      jboolean isHidden() const;
      jlong lastModified() const;
      jlong length() const;
      JArray< ::java::lang::String > list() const;
      JArray< ::java::lang::String > list(const ::java::io::FilenameFilter &) const;
      JArray< File > listFiles() const;
      JArray< File > listFiles(const ::java::io::FilenameFilter &) const;
      JArray< File > listFiles(const ::java::io::FileFilter &) const;
      static JArray< File > listRoots();
      jboolean mkdir() const;
      jboolean mkdirs() const;
      jboolean renameTo(const File &) const;
      jboolean setExecutable(jboolean) const;
      jboolean setExecutable(jboolean, jboolean) const;
      jboolean setLastModified(jlong) const;
      jboolean setReadOnly() const;
      jboolean setReadable(jboolean) const;
      jboolean setReadable(jboolean, jboolean) const;
      jboolean setWritable(jboolean) const;
      jboolean setWritable(jboolean, jboolean) const;
      ::java::nio::file::Path toPath() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(File);
    _dll_lucene extern PyTypeObject *PY_TYPE(File);

    class _dll_lucene t_File {
    public:
      PyObject_HEAD
      File object;
      static PyObject *wrap_Object(const File&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
