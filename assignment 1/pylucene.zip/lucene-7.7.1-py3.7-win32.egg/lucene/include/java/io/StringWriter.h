#ifndef java_io_StringWriter_H
#define java_io_StringWriter_H

#include "java/io/Writer.h"

namespace java {
  namespace lang {
    class StringBuffer;
    class Class;
    class CharSequence;
    class String;
  }
  namespace io {
    class StringWriter;
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene StringWriter : public ::java::io::Writer {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_init$_ffffffffa0b31ff5,
        mid_append_ffffffffd7e54cdd,
        mid_append_ffffffffad47fd6d,
        mid_append_000000003af35afb,
        mid_close_ffffffffde902c42,
        mid_flush_ffffffffde902c42,
        mid_getBuffer_ffffffffe3d2e3e6,
        mid_toString_000000001d4fc793,
        mid_write_0000000048822f5e,
        mid_write_ffffffffa0b31ff5,
        mid_write_000000002c87a49f,
        mid_write_0000000052290416,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit StringWriter(jobject obj) : ::java::io::Writer(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      StringWriter(const StringWriter& obj) : ::java::io::Writer(obj) {}

      StringWriter();
      StringWriter(jint);

      StringWriter append(jchar) const;
      StringWriter append(const ::java::lang::CharSequence &) const;
      StringWriter append(const ::java::lang::CharSequence &, jint, jint) const;
      void close() const;
      void flush() const;
      ::java::lang::StringBuffer getBuffer() const;
      ::java::lang::String toString() const;
      void write(const ::java::lang::String &) const;
      void write(jint) const;
      void write(const ::java::lang::String &, jint, jint) const;
      void write(const JArray< jchar > &, jint, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(StringWriter);
    _dll_lucene extern PyTypeObject *PY_TYPE(StringWriter);

    class _dll_lucene t_StringWriter {
    public:
      PyObject_HEAD
      StringWriter object;
      static PyObject *wrap_Object(const StringWriter&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
