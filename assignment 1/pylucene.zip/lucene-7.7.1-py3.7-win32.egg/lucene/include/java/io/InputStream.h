#ifndef java_io_InputStream_H
#define java_io_InputStream_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class IOException;
    class Closeable;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene InputStream : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_available_000000002043cb81,
        mid_close_ffffffffde902c42,
        mid_mark_ffffffffa0b31ff5,
        mid_markSupported_0000000000c0c182,
        mid_read_000000002043cb81,
        mid_read_ffffffffceb14ffc,
        mid_read_ffffffffecb4e587,
        mid_reset_ffffffffde902c42,
        mid_skip_0000000032d92391,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit InputStream(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      InputStream(const InputStream& obj) : ::java::lang::Object(obj) {}

      InputStream();

      jint available() const;
      void close() const;
      void mark(jint) const;
      jboolean markSupported() const;
      jint read() const;
      jint read(const JArray< jbyte > &) const;
      jint read(const JArray< jbyte > &, jint, jint) const;
      void reset() const;
      jlong skip(jlong) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(InputStream);
    _dll_lucene extern PyTypeObject *PY_TYPE(InputStream);

    class _dll_lucene t_InputStream {
    public:
      PyObject_HEAD
      InputStream object;
      static PyObject *wrap_Object(const InputStream&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
