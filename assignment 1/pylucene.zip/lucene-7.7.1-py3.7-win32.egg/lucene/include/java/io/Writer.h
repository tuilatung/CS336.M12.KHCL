#ifndef java_io_Writer_H
#define java_io_Writer_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class Appendable;
    class CharSequence;
    class String;
  }
  namespace io {
    class Flushable;
    class Closeable;
    class Writer;
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene Writer : public ::java::lang::Object {
     public:
      enum {
        mid_append_0000000076cd256c,
        mid_append_000000000f301899,
        mid_append_ffffffffafb1573a,
        mid_close_ffffffffde902c42,
        mid_flush_ffffffffde902c42,
        mid_write_ffffffffa23b19d5,
        mid_write_ffffffffa0b31ff5,
        mid_write_0000000048822f5e,
        mid_write_0000000052290416,
        mid_write_000000002c87a49f,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Writer(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Writer(const Writer& obj) : ::java::lang::Object(obj) {}

      Writer append(jchar) const;
      Writer append(const ::java::lang::CharSequence &) const;
      Writer append(const ::java::lang::CharSequence &, jint, jint) const;
      void close() const;
      void flush() const;
      void write(const JArray< jchar > &) const;
      void write(jint) const;
      void write(const ::java::lang::String &) const;
      void write(const JArray< jchar > &, jint, jint) const;
      void write(const ::java::lang::String &, jint, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(Writer);
    _dll_lucene extern PyTypeObject *PY_TYPE(Writer);

    class _dll_lucene t_Writer {
    public:
      PyObject_HEAD
      Writer object;
      static PyObject *wrap_Object(const Writer&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
