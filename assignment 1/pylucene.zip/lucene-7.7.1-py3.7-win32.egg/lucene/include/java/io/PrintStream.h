#ifndef java_io_PrintStream_H
#define java_io_PrintStream_H

#include "java/io/FilterOutputStream.h"

namespace java {
  namespace io {
    class File;
    class OutputStream;
    class FileNotFoundException;
    class UnsupportedEncodingException;
    class PrintStream;
  }
  namespace lang {
    class Class;
    class Appendable;
    class Object;
    class CharSequence;
    class String;
  }
  namespace util {
    class Locale;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene PrintStream : public ::java::io::FilterOutputStream {
     public:
      enum {
        mid_init$_ffffffffac5e0eab,
        mid_init$_0000000048822f5e,
        mid_init$_000000005456c19e,
        mid_init$_0000000041bba0eb,
        mid_init$_ffffffffea5c5690,
        mid_init$_000000001de5feb3,
        mid_init$_000000006107002f,
        mid_append_00000000647c0557,
        mid_append_ffffffff83651ce7,
        mid_append_0000000048759262,
        mid_checkError_0000000000c0c182,
        mid_close_ffffffffde902c42,
        mid_flush_ffffffffde902c42,
        mid_format_fffffffff623da15,
        mid_format_0000000057c4dba6,
        mid_print_ffffffffd7cfea8c,
        mid_print_ffffffff985e9c5c,
        mid_print_000000003e46d501,
        mid_print_fffffffffc2a4e56,
        mid_print_ffffffff9530faa9,
        mid_print_0000000048822f5e,
        mid_print_ffffffffa23b19d5,
        mid_print_ffffffffa0b31ff5,
        mid_print_000000005e56173b,
        mid_printf_fffffffff623da15,
        mid_printf_0000000057c4dba6,
        mid_println_ffffffffde902c42,
        mid_println_000000003e46d501,
        mid_println_fffffffffc2a4e56,
        mid_println_ffffffff985e9c5c,
        mid_println_ffffffff9530faa9,
        mid_println_0000000048822f5e,
        mid_println_ffffffffa23b19d5,
        mid_println_ffffffffd7cfea8c,
        mid_println_000000005e56173b,
        mid_println_ffffffffa0b31ff5,
        mid_write_ffffffffa0b31ff5,
        mid_write_00000000311f6778,
        mid_clearError_ffffffffde902c42,
        mid_setError_ffffffffde902c42,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit PrintStream(jobject obj) : ::java::io::FilterOutputStream(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      PrintStream(const PrintStream& obj) : ::java::io::FilterOutputStream(obj) {}

      PrintStream(const ::java::io::OutputStream &);
      PrintStream(const ::java::lang::String &);
      PrintStream(const ::java::io::File &);
      PrintStream(const ::java::io::OutputStream &, jboolean);
      PrintStream(const ::java::lang::String &, const ::java::lang::String &);
      PrintStream(const ::java::io::File &, const ::java::lang::String &);
      PrintStream(const ::java::io::OutputStream &, jboolean, const ::java::lang::String &);

      PrintStream append(jchar) const;
      PrintStream append(const ::java::lang::CharSequence &) const;
      PrintStream append(const ::java::lang::CharSequence &, jint, jint) const;
      jboolean checkError() const;
      void close() const;
      void flush() const;
      PrintStream format(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintStream format(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void print(jboolean) const;
      void print(jlong) const;
      void print(jdouble) const;
      void print(jfloat) const;
      void print(const ::java::lang::Object &) const;
      void print(const ::java::lang::String &) const;
      void print(const JArray< jchar > &) const;
      void print(jint) const;
      void print(jchar) const;
      PrintStream printf(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintStream printf(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void println() const;
      void println(jdouble) const;
      void println(jfloat) const;
      void println(jlong) const;
      void println(const ::java::lang::Object &) const;
      void println(const ::java::lang::String &) const;
      void println(const JArray< jchar > &) const;
      void println(jboolean) const;
      void println(jchar) const;
      void println(jint) const;
      void write(jint) const;
      void write(const JArray< jbyte > &, jint, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(PrintStream);
    _dll_lucene extern PyTypeObject *PY_TYPE(PrintStream);

    class _dll_lucene t_PrintStream {
    public:
      PyObject_HEAD
      PrintStream object;
      static PyObject *wrap_Object(const PrintStream&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
