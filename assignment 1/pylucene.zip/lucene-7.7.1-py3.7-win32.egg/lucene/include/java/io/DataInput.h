#ifndef java_io_DataInput_H
#define java_io_DataInput_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene DataInput : public ::java::lang::Object {
     public:
      enum {
        mid_readBoolean_0000000000c0c182,
        mid_readByte_ffffffffb58647b4,
        mid_readChar_ffffffffb606c467,
        mid_readDouble_0000000046402c15,
        mid_readFloat_ffffffffee5e3be1,
        mid_readFully_0000000038c78f53,
        mid_readFully_00000000311f6778,
        mid_readInt_000000002043cb81,
        mid_readLine_000000001d4fc793,
        mid_readLong_ffffffffb4c92ea6,
        mid_readShort_00000000001347c2,
        mid_readUTF_000000001d4fc793,
        mid_readUnsignedByte_000000002043cb81,
        mid_readUnsignedShort_000000002043cb81,
        mid_skipBytes_000000007930bd1c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit DataInput(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      DataInput(const DataInput& obj) : ::java::lang::Object(obj) {}

      jboolean readBoolean() const;
      jbyte readByte() const;
      jchar readChar() const;
      jdouble readDouble() const;
      jfloat readFloat() const;
      void readFully(const JArray< jbyte > &) const;
      void readFully(const JArray< jbyte > &, jint, jint) const;
      jint readInt() const;
      ::java::lang::String readLine() const;
      jlong readLong() const;
      jshort readShort() const;
      ::java::lang::String readUTF() const;
      jint readUnsignedByte() const;
      jint readUnsignedShort() const;
      jint skipBytes(jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(DataInput);
    _dll_lucene extern PyTypeObject *PY_TYPE(DataInput);

    class _dll_lucene t_DataInput {
    public:
      PyObject_HEAD
      DataInput object;
      static PyObject *wrap_Object(const DataInput&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
