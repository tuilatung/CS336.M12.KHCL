#ifndef java_io_FileDescriptor_H
#define java_io_FileDescriptor_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class SyncFailedException;
    class FileDescriptor;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class _dll_lucene FileDescriptor : public ::java::lang::Object {
     public:
      enum {
        mid_init$_ffffffffde902c42,
        mid_sync_ffffffffde902c42,
        mid_valid_0000000000c0c182,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit FileDescriptor(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      FileDescriptor(const FileDescriptor& obj) : ::java::lang::Object(obj) {}

      static FileDescriptor *err;
      static FileDescriptor *in;
      static FileDescriptor *out;

      FileDescriptor();

      void sync() const;
      jboolean valid() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    _dll_lucene extern PyType_Def PY_TYPE_DEF(FileDescriptor);
    _dll_lucene extern PyTypeObject *PY_TYPE(FileDescriptor);

    class _dll_lucene t_FileDescriptor {
    public:
      PyObject_HEAD
      FileDescriptor object;
      static PyObject *wrap_Object(const FileDescriptor&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
