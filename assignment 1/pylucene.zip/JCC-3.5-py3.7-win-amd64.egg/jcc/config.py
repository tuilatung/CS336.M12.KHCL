
INCLUDES=['C:\\Program Files\\Java\\jdk1.8.0_65/include', 'C:\\Program Files\\Java\\jdk1.8.0_65/include/win32']
CFLAGS=['/EHsc', '/D_CRT_SECURE_NO_WARNINGS', '/bigobj']
DEBUG_CFLAGS=['/Od', '/DDEBUG']
LFLAGS=['/DLL', '/LIBPATH:C:\\Program Files\\Java\\jdk1.8.0_65/lib', 'Ws2_32.lib', 'jvm.lib']
IMPLIB_LFLAGS=['/IMPLIB:%s']
SHARED=True
VERSION="3.5"
